﻿/** Single chat message for display purposes */
export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

/**
 * Per-project configuration (loaded from the projects DB table).
 * Shared for frontend use in admin UI and project configuration.
 */
export interface ProjectConfig {
  id: string;
  name: string;
  enabledModes: string[];
  kbRepoOwner: string | null;
  kbRepoName: string | null;
  adoOrg: string | null;
  adoProject: string | null;
}

/**
 * Request to the chat endpoint.
 * Client generates a stable UUID sessionId on page load and sends it with every message.
 * Server maintains the actual SDK session in a Map keyed by sessionId.
 * Only the current message is sent — the SDK session retains conversation context server-side.
 */
export interface ChatRequest {
  sessionId: string;               // UUID generated on frontend page load
  message: string;                 // Current user message only
  mode?: "chat" | "ud" | "sdlc" | "brd-analyst" | "impl-plan" | "coding" | "release";
  projectId?: string;              // Project scope (defaults to "default" on server)
  buildId?: string;                // If present, session is build-scoped (pipeline mode)
}

/** Streaming event types for chat SSE */
export type ChatStreamEventType =
  | "chunk"           // Assistant text delta
  | "done"            // Stream complete
  | "error"           // Error occurred
  | "tool_start"      // Tool execution started
  | "tool_complete"   // Tool execution completed
  | "status"          // Status message (e.g., KB loading)
  | "ud_file_ready"           // UD file ready for download (UD / SDLC mode)
  | "artifact_download_ready" // Build artifact ready for download — data: JSON.stringify(ArtifactDownloadPayload)
  | "work_item_loaded"        // ADO work item fetched — data: JSON.stringify(ADOWorkItem)
  | "ud_attached"             // UD attached to ADO work item — data: JSON.stringify(UDAttachedPayload)
  | "artifact_saved"          // Build artifact saved — data: JSON.stringify(ArtifactSavedPayload)
  | "build_stage_advanced";   // Stage advanced — data: JSON.stringify({ buildId, newStage, newMode })

export interface ChatStreamEvent {
  type: ChatStreamEventType;
  data: string;
}

// ─── UD Types ──────────────────────────────────────────────────────────────────

/** Payload carried by a ud_file_ready SSE event */
export interface UDFilePayload {
  filename: string; // e.g., "UD_TICKET-123.md"
  content: string;  // Complete UD in Markdown format
}

/** Payload carried by an artifact_download_ready SSE event (BRD, impl-plan, release-notes) */
export interface ArtifactDownloadPayload {
  filename: string;     // e.g., "BRD_Auth_Feature.md"
  content: string;      // Complete artifact content in Markdown format
  artifactType: string; // e.g., "brd", "impl-plan", "release-notes"
}

// ─── Azure DevOps Types (SDLC Agent Mode) ─────────────────────────────────────

/** A parsed Azure DevOps Work Item returned by the fetch_azure_work_item tool */
export interface ADOWorkItem {
  id: number;
  title: string;
  description: string;           // HTML-stripped plain text
  acceptanceCriteria: string;    // HTML-stripped plain text
  state: string;                 // e.g. "Active", "Resolved"
  assignedTo?: string;           // Display name
  areaPath: string;
  iterationPath?: string;
  tags: string[];                // Split from semicolon-delimited field
  workItemType: string;          // e.g. "User Story", "Bug", "Task"
  url: string;                   // Web URL to the work item in Azure DevOps
}

/** Payload emitted when a build pipeline artifact is saved (create_artifact_file tool) */
export interface ArtifactSavedPayload {
  buildId: string;
  stage: string;    // e.g. "brd_intake"
  filename: string; // e.g. "BRD_Auth_Feature.md"
}

/** Payload carried by a ud_attached SSE event */
export interface UDAttachedPayload {
  workItemId: number;
  attachmentUrl: string;  // ADO attachment API URL
  webUrl: string;         // Human-readable work item URL
}

// ─── Artifacts (Generated Documents) ───────────────────────────────────────────────────────────────────

export type ArtifactType = "ud" | "hld" | "test" | "release-notes" | "brd" | "impl-plan";

/** A persisted generated artifact (UD, HLD, test case, release notes, BRD, impl-plan). */
export interface Artifact {
  id: number;
  sessionKey: string;
  projectId: string | null;
  filename: string;
  content: string;
  artifactType: ArtifactType;
  version: number;
  createdAt: string;
}

// ─── Build Pipeline Types (Phase 3) ────────────────────────────────────────────

export type BuildStage =
  | "brd_intake"
  | "brd_approved"
  | "ud_draft"
  | "ud_approved"
  | "impl_plan"
  | "plan_approved"
  | "coding"
  | "pr_created"
  | "release_docs"
  | "completed";

export type BuildStatus = "active" | "paused" | "failed" | "completed";
export type ApprovalDecision = "approved" | "rejected" | "revision_requested";

export interface Build {
  id: string;
  projectId: string;
  title: string;
  description: string | null;
  adoWorkItemId: number | null;
  currentStage: BuildStage;
  status: BuildStatus;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  releasedAt: string | null;
  isArchived: boolean;
}

export interface BuildApproval {
  id: number;
  buildId: string;
  stage: string;
  approvedBy: string;
  approvedAt: string;
  decision: ApprovalDecision;
  comments: string | null;
}

export interface BuildArtifactSummary {
  stage: string;
  artifactId: number;
  filename: string | null;
  artifactType: ArtifactType | null;
  version: number | null;
  createdAt: string;
}

export interface BuildDetail extends Build {
  artifacts: BuildArtifactSummary[];
  approvals: BuildApproval[];
}

/** Stage labels for display in the pipeline UI */
export const STAGE_LABELS: Record<BuildStage, string> = {
  brd_intake: "BRD Intake",
  brd_approved: "BRD Approved",
  ud_draft: "UD Draft",
  ud_approved: "UD Approved",
  impl_plan: "Implementation Plan",
  plan_approved: "Plan Approved",
  coding: "Coding",
  pr_created: "PR Created",
  release_docs: "Release Docs",
  completed: "Completed",
};

// ─── Observe Response Shapes ───────────────────────────────────────────────────

export interface SkillHealthEntry {
  mode: string;
  displayName: string;
  health: "healthy" | "degraded" | "unknown";
  fallbackMode: string | null;
}

export interface ObserveHealthResponse {
  skills: SkillHealthEntry[];
  capturedAt: string;
}

export interface SkillMetricsSummary {
  requestCount: number;
  errorCount: number;
  avgLatencyMs: number;
  lastErrorAt: string | null;
}

export interface ObserveMetricsResponse {
  skills: Record<string, SkillMetricsSummary>;
  toolCallCount: Record<string, number>;
  uptimeSecs: number;
  capturedAt: string;
}

export interface ActiveSessionInfo {
  sessionKeyHash: string;
  lastUsedAt: string;
  mode: string;
  isProcessing: boolean;
  queueDepth: number;
}

export interface ObserveSessionsResponse {
  sessions: ActiveSessionInfo[];
  totalCount: number;
  capturedAt: string;
}

export interface ObserveErrorEntry {
  timestamp: string;
  skill: string;
  message: string;
  requestId?: string;
}

export interface ObserveErrorsResponse {
  errors: ObserveErrorEntry[];
  count: number;
  capturedAt: string;
}

// ─── Session Registry Types ────────────────────────────────────────────────────────────────────────

/**
 * Metadata for a session entry in the SessionRegistry.
 * Used by /api/observe/sessions and multi-instance routing checks.
 */
export interface SessionRegistryEntry {
  sessionKey: string;
  instanceId: string;
  mode: string;
  projectId: string;
  registeredAt: string;
  lastSeenAt: string;
}

// ─── Phase 4.1: Observer Logs ─────────────────────────────────────────────────

export interface ObserverLogEntry {
  id: number;
  skill: string;
  diagnosis: string;
  action: string;
  confidence: number;
  outcome: string;
  created_at: string;
}

export interface ObserveObserverLogsResponse {
  logs: ObserverLogEntry[];
  count: number;
  capturedAt: string;
}

// ─── Phase 4.4: Circuit Breaker ───────────────────────────────────────────────

export type CircuitBreakerState = "closed" | "open" | "half_open";

export interface CircuitBreakerEntry {
  state: CircuitBreakerState;
  failures: number;
  lastFailureAt: string | null;
}

export interface ObserveCircuitBreakersResponse {
  circuitBreakers: Record<string, CircuitBreakerEntry>;
  count: number;
  capturedAt: string;
}

// ─── Phase 4.8: Prompt Templates ──────────────────────────────────────────────

export interface PromptTemplate {
  id: number;
  project_id: string;
  mode: string;
  version: number;
  content: string;
  is_active: number; // 1 = active, 0 = inactive
  created_by: string;
  created_at: string;
}

export type PromptMode =
  | "chat"
  | "ud"
  | "sdlc"
  | "brd-analyst"
  | "impl-plan"
  | "coding"
  | "release";

