# SDLC Copilot — Project Overview

**In one sentence:** An AI assistant for the entire SDLC lifecycle — from requirements gathering and design to implementation planning and release notes — integrated with GitHub and Azure DevOps.

---

## What It Does

### 1. Requirements → Understanding Documents (UD)

**Mode:** `sdlc`

Automated UD creation for Azure DevOps work items:

```
Step 1: Provide work item ID
Step 2: AI asks 3–7 clarifying questions
Step 3: AI drafts complete UD (scope, data, logic, UI, tests, dependencies)
Step 4: Review and iterate
Step 5: Approve → UD auto-attaches to work item in ADO
```

### 2. Business Requirements Documents (BRD)

**Mode:** `brd`

Structured business requirements with stakeholder context, business drivers, success metrics, and constraints.

### 3. High-Level Design (HLD)

**Mode:** `hld`

System architecture, component interactions, technology stack, data flows, and integration points.

### 4. Implementation Planning

**Mode:** `impl-plan`

Detailed implementation roadmap, task breakdown, dependencies, and GitHub Copilot agent trigger for proof-of-work.

### 5. Release Notes

**Mode:** `release-notes`

Auto-generated release documentation from feature set, including what changed, why, and how to upgrade.

### 6. File Summarizer

**Ad-hoc:** Summarize any GitHub file (code, config, markdown) in plain English.

---

## How It Works (Simple Flow)

```
        You (in browser)
              ↓
        Write requirement
              ↓
    ┌─────────▼─────────┐
    │  AI asks questions │
    └─────────┬─────────┘
              ↓
        You answer (1 round)
              ↓
    ┌─────────▼──────────────┐
    │  AI generates document │
    │ (UD / BRD / HLD / etc) │
    └─────────┬──────────────┘
              ↓
        You review & approve
              ↓
    ┌─────────▼──────────┐
    │  Auto-attach to    │
    │  Azure DevOps or   │
    │  Download as .md   │
    └────────────────────┘
```

**Key difference from ChatGPT:**
- Grounded in your project KB (not guessing)
- Integrated with ADO (one-click attachment)
- Structured output (scope, data, logic, UI, tests)
- Project memory (remembers decisions across sessions)

---

## Who Uses It

| Role | Use Case |
|---|---|
| **Business Analyst** | Requirements gathering → UD creation → link to ADO tickets |
| **Product Manager** | Business requirements + design → BRD + success criteria |
| **Architect** | System design → HLD with integration points |
| **Developer** | Understanding unfamiliar codebases, implementation roadmaps |
| **Tech Lead** | Questions about system design, code reviews |
| **QA Engineer** | Understanding requirements deeply, edge case discovery |

---

## Key Features

✅ **Multi-project support** — One deployment, multiple teams (KB repo + ADO org per project)

✅ **Session recovery** — Server restarts don't lose conversations; resume from database

✅ **Project memory** — Teams accumulate knowledge (decisions, patterns, caveats) across sessions

✅ **Self-healing** — LLM-backed observer diagnoses and fixes skill failures automatically

✅ **Audit trail** — Every action logged with who, what, when; full traceability

✅ **Security hardened** — 5-layer prompt injection defense, timing-safe auth, role-locked prompts

✅ **Admin observability** — Health dashboard, metrics, circuit breaker status, error logs

✅ **Extensible modes** — New SDLC phases (testing, maintenance) are drop-in skills

---

## Technology Stack (You Don't Need to Know)

- **LLM Engine:** GitHub Copilot SDK (uses Claude)
- **Backend:** Express + Node.js + TypeScript
- **Frontend:** Next.js 15 + React 19
- **Database:** SQLite (all state: sessions, memory, artifacts, audit logs)
- **Deployment:** Single Express server + SQLite file (or Docker)

---

## Getting Started

**Start the demo:**
```bash
# 1. Install dependencies
npm install

# 2. Configure (create .env at repo root)
COPILOT_TOKEN=<your GitHub Copilot token>
API_KEYS=demo-key-12345
KB_REPO_OWNER=<your repo owner>
KB_REPO_NAME=<your kb repo>
ADO_ORG=<your Azure DevOps org>
ADO_PROJECT=<your ADO project>
ADO_PAT=<your ADO personal access token>

# 3. Run
npm run dev

# 4. Open http://localhost:3000 in your browser
```

**Available modes (select in UI):**
- **SDLC** — Requirements → UD + ADO attachment
- **BRD** — Business requirements
- **HLD** — System design
- **Implementation** — Implementation roadmap
- **Release Notes** — Release documentation

---

## Conversation Example

**Analyst:** "I need a UD for a user authentication module."

**AI:** "I'll help! Let me ask a few clarifying questions:
1. What's the scope — new system or enhancement to existing?
2. Which authentication methods (OAuth, JWT, SAML)?
3. Single sign-on with external systems?
4. Any compliance requirements (GDPR, PCI)?
5. Performance SLA (latency requirement)?"

**Analyst:** "New system, OAuth + JWT, yes SSO with Google, GDPR compliant, < 200ms latency."

**AI:** (reads your KB) "Based on your project architecture, here's the draft UD:

```
# UD — Authentication Module

**Scope:**
- New OAuth + JWT authentication system
- SSO with Google Identity Provider
- Applied to web frontend + mobile app
...
[Complete UD with data models, security considerations, etc.]
```

Looks good? Any changes needed?"

**Analyst:** "Perfect. Approve."

**AI:** "UD saved. Attaching to Azure DevOps work item #1234..." → Done.

---

## Architecture at a Glance

```
Next.js Frontend (You)
         ↓ SSE
Express Server (Smart Routing)
         ↓
GitHub Copilot SDK (LLM Reasoning)
         ├→ Tools (fetch KB files, get ADO items, save artifacts)
         └→ Self-Repair (detect failures, fix itself)
              ↓
         SQLite (All History)
```

The Copilot SDK does the reasoning. Everything around it just handles routing, durability, observability, and security. Think of the server as a "thin wrapper" around the Copilot SDK.

---

## Demo Checklist

- [✅] Multi-project configuration (database-driven, not env vars)
- [✅] UD creation with clarifying questions
- [✅] Azure DevOps integration (fetch + attach)
- [✅] Project memory (remember/recall tools)
- [✅] BRD, HLD, impl-plan, release-notes modes
- [✅] Session persistence (survive server restart)
- [✅] Admin observability dashboard
- [✅] Self-healing (observer agent fixes failures)
- [✅] Full audit trail
- [✅] Security hardened (5-layer injection defense)

**All working. Ready to demo.**

---

## Common Questions

**Q: Does it read my actual code?**
A: No. It reads your KB documentation (markdown files on GitHub). Optional: file summarizer can analyze a specific file, but not your entire codebase.

**Q: Can I use my own LLM?**
A: Currently uses GitHub Copilot (via Copilot SDK). Switching LLMs would require replacing the SDK integration — possible but not the current scope.

**Q: What if the internet goes down?**
A: The UI won't work (it's a web app). But your data is safe in SQLite. When the internet comes back, you can resume sessions.

**Q: How much does it cost?**
A: GitHub Copilot Pro or Business subscription covers this. No additional costs beyond your GitHub plan.

**Q: Can multiple teams share one instance?**
A: Yes. Each team can have their own project config (KB repo, ADO org). The database stores each project's settings separately.

**Q: How do I update the knowledge base?**
A: Commit updated markdown files to your KB GitHub repo. The next session will use the latest versions.

---

## What's Next (Not Needed for Demo)

Future phases (not implemented yet) could include:
- Multi-instance deployment (scale horizontally)
- OAuth/SSO for enterprise auth
- GitHub PR review agent
- Advanced analytics (cost attribution, skill performance trends)

These are deferred. The current system handles 500+ concurrent sessions and 1–2 GB annual data growth — plenty for MVP.

