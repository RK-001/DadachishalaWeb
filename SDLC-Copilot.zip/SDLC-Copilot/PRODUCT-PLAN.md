# SDLC Copilot — Product Plan

**Status:** Phase 1–4 complete (March 2026). Production-ready with full observability, multi-project support, and self-healing infrastructure.

---

## Overview

SDLC Copilot is a GitHub Copilot SDK-powered assistant for the entire SDLC lifecycle. It automates requirements gathering (UD creation), system design (BRD, HLD), implementation planning, and release documentation through conversational AI and Azure DevOps integration.

**Current Capabilities:**
- Multi-mode agent platform (Requirements, Design, Implementation, Release)
- Session-resilient with SQLite persistence and automatic recovery
- Project-scoped memory and artifact storage
- Multi-project configuration from database
- Self-healing infrastructure with Observer Agent
- Internal admin observability (health, metrics, circuit breakers, audit logs)

---

## Architecture

```
┌────────────────────────────────────────────┐
│       Next.js Frontend + React             │
│  ChatInterface  │  FileSummarizer  │ Admin │
└────────────────┬──────────────────────────┘
                 │ SSE Streaming
┌────────────────▼──────────────────────────┐
│        Express Server + Copilot SDK       │
│                                           │
│  ┌──────────────────────────────────┐    │
│  │ OrchestratorAgent + SkillRegistry │    │
│  │ (Chat, UD, Design, Release skills) │   │
│  └────────────┬─────────────────────┘    │
│  ┌────────────▼─────────────────────┐    │
│  │ Tools: KB Fetch, ADO Fetch/Attach │    │
│  │         Memory, Artifact Store    │    │
│  └────────────┬─────────────────────┘    │
│  ┌────────────▼──────────────────────┐   │
│  │ Observability & Self-Healing:     │   │
│  │ - HealthMonitor + Metrics          │   │
│  │ - Observer Agent (LLM-backed)      │   │
│  │ - Circuit Breakers (GitHub/ADO)    │   │
│  └──────────────────────────────────┘    │
└────────────────┬──────────────────────────┘
                 │
      ┌──────────┼──────────┐
      ▼          ▼          ▼
   GitHub     Azure      SQLite
   (Knowledge DevOps    (Persistence:
    Base)    (Work      Sessions,
             Items)     Memory,
                        Artifacts,
                        Audit Logs)
```

---

## Current Implementation (Phases 0–4)

### Phase 0 — SDK Foundation

- ✅ Security hardened (5-layer prompt injection defense, timing-safe auth)
- ✅ SQLite session recovery
- ✅ Project-scoped memory (remember/recall tools)
- ✅ Skill registry + modular tool system
- ✅ Structured logging with Pino
- ✅ Per-session FIFO queue + cancellation

### Phase 1 — Production Persistence

- ✅ Durable artifact store (UDs, BRDs, HLDs, release notes, impl plans)
- ✅ Message history per session
- ✅ Metrics snapshots for admin observability
- ✅ Multi-project configuration from database

### Phase 2 — Multi-Agent Build Pipeline (Design Phase)

- ✅ BRD Analyst skill
- ✅ HLD Designer skill
- ✅ Build lifecycle management (6-stage pipeline)
- ✅ Approval gates + audit trail

### Phase 3 — Multi-Agent Build Pipeline (Execution Phase)

- ✅ Implementation Plan skill
- ✅ Release Notes skill
- ✅ Coding Coordinator (triggers GitHub Copilot agent)
- ✅ Multi-repository support
- ✅ GitHub Actions integration for proof-of-work

### Phase 4 — Stability, Security & Scale

- ✅ Observer Agent (LLM-backed self-repair)
- ✅ Circuit breaker for GitHub/ADO APIs
- ✅ Admin auth guard for observe/* endpoints
- ✅ Prompt versioning + custom templates per project
- ✅ Full request tracing (UUID v4 correlation IDs)
- ✅ UX polish (copy-to-clipboard, artifact export, build history chart)

---

## Working Modes

| Mode | Purpose | Key Tools |
|---|---|---|
| `sdlc` | Requirements → UD + ADO integration | fetch_kb_file, fetch_ado_work_item, create_ud_file, attach_ud_to_work_item, remember, recall |
| `brd` | Business requirements + design | fetch_kb_file, create_ud_file, remember, recall |
| `hld` | High-level design documentation | fetch_kb_file, create_ud_file, remember, recall |
| `impl-plan` | Implementation planning | fetch_kb_file, create_ud_file, fetch_github_issue, remember, recall |
| `release-notes` | Release documentation | fetch_kb_file, create_ud_file, fetch_github_releases, remember, recall |
| `summarize` | Ad-hoc text/file summarization | (direct content injection — ephemeral) |

---

## Database Schema (Implemented)

**Core tables:**
- `projects` — multi-project config (KB repo, ADO org, enabled modes, model)
- `session_state` — composite key (`userId:sessionId:mode`), recovery metadata
- `conversation_log` — message history per session
- `memories` — project-scoped long-term knowledge
- `audit_log` — all user actions with request correlation IDs
- `messages` — full chat history with tool metadata
- `artifacts` — generated UDs, BRDs, HLDs, impl plans, release notes, PRs
- `builds` — long-lived feature pipeline (6 stages)
- `build_artifacts` — linking artifacts to build lifecycle
- `build_approvals` — stage approval audit trail
- `prompt_templates` — per-project prompt versions
- `observer_log` — self-repair diagnostics + actions

---

## APIs & Observability

**Chat endpoints:**
- `POST /api/chat/stream` — SSE streaming
- `DELETE /api/chat/:sessionKey` — cancel session

**Admin endpoints (auth-protected):**
- `GET /api/observe/health` — per-skill health status
- `GET /api/observe/metrics` — performance metrics
- `GET /api/observe/sessions` — active sessions
- `GET /api/observe/circuit-breakers` — circuit state
- `POST /api/observe/circuit-breakers/:service/reset` — manual reset
- `GET /api/admin/prompt-templates` — manage prompts
- `POST /api/admin/prompt-templates` — create version
- `PUT /api/admin/prompt-templates/:id/activate` — activate prompt

**Artifacts:**
- `GET /api/artifacts` — list per project
- `GET /api/artifacts/:id` — retrieve specific artifact
- `PUT /api/artifacts/:id` — edit artifact
- `POST /api/artifacts/:id/export` — PDF export

---

## Technology Stack

| Concern | Tech | Notes |
|---|---|---|
| LLM orchestration | @github/copilot-sdk | SDK session + tool calling; infinite context via event compaction |
| Backend | Express + TypeScript | Middleware stack (auth, validation, rate limit) |
| Frontend | Next.js 15 + React 19 | App Router, SSE streaming, no API key exposed (proxy route) |
| Persistence | SQLite (better-sqlite3) | All state: sessions, history, artifacts, memory, audit, metrics |
| Logging | Pino + pino-http | Structured JSON with request correlation IDs |
| Security | crypto.timingSafeEqual, helmet | Timing-safe auth, OWASP headers |
| Containerization | Docker (optional) | Single Express server, single SQLite file |

---

## Configuration

**Environment variables:**
- `COPILOT_TOKEN` / `GH_TOKEN` — GitHub Copilot auth
- `API_KEYS` — comma-separated API keys (required in production)
- `KB_REPO_OWNER`, `KB_REPO_NAME` — default KB repo
- `ADO_ORG`, `ADO_PROJECT`, `ADO_PAT` — Azure DevOps integration
- `DATABASE_PATH` — SQLite file location (default: `data/sdlc.db`)
- `OBSERVER_MODEL` — internal observer LLM (default: claude-haiku-4.5)
- `CB_FAILURE_THRESHOLD` — circuit breaker failures before open (default: 5)
- `CB_OPEN_DURATION_MS` — circuit open duration (default: 60000)

---

## Demo Ready?

**YES.** Phases 0–4 provide:
- ✅ Full conversational UD creation with multi-project memory
- ✅ Azure DevOps work-item integration + automatic UD attachment
- ✅ BRD creation and HLD generation from requirements
- ✅ Implementation planning + GitHub Copilot coding agent integration
- ✅ Release notes generation
- ✅ Self-healing infrastructure with operator observability
- ✅ Session persistence across restarts
- ✅ Role-locked prompts with 5-layer injection defense
- ✅ Full audit trail

**Commands to run:**
```bash
npm install
npm run dev              # Starts server (4000) + web (3000)
npm run build            # Compile all packages
npm test                 # Run test suite (219 tests)
```

---

## Future Scope (Phase 5+)

**Multi-instance deployment:**
- Redis session affinity metadata (Phase 5)
- PostgreSQL for large-scale deployments (Phase 5)
- Distributed artifact replication

**Advanced features:**
- OAuth/SSO + full RBAC (Phase 5)
- Per-tenant rate limiting
- Custom user-defined agents (AGENT.md files)
- GitHub PR Review integration (separate product)
- Advanced analytics (skill trends, cost attribution)

**These will be addressed in a future sprint or Phase 5 — not needed for MVP demo.**
