#!/usr/bin/env node

/**
 * Database Reset Script
 * 
 * Clears all entries from every table while preserving the database schema.
 * Tables are truncated in dependency order to respect foreign key constraints.
 */

import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const DB_PATH = process.env.SQLITE_PATH || path.resolve(__dirname, "./data/sdlc-copilot.db");

console.log(`🗑️  Clearing all data from database: ${DB_PATH}`);

const db = new Database(DB_PATH);

try {
  // Disable foreign key checks temporarily to allow truncation in any order
  db.pragma("foreign_keys = OFF");

  // Tables to clear (in dependency order for safety)
  const tables = [
    "build_artifacts",
    "build_approvals",
    "builds",
    "artifacts",
    "messages",
    "session_state",
    "memories",
    "audit_log",
    "metrics_snapshots",
    "observer_log",
    "prompt_templates",
    "projects",
    "schema_migrations",
  ];

  // Clear each table
  for (const table of tables) {
    const stmt = db.prepare(`DELETE FROM ${table}`);
    const result = stmt.run();
    console.log(`✓ Cleared ${table} (${result.changes} rows deleted)`);
  }

  // Re-enable foreign key checks
  db.pragma("foreign_keys = ON");

  // Re-seed the default project so a running server can still create builds
  const enabledModes = "chat,ud,sdlc,brd-analyst,impl-plan,coding,release";
  db.prepare(`
    INSERT OR IGNORE INTO projects
      (id, name, kb_repo_owner, kb_repo_name, kb_repo_ref,
       ado_org, ado_project, enabled_modes, model)
    VALUES ('default', 'Default Project', null, null, 'main', null, null, ?, null)
  `).run(enabledModes);
  console.log("✓ Re-seeded default project");

  console.log("\n✅ Database reset complete! All tables are now empty.");
  console.log("   Schema is preserved — tables still exist with their structure.");

} catch (err) {
  console.error("❌ Error clearing database:", err.message);
  process.exit(1);
} finally {
  db.close();
}
