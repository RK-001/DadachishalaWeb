/**
 * Circuit Breaker — Phase 4.4
 *
 * Lightweight, zero-dependency circuit breaker for external APIs
 * (GitHub, Azure DevOps). Three states:
 *   CLOSED    — normal operation; failures are counted
 *   OPEN      — blocking all calls; throws ServiceUnavailableError
 *   HALF_OPEN — testing recovery after open duration expires
 *
 * On circuit OPEN: returns ServiceUnavailableError immediately (no caching).
 * Configuration via env vars:
 *   CB_FAILURE_THRESHOLD  — failures before opening (default: 5)
 *   CB_OPEN_DURATION_MS   — open state duration ms (default: 60 000)
 */

import logger from "./logger.js";

// ─── Error type ────────────────────────────────────────────────────────────────

export class ServiceUnavailableError extends Error {
  readonly code = "CIRCUIT_OPEN" as const;
  readonly service: string;

  constructor(service: string) {
    super(
      `Service "${service}" is temporarily unavailable (circuit breaker open). ` +
        `Please try again in a moment.`
    );
    this.name = "ServiceUnavailableError";
    this.service = service;
  }
}

// ─── State management ──────────────────────────────────────────────────────────

type CircuitState = "closed" | "open" | "half_open";

interface CircuitEntry {
  state: CircuitState;
  failures: number;
  lastFailureAt: number;
  halfOpenAttempts: number;
}

const FAILURE_THRESHOLD = Number(process.env.CB_FAILURE_THRESHOLD) || 5;
const OPEN_DURATION_MS = Number(process.env.CB_OPEN_DURATION_MS) || 60_000;
const HALF_OPEN_MAX_ATTEMPTS = 2;

const circuitMap = new Map<string, CircuitEntry>();

function getEntry(service: string): CircuitEntry {
  if (!circuitMap.has(service)) {
    circuitMap.set(service, {
      state: "closed",
      failures: 0,
      lastFailureAt: 0,
      halfOpenAttempts: 0,
    });
  }
  return circuitMap.get(service)!;
}

function checkBeforeCall(service: string): void {
  const entry = getEntry(service);

  if (entry.state === "open") {
    const elapsed = Date.now() - entry.lastFailureAt;
    if (elapsed >= OPEN_DURATION_MS) {
      entry.state = "half_open";
      entry.halfOpenAttempts = 0;
      logger.info({ service }, "[circuit-breaker] HALF_OPEN — testing recovery");
    } else {
      throw new ServiceUnavailableError(service);
    }
  }
}

function onSuccess(service: string): void {
  const entry = getEntry(service);
  if (entry.state !== "closed") {
    logger.info({ service }, "[circuit-breaker] CLOSED — recovered");
  }
  entry.state = "closed";
  entry.failures = 0;
  entry.halfOpenAttempts = 0;
}

function onFailure(service: string, err: unknown): void {
  const entry = getEntry(service);
  entry.failures++;
  entry.lastFailureAt = Date.now();

  if (entry.state === "half_open") {
    entry.halfOpenAttempts++;
    if (entry.halfOpenAttempts >= HALF_OPEN_MAX_ATTEMPTS) {
      entry.state = "open";
      logger.warn(
        { service, failures: entry.failures },
        "[circuit-breaker] OPEN — half-open test failed"
      );
    }
  } else if (entry.failures >= FAILURE_THRESHOLD) {
    entry.state = "open";
    logger.warn(
      { service, failures: entry.failures, err },
      "[circuit-breaker] OPEN — threshold reached"
    );
  }
}

// ─── Public API ────────────────────────────────────────────────────────────────

/**
 * Wrap an async function with circuit breaker protection.
 * @param service — unique service label for state tracking
 * @param fn      — the async operation to protect
 */
export async function withCircuitBreaker<T>(
  service: string,
  fn: () => Promise<T>
): Promise<T> {
  checkBeforeCall(service);
  try {
    const result = await fn();
    onSuccess(service);
    return result;
  } catch (err) {
    if (err instanceof ServiceUnavailableError) throw err;
    onFailure(service, err);
    throw err;
  }
}

/**
 * Get current state of all circuit breakers (for observability endpoint).
 */
export function getCircuitBreakerStatus(): Record<
  string,
  { state: CircuitState; failures: number; lastFailureAt: string | null }
> {
  const result: Record<
    string,
    { state: CircuitState; failures: number; lastFailureAt: string | null }
  > = {};
  for (const [service, entry] of circuitMap) {
    result[service] = {
      state: entry.state,
      failures: entry.failures,
      lastFailureAt: entry.lastFailureAt
        ? new Date(entry.lastFailureAt).toISOString()
        : null,
    };
  }
  return result;
}

/**
 * Force-reset a circuit breaker to CLOSED (admin recovery action).
 */
export function resetCircuitBreaker(service: string): void {
  circuitMap.set(service, {
    state: "closed",
    failures: 0,
    lastFailureAt: 0,
    halfOpenAttempts: 0,
  });
  logger.info({ service }, "[circuit-breaker] manually reset to CLOSED");
}
