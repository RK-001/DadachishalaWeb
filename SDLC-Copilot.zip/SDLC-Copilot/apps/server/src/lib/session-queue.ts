/**
 * Session Queue
 *
 * Per-session FIFO queue for concurrent message requests (Phase 0.5).
 * Manages slot allocation and waiting lists to enforce serial processing within sessions.
 *
 * At most MAX_QUEUE_DEPTH total slots per session (1 active + up to 4 waiting).
 * An incoming request that would make depth ≥ MAX_QUEUE_DEPTH is rejected 429.
 */

/**
 * Maximum total slots per session: 1 active + 4 waiting.
 * A 6th concurrent request is rejected with HTTP 429.
 */
export const MAX_QUEUE_DEPTH = 5;

/**
 * Set of session keys that currently hold an active slot.
 * Empty for a key means the slot is available.
 */
const activeKeys = new Set<string>();

/**
 * Map of session key → list of unfulfilled slot requests.
 * Resolver receives: true = slot granted, false = cancelled.
 */
const sessionWaiters = new Map<string, Array<(granted: boolean) => void>>();

/**
 * Returns the total queue depth for a session.
 * Includes: 1 if slot is active + number of waiting requests.
 */
export function getSessionQueueDepth(key: string): number {
  return (activeKeys.has(key) ? 1 : 0) + (sessionWaiters.get(key)?.length ?? 0);
}

/**
 * Acquire the processing slot for a session key.
 * - If no slot is active, grants immediately and returns true.
 * - If the slot is active but queue is not full, waits asynchronously.
 * - If queue is already at MAX_QUEUE_DEPTH, caller should reject the request (don't call this).
 *
 * Returns true when the slot is granted; false if cancelled.
 * Caller MUST call releaseSessionSlot() when finished (even on error).
 */
export async function acquireSessionSlot(key: string): Promise<boolean> {
  if (!activeKeys.has(key)) {
    activeKeys.add(key);
    return true; // immediate grant
  }
  return new Promise<boolean>((resolve) => {
    const waiters = sessionWaiters.get(key) ?? [];
    waiters.push(resolve);
    sessionWaiters.set(key, waiters);
  });
}

/**
 * Release the slot and unblock the next FIFO waiter (if any).
 * Called after a request finishes (success or error).
 */
export function releaseSessionSlot(key: string): void {
  const waiters = sessionWaiters.get(key) ?? [];
  const next = waiters.shift();
  if (next) {
    sessionWaiters.set(key, waiters);
    next(true); // grant to next waiter
  } else {
    sessionWaiters.delete(key);
    activeKeys.delete(key);
  }
}

/**
 * Returns true if the given session currently holds the active processing slot.
 * Used by chatAgent.getActiveSessionInfo() to report per-session processing state.
 */
export function isSessionActive(key: string): boolean {
  return activeKeys.has(key);
}

/**
 * Cancel all pending waiters and the active slot for a session.
 * Waiting requests have their acquireSessionSlot() resolved with false (cancelled).
 * Called when destroying a session or when the user cancels.
 */
export function cancelSessionQueue(key: string): void {
  const waiters = sessionWaiters.get(key) ?? [];
  waiters.forEach((resolve) => resolve(false));
  sessionWaiters.delete(key);
  activeKeys.delete(key);
}
