/**
 * Health — Phase 0.5
 *
 * In-memory per-skill and per-tool counters (MetricsService) +
 * periodic health polling (HealthMonitor). Merged from metrics.ts + health-monitor.ts.
 *
 * HealthMonitor polls every 30s. When a skill's error rate exceeds the
 * threshold (≥3 errors AND >50% error rate), it marks the skill DEGRADED
 * in the SkillRegistry. On recovery it marks it HEALTHY.
 *
 * Phase 0.5 — Observability + Self-Healing
 */

import { skillRegistry } from "../agents/registry.js";
import logger from "./logger.js";
import { db } from "./db.js";

// Lazy-import observer to avoid circular dependency at module load time
let _triggerObserver: ((skill: string) => Promise<void>) | null = null;
async function notifyObserver(skill: string): Promise<void> {
  try {
    if (!_triggerObserver) {
      const mod = await import("../agents/observer-agent.js");
      _triggerObserver = mod.triggerObserver;
    }
    void _triggerObserver(skill);
  } catch {
    // observer failure must never affect health monitor
  }
}

// ─── Metrics Types ─────────────────────────────────────────────────────────────

export interface SkillMetrics {
  requestCount: number;
  errorCount: number;
  totalLatencyMs: number;
  requestsWithLatency: number;
  avgLatencyMs: number;
  lastErrorAt: string | null;
}

export interface ErrorEntry {
  timestamp: string;
  skill: string;
  message: string;
  requestId?: string;
}

export interface MetricsSnapshot {
  skills: Record<string, SkillMetrics>;
  toolCallCount: Record<string, number>;
  uptimeSecs: number;
  capturedAt: string;
}

// ─── Ring Buffer ───────────────────────────────────────────────────────────────

const MAX_ERROR_BUFFER = 50;

class RingBuffer<T> {
  private buf: T[] = [];
  private cap: number;

  constructor(capacity: number) {
    this.cap = capacity;
  }

  push(item: T): void {
    if (this.buf.length >= this.cap) this.buf.shift();
    this.buf.push(item);
  }

  all(): T[] {
    return [...this.buf];
  }
}

// ─── MetricsService ────────────────────────────────────────────────────────────

class MetricsService {
  private skillMetrics: Record<string, SkillMetrics> = {};
  private toolCallCount: Record<string, number> = {};
  private errorBuffer = new RingBuffer<ErrorEntry>(MAX_ERROR_BUFFER);
  private startedAt = Date.now();

  private getOrCreateSkill(skill: string): SkillMetrics {
    if (!this.skillMetrics[skill]) {
      this.skillMetrics[skill] = {
        requestCount: 0,
        errorCount: 0,
        totalLatencyMs: 0,
        requestsWithLatency: 0,
        avgLatencyMs: 0,
        lastErrorAt: null,
      };
    }
    return this.skillMetrics[skill];
  }

  recordRequest(skill: string): void {
    this.getOrCreateSkill(skill).requestCount++;
  }

  recordError(skill: string, message: string, requestId?: string): void {
    const m = this.getOrCreateSkill(skill);
    m.errorCount++;
    m.lastErrorAt = new Date().toISOString();
    this.errorBuffer.push({
      timestamp: m.lastErrorAt,
      skill,
      message,
      requestId,
    });
  }

  recordLatency(skill: string, ms: number): void {
    const m = this.getOrCreateSkill(skill);
    m.totalLatencyMs += ms;
    m.requestsWithLatency++;
    m.avgLatencyMs = Math.round(m.totalLatencyMs / m.requestsWithLatency);
  }

  recordToolCall(tool: string): void {
    this.toolCallCount[tool] = (this.toolCallCount[tool] ?? 0) + 1;
  }

  getSnapshot(): MetricsSnapshot {
    return {
      skills: { ...this.skillMetrics },
      toolCallCount: { ...this.toolCallCount },
      uptimeSecs: Math.floor((Date.now() - this.startedAt) / 1000),
      capturedAt: new Date().toISOString(),
    };
  }

  getErrors(): ErrorEntry[] {
    return this.errorBuffer.all();
  }
}

export const metrics = new MetricsService();

// ─── HealthMonitor ─────────────────────────────────────────────────────────────

const POLL_INTERVAL_MS = Number(process.env.HEALTH_MONITOR_INTERVAL_MS) || 30_000;
const ERROR_THRESHOLD_COUNT = 3;

let monitorTimer: NodeJS.Timeout | null = null;

function checkSkillHealth(): void {
  const snapshot = metrics.getSnapshot();

  for (const [mode, skillMetrics] of Object.entries(snapshot.skills)) {
    if (!skillRegistry.isRegistered(mode)) continue;

    const currentHealth = skillRegistry.getHealth(mode);
    const isDegraded = skillMetrics.errorCount >= ERROR_THRESHOLD_COUNT &&
      (skillMetrics.requestCount === 0 ||
        skillMetrics.errorCount / skillMetrics.requestCount > 0.5);

    if (isDegraded && currentHealth !== "degraded") {
      logger.warn(
        { skill: mode, errorCount: skillMetrics.errorCount, requestCount: skillMetrics.requestCount },
        `[health-monitor] Skill "${mode}" DEGRADED`
      );
      skillRegistry.markDegraded(mode);
      void notifyObserver(mode); // Phase 4.1: trigger observer agent (non-blocking)
    } else if (!isDegraded && currentHealth === "degraded") {
      logger.info({ skill: mode }, `[health-monitor] Skill "${mode}" RECOVERED`);
      skillRegistry.markHealthy(mode);
    }
  }
}

export function startHealthMonitor(): void {
  if (monitorTimer) return;
  monitorTimer = setInterval(checkSkillHealth, POLL_INTERVAL_MS);
  monitorTimer.unref();
  logger.info(`[health-monitor] Started (interval: ${POLL_INTERVAL_MS} ms)`);
}

export function stopHealthMonitor(): void {
  if (monitorTimer) {
    clearInterval(monitorTimer);
    monitorTimer = null;
  }
}

// ─── Metrics flush ────────────────────────────────────────────────────────────────────────

const FLUSH_INTERVAL_MS = Number(process.env.METRICS_FLUSH_INTERVAL_MS) || 60_000;
/** Maximum rows to retain in metrics_snapshots (~24 h at 1/min). */
const MAX_SNAPSHOT_ROWS = 1440;

let flushTimer: NodeJS.Timeout | null = null;

function flushMetrics(): void {
  try {
    const snapshot = metrics.getSnapshot();
    db.prepare(`INSERT INTO metrics_snapshots (snapshot) VALUES (?)`)
      .run(JSON.stringify(snapshot));

    // Prune oldest rows beyond retention limit
    db.prepare(
      `DELETE FROM metrics_snapshots WHERE id NOT IN (
         SELECT id FROM metrics_snapshots ORDER BY id DESC LIMIT ?
       )`
    ).run(MAX_SNAPSHOT_ROWS);
  } catch (err: any) {
    logger.error({ err }, "[health] metrics flush error");
  }
}

/**
 * Start periodic flush of in-memory MetricsService counters to the
 * metrics_snapshots SQLite table. No-op if already started.
 */
export function startMetricsFlush(): void {
  if (flushTimer) return;
  flushTimer = setInterval(flushMetrics, FLUSH_INTERVAL_MS);
  flushTimer.unref();
  logger.info(`[health] Metrics flush started (interval: ${FLUSH_INTERVAL_MS} ms)`);
}

export function stopMetricsFlush(): void {
  if (flushTimer) {
    clearInterval(flushTimer);
    flushTimer = null;
  }
}
