/**
 * Pino structured logger + error types — Phase 0.5
 *
 * Singleton logger used across the server. Outputs:
 *   - Pretty-print in development (NODE_ENV !== 'production')
 *   - Plain JSON in production (grep-friendly, ingestible by log aggregators)
 *
 * Also exports AppError and sanitizeError (merged from errors.ts).
 *
 * Phase 0.0 — Security Prerequisite V6 (verbose error suppression)
 * Phase 0.5 — Observability
 */

import pino from "pino";

const isDev = process.env.NODE_ENV !== "production";

export const logger = pino({
  level: process.env.LOG_LEVEL || "info",
  ...(isDev
    ? {
        transport: {
          target: "pino-pretty",
          options: {
            colorize: true,
            translateTime: "HH:MM:ss.l",
            ignore: "pid,hostname",
          },
        },
      }
    : {}),
});

export default logger;

// ─── Error types (merged from errors.ts) ───────────────────────────────────────

export class AppError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly statusCode: number = 500,
    public readonly isOperational: boolean = true
  ) {
    super(message);
    this.name = "AppError";
    Error.captureStackTrace?.(this, AppError);
  }
}

export interface SafeError {
  message: string;
  code: string;
}

export function sanitizeError(err: unknown): SafeError {
  if (err instanceof AppError && err.isOperational) {
    return { message: err.message, code: err.code };
  }
  return { message: "An error occurred. Please try again.", code: "INTERNAL_ERROR" };
}
