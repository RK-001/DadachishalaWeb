/**
 * Artifact store — Phase 1.1
 *
 * Persists generated artifacts (UDs and future: HLDs, test cases, release notes)
 * to the `artifacts` SQLite table. Content is stored as a TEXT column.
 *
 * Auto-increment versioning: if the same filename appears multiple times in a
 * session (e.g. UD revised and re-approved), each save gets a new version number.
 *
 * Security: All queries are parameterized. artifact_type is enforced by a
 * DB CHECK constraint and TypeScript union type — no free-form values accepted.
 *
 * Phase 1.1 — Production Persistence
 */

import { db } from "./db.js";

// ─── Types ─────────────────────────────────────────────────────────────────────

export type ArtifactType = "ud" | "hld" | "test" | "release-notes" | "brd" | "impl-plan";

export interface ArtifactRow {
  id: number;
  session_key: string;
  project_id: string | null;
  filename: string;
  content: string;
  artifact_type: ArtifactType;
  version: number;
  created_at: string;
}

export interface SaveArtifactParams {
  sessionKey: string;
  projectId?: string | null;
  filename: string;
  content: string;
  artifactType: ArtifactType;
  /** Explicit version. If omitted, auto-increments from the highest existing version. */
  version?: number;
}

export interface ListArtifactsParams {
  sessionKey?: string;
  projectId?: string;
  limit?: number;
}

// ─── Version helpers ───────────────────────────────────────────────────────────

/**
 * Returns the highest version number saved for (sessionKey, filename).
 * Returns 0 if no such artifact exists — so version 1 is always the first save.
 */
export function getLatestArtifactVersion(sessionKey: string, filename: string): number {
  const row = db.prepare(`
    SELECT MAX(version) AS max_version FROM artifacts
    WHERE session_key = ? AND filename = ?
  `).get(sessionKey, filename) as { max_version: number | null } | undefined;
  return row?.max_version ?? 0;
}

// ─── Writers ───────────────────────────────────────────────────────────────────

/**
 * Save a new artifact. Automatically increments the version when the same
 * filename already exists in the session. Returns the inserted row id.
 */
export function saveArtifact(params: SaveArtifactParams): number {
  const version =
    params.version ??
    getLatestArtifactVersion(params.sessionKey, params.filename) + 1;

  const result = db.prepare(`
    INSERT INTO artifacts (session_key, project_id, filename, content, artifact_type, version)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    params.sessionKey,
    params.projectId ?? null,
    params.filename,
    params.content,
    params.artifactType,
    version
  );

  return result.lastInsertRowid as number;
}

// ─── Readers ───────────────────────────────────────────────────────────────────

/** Fetch a single artifact by its numeric id. Returns null if not found. */
export function getArtifact(id: number): ArtifactRow | null {
  return (
    db.prepare(`
      SELECT id, session_key, project_id, filename, content, artifact_type, version, created_at
      FROM artifacts WHERE id = ?
    `).get(id) as ArtifactRow | undefined
  ) ?? null;
}

/**
 * List artifacts with optional filters by sessionKey and/or projectId.
 * Results are newest-first. Defaults to 50 rows.
 */
export function listArtifacts(params: ListArtifactsParams = {}): ArtifactRow[] {
  const { sessionKey, projectId, limit = 50 } = params;

  if (sessionKey && projectId) {
    return db.prepare(`
      SELECT id, session_key, project_id, filename, content, artifact_type, version, created_at
      FROM artifacts WHERE session_key = ? AND project_id = ?
      ORDER BY id DESC LIMIT ?
    `).all(sessionKey, projectId, limit) as ArtifactRow[];
  }
  if (sessionKey) {
    return db.prepare(`
      SELECT id, session_key, project_id, filename, content, artifact_type, version, created_at
      FROM artifacts WHERE session_key = ?
      ORDER BY id DESC LIMIT ?
    `).all(sessionKey, limit) as ArtifactRow[];
  }
  if (projectId) {
    return db.prepare(`
      SELECT id, session_key, project_id, filename, content, artifact_type, version, created_at
      FROM artifacts WHERE project_id = ?
      ORDER BY id DESC LIMIT ?
    `).all(projectId, limit) as ArtifactRow[];
  }
  return db.prepare(`
    SELECT id, session_key, project_id, filename, content, artifact_type, version, created_at
    FROM artifacts ORDER BY id DESC LIMIT ?
  `).all(limit) as ArtifactRow[];
}
