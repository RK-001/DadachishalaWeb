/**
 * Build Database — Phase 3
 *
 * Initialises the 3 build-pipeline tables that support the multi-stage
 * BRD → UD → ImplPlan → Coding → Release workflow.
 *
 * Tables:
 *   builds           — one row per feature flowing through the pipeline
 *   build_artifacts  — links each stage to the artifact it produced
 *   build_approvals  — human approval/rejection records per stage
 *
 * Also handles migration of the artifacts table's CHECK constraint to include
 * 'brd' and 'impl-plan' types added in Phase 3.
 *
 * Phase 3 — Multi-stage Build Pipeline
 */

import { db } from "./db.js";
import logger from "./logger.js";

// ─── Schema Init ───────────────────────────────────────────────────────────────

export function initBuildDb(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS builds (
      id           TEXT PRIMARY KEY,
      project_id   TEXT NOT NULL REFERENCES projects(id),
      title        TEXT NOT NULL,
      description  TEXT,
      current_stage TEXT NOT NULL DEFAULT 'brd_intake'
        CHECK(current_stage IN (
          'brd_intake','brd_approved',
          'ud_draft','ud_approved',
          'impl_plan','plan_approved',
          'coding','pr_created',
          'release_docs','completed'
        )),
      status       TEXT NOT NULL DEFAULT 'active'
        CHECK(status IN ('active','paused','failed','completed')),
      created_by   TEXT NOT NULL,
      created_at   TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at   TEXT NOT NULL DEFAULT (datetime('now')),
      released_at  TEXT,
      is_archived  INTEGER NOT NULL DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_builds_project_id ON builds(project_id);
    CREATE INDEX IF NOT EXISTS idx_builds_status ON builds(status, is_archived);

    CREATE TABLE IF NOT EXISTS build_artifacts (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      build_id    TEXT NOT NULL REFERENCES builds(id),
      stage       TEXT NOT NULL,
      artifact_id INTEGER NOT NULL REFERENCES artifacts(id),
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_build_artifacts_build_id ON build_artifacts(build_id);

    CREATE TABLE IF NOT EXISTS build_approvals (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      build_id    TEXT NOT NULL REFERENCES builds(id),
      stage       TEXT NOT NULL,
      approved_by TEXT NOT NULL,
      approved_at TEXT NOT NULL DEFAULT (datetime('now')),
      decision    TEXT NOT NULL
        CHECK(decision IN ('approved','rejected','revision_requested')),
      comments    TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_build_approvals_build_id ON build_approvals(build_id);
  `);

  // Migration: add ado_work_item_id column if not present
  const buildCols = db.prepare(`PRAGMA table_info(builds)`).all() as { name: string }[];
  const hasAdoCol = buildCols.some((c) => c.name === "ado_work_item_id");
  if (!hasAdoCol) {
    db.exec(`ALTER TABLE builds ADD COLUMN ado_work_item_id INTEGER`);
    logger.info("[build-db] Migrated: added ado_work_item_id column to builds");
  }

  // Migrate artifacts CHECK constraint to include phase-3 types
  migrateArtifactsConstraint();

  logger.info("[build-db] Build tables initialised");
}

// ─── Migration ─────────────────────────────────────────────────────────────────

/**
 * Expand the artifacts.artifact_type CHECK constraint to include 'brd' and 'impl-plan'.
 * SQLite does not support ALTER TABLE … ADD CONSTRAINT, so we rename → recreate → repopulate.
 * Idempotent and safe for concurrent test runs:
 *   - If table already has new types → skip
 *   - If _artifacts_phase2 exists (leftover) + artifacts exists → cleanup leftover
 *   - If _artifacts_phase2 exists + no artifacts → recover from leftover
 */
function migrateArtifactsConstraint(): void {
  // Check if migration is already done (new constraint present)
  const artifactsRow = db
    .prepare(`SELECT sql FROM sqlite_master WHERE type='table' AND name='artifacts'`)
    .get() as { sql: string } | undefined;

  // Clean artifacts table already has the new types — skip
  if (artifactsRow?.sql?.includes("impl-plan")) return;
  if (artifactsRow?.sql?.includes("'brd'") && artifactsRow.sql.includes("'impl-plan'")) return;

  // Check for leftover _artifacts_phase2 from a prior migration attempt
  const legacyRow = db
    .prepare(`SELECT sql FROM sqlite_master WHERE type='table' AND name='_artifacts_phase2'`)
    .get() as { sql: string } | undefined;

  if (legacyRow) {
    if (artifactsRow) {
      // artifacts already recreated (migration completed between our two checks) — just clean up
      try { db.exec(`DROP TABLE _artifacts_phase2`); } catch { /* already gone */ }
      return;
    }
    // Recover: artifacts was renamed but new table not created yet
    // Recreate from the leftover
    logger.warn("[build-db] Recovering from incomplete migration …");
  }

  if (!artifactsRow && !legacyRow) return; // artifacts doesn't exist at all — initDb runs first

  logger.info("[build-db] Migrating artifacts table for Phase 3 types …");

  try {
    const migrate = db.transaction(() => {
      if (!legacyRow) {
        // Rename only if not already renamed
        db.exec(`ALTER TABLE artifacts RENAME TO _artifacts_phase2`);
      }

      // Create new artifacts table if it doesn't exist yet
      db.exec(`
        CREATE TABLE IF NOT EXISTS artifacts (
          id            INTEGER PRIMARY KEY AUTOINCREMENT,
          session_key   TEXT NOT NULL,
          project_id    TEXT,
          filename      TEXT NOT NULL,
          content       TEXT NOT NULL,
          artifact_type TEXT NOT NULL
            CHECK(artifact_type IN ('ud','hld','test','release-notes','brd','impl-plan')),
          version       INTEGER NOT NULL DEFAULT 1,
          created_at    TEXT NOT NULL DEFAULT (datetime('now'))
        )
      `);

      db.exec(`
        CREATE INDEX IF NOT EXISTS idx_artifacts_session ON artifacts(session_key);
        CREATE INDEX IF NOT EXISTS idx_artifacts_project ON artifacts(project_id, created_at)
      `);

      db.exec(`
        INSERT OR IGNORE INTO artifacts
          SELECT id, session_key, project_id, filename, content, artifact_type, version, created_at
          FROM _artifacts_phase2
      `);

      db.exec(`DROP TABLE IF EXISTS _artifacts_phase2`);
    });

    migrate();
    logger.info("[build-db] artifacts table migration complete");
  } catch (err: any) {
    logger.warn({ err: err.message }, "[build-db] Migration skipped (already done or concurrent run)");
  }
}
