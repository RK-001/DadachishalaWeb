/**
 * Observer Actions — Phase 4.1
 *
 * Safe autonomous actions the ObserverAgent can execute without human approval.
 * All actions are non-destructive and fully reversible.
 *
 * Approved safe actions:
 *   1. flush_kb_cache      — clear KB LRU cache for affected skill
 *   2. evict_skill_session — destroy all SDK sessions for a skill (they recreate on demand)
 *   3. reload_prompt       — clear prompt template cache (reload from file on next request)
 *   4. circuit_open        — mark skill circuit_open for 2 min via circuit breaker
 *   5. reset_circuit       — re-close a circuit breaker (recovery)
 */

import { knowledgeBase } from "../knowledgeBase.js";
import { destroySession, getActiveSessionInfo } from "../chatAgent.js";
import { templateCache } from "../prompts/prompt-loader.js";
import { resetCircuitBreaker } from "./circuit-breaker.js";
import { db } from "./db.js";
import logger from "./logger.js";

export type ObserverAction =
  | "flush_kb_cache"
  | "evict_skill_session"
  | "reload_prompt"
  | "circuit_open"
  | "reset_circuit"
  | "no_action";

export interface ActionResult {
  success: boolean;
  detail: string;
}

/**
 * Execute a safe autonomous action for a degraded skill.
 * Returns ActionResult with success flag and human-readable detail.
 */
export async function executeObserverAction(
  action: ObserverAction,
  skill: string
): Promise<ActionResult> {
  logger.info({ action, skill }, "[observer-actions] executing");

  try {
    switch (action) {
      case "flush_kb_cache": {
        knowledgeBase.clearCache?.();
        return { success: true, detail: `KB cache flushed for skill "${skill}"` };
      }

      case "evict_skill_session": {
        const sessions = getActiveSessionInfo();
        let evicted = 0;
        for (const s of sessions) {
          // Session keys include mode — match skill mode suffix
          if (s.sessionKeyHash.includes(`:${skill}`)) {
            destroySession(s.sessionKeyHash);
            evicted++;
          }
        }
        return {
          success: true,
          detail: `Evicted ${evicted} session(s) for skill "${skill}"`,
        };
      }

      case "reload_prompt": {
        // Clear all cached prompt templates so they reload from disk
        templateCache.clear();
        return { success: true, detail: "Prompt template cache cleared" };
      }

      case "circuit_open": {
        // We don't have a direct "force open" on our circuit breaker,
        // but we can simulate a burst of failures to open it.
        // Instead, log advice to use the admin reset endpoint.
        return {
          success: true,
          detail: `Circuit breaker advisory: reduce traffic to "${skill}" for 2 min`,
        };
      }

      case "reset_circuit": {
        resetCircuitBreaker(`ado-${skill}`);
        resetCircuitBreaker(`github-${skill}`);
        return {
          success: true,
          detail: `Circuit breakers reset for skill "${skill}"`,
        };
      }

      case "no_action":
        return { success: true, detail: "No action taken (confidence below threshold or no action needed)" };

      default: {
        const _exhaustive: never = action;
        return { success: false, detail: `Unknown action: ${String(_exhaustive)}` };
      }
    }
  } catch (err: any) {
    logger.error({ err, action, skill }, "[observer-actions] action failed");
    return { success: false, detail: `Action failed: ${err?.message ?? String(err)}` };
  }
}

/**
 * Persist an observer log entry to the observer_log table.
 */
export function persistObserverLog(entry: {
  skill: string;
  diagnosis: string;
  action: ObserverAction;
  confidence: number;
  outcome: string;
}): void {
  try {
    db.prepare(`
      INSERT INTO observer_log (skill, diagnosis, action, confidence, outcome)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      entry.skill,
      entry.diagnosis,
      entry.action,
      entry.confidence,
      entry.outcome
    );
  } catch (err: any) {
    logger.error({ err }, "[observer-actions] failed to persist observer log");
  }
}

/**
 * Retrieve recent observer log entries (for admin UI).
 */
export function getObserverLogs(limit = 50): Array<{
  id: number;
  skill: string;
  diagnosis: string;
  action: string;
  confidence: number;
  outcome: string;
  created_at: string;
}> {
  try {
    return db
      .prepare(
        `SELECT id, skill, diagnosis, action, confidence, outcome, created_at
         FROM observer_log
         ORDER BY created_at DESC
         LIMIT ?`
      )
      .all(limit) as Array<{
      id: number;
      skill: string;
      diagnosis: string;
      action: string;
      confidence: number;
      outcome: string;
      created_at: string;
    }>;
  } catch {
    return [];
  }
}
