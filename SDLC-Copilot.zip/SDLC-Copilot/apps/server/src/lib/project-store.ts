/**
 * Project store — Phase 0.4
 *
 * Loads per-project configuration from the SQLite `projects` table.
 * On first startup, seeds a "default" project from the existing env vars
 * so the system works out-of-the-box without any manual DB setup.
 *
 * Phase 0.4 — Multi-project configuration
 * Phase 1    — Migrated to PostgreSQL with full CRUD admin API
 */

import { db } from "./db.js";

// ─── Types ─────────────────────────────────────────────────────────────────────

export interface ProjectConfig {
  id: string;
  name: string;
  kbRepoOwner: string | null;
  kbRepoName: string | null;
  kbRepoRef: string;
  adoOrg: string | null;
  adoProject: string | null;
  /** Modes enabled for this project e.g. ["chat","ud","sdlc"] */
  enabledModes: string[];
  /** Override model for this project; null = use COPILOT_MODEL env */
  model: string | null;
}

interface ProjectRow {
  id: string;
  name: string;
  kb_repo_owner: string | null;
  kb_repo_name: string | null;
  kb_repo_ref: string;
  ado_org: string | null;
  ado_project: string | null;
  enabled_modes: string;
  model: string | null;
}

// ─── In-memory cache ───────────────────────────────────────────────────────────
// Simple per-process cache; cleared on upsert. Phase 1 will add TTL + broadcast.
const projectCache = new Map<string, ProjectConfig | null>();

function rowToConfig(row: ProjectRow): ProjectConfig {
  return {
    id: row.id,
    name: row.name,
    kbRepoOwner: row.kb_repo_owner,
    kbRepoName: row.kb_repo_name,
    kbRepoRef: row.kb_repo_ref ?? "main",
    adoOrg: row.ado_org,
    adoProject: row.ado_project,
    enabledModes: row.enabled_modes
      .split(",")
      .map((m) => m.trim())
      .filter(Boolean),
    model: row.model,
  };
}

// ─── Public API ────────────────────────────────────────────────────────────────

/**
 * Load a project by id. Returns null if not found.
 * Results are cached for the process lifetime (invalidated on upsert).
 */
export function getProject(id: string): ProjectConfig | null {
  if (projectCache.has(id)) return projectCache.get(id)!;

  const row = db
    .prepare(
      `SELECT id, name, kb_repo_owner, kb_repo_name, kb_repo_ref,
              ado_org, ado_project, enabled_modes, model
       FROM projects WHERE id = ?`
    )
    .get(id) as ProjectRow | undefined;

  const config = row ? rowToConfig(row) : null;
  projectCache.set(id, config);
  return config;
}

/**
 * Seed the "default" project from env vars if it doesn't already exist.
 * Called once at server startup after initDb().
 *
 * Uses INSERT OR IGNORE so manual DB changes are never overwritten.
 */
export function upsertDefaultProject(): void {
  const existing = db
    .prepare(`SELECT id FROM projects WHERE id = 'default'`)
    .get();

  if (existing) {
    console.log("[project-store] Default project already exists — skipping seed");
    return;
  }

  const enabledModes = "chat,ud,sdlc,brd-analyst,impl-plan,coding,release";
  db.prepare(`
    INSERT OR IGNORE INTO projects
      (id, name, kb_repo_owner, kb_repo_name, kb_repo_ref,
       ado_org, ado_project, enabled_modes, model)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    "default",
    process.env.KB_PROJECT_NAME || "Default Project",
    process.env.KB_REPO_OWNER || null,
    process.env.KB_REPO_NAME || null,
    process.env.KB_REPO_REF || "main",
    process.env.ADO_ORG || null,
    process.env.ADO_PROJECT || null,
    enabledModes,
    process.env.COPILOT_MODEL || null
  );

  // Invalidate cache after write
  projectCache.delete("default");
  console.log("[project-store] Default project seeded from env vars");
}

/** Force-refresh the in-process cache for a project id. */
export function invalidateProjectCache(id: string): void {
  projectCache.delete(id);
}

// ─── Admin CRUD ────────────────────────────────────────────────────────────────

/** Return all projects in the database (not cached — always reads from DB). */
export function listProjects(): ProjectConfig[] {
  const rows = db.prepare(`
    SELECT id, name, kb_repo_owner, kb_repo_name, kb_repo_ref,
           ado_org, ado_project, enabled_modes, model
    FROM projects ORDER BY name ASC
  `).all() as ProjectRow[];
  return rows.map(rowToConfig);
}

/** Create a new project. Throws if the id already exists. */
export function createProject(config: {
  id: string;
  name: string;
  kbRepoOwner?: string | null;
  kbRepoName?: string | null;
  kbRepoRef?: string;
  adoOrg?: string | null;
  adoProject?: string | null;
  enabledModes?: string[];
  model?: string | null;
}): void {
  db.prepare(`
    INSERT INTO projects
      (id, name, kb_repo_owner, kb_repo_name, kb_repo_ref,
       ado_org, ado_project, enabled_modes, model)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    config.id,
    config.name,
    config.kbRepoOwner ?? null,
    config.kbRepoName ?? null,
    config.kbRepoRef ?? "main",
    config.adoOrg ?? null,
    config.adoProject ?? null,
    (config.enabledModes ?? ["sdlc"]).join(","),
    config.model ?? null
  );
  // Invalidate cache so next getProject() reads from DB
  projectCache.delete(config.id);
}

/**
 * Update an existing project by id.
 * Only the fields present in `partial` are updated; others remain unchanged.
 * Returns true if the row was found and updated, false if the id doesn't exist.
 */
export function updateProject(
  id: string,
  partial: Partial<{
    name: string;
    kbRepoOwner: string | null;
    kbRepoName: string | null;
    kbRepoRef: string;
    adoOrg: string | null;
    adoProject: string | null;
    enabledModes: string[];
    model: string | null;
  }>
): boolean {
  // Build SET clause dynamically from provided fields
  const setClauses: string[] = [];
  const values: unknown[] = [];

  if ("name" in partial) {
    setClauses.push("name = ?");
    values.push(partial.name ?? null);
  }
  if ("kbRepoOwner" in partial) {
    setClauses.push("kb_repo_owner = ?");
    values.push(partial.kbRepoOwner ?? null);
  }
  if ("kbRepoName" in partial) {
    setClauses.push("kb_repo_name = ?");
    values.push(partial.kbRepoName ?? null);
  }
  if ("kbRepoRef" in partial) {
    setClauses.push("kb_repo_ref = ?");
    values.push(partial.kbRepoRef ?? "main");
  }
  if ("adoOrg" in partial) {
    setClauses.push("ado_org = ?");
    values.push(partial.adoOrg ?? null);
  }
  if ("adoProject" in partial) {
    setClauses.push("ado_project = ?");
    values.push(partial.adoProject ?? null);
  }
  if ("enabledModes" in partial && partial.enabledModes) {
    setClauses.push("enabled_modes = ?");
    values.push(partial.enabledModes.join(","));
  }
  if ("model" in partial) {
    setClauses.push("model = ?");
    values.push(partial.model ?? null);
  }

  if (setClauses.length === 0) return false; // nothing to update

  values.push(id); // WHERE clause
  const result = db.prepare(
    `UPDATE projects SET ${setClauses.join(", ")} WHERE id = ?`
  ).run(...values);

  if (result.changes > 0) {
    projectCache.delete(id);
    return true;
  }
  return false;
}

/**
 * Delete a project by id.
 * The default project cannot be deleted (returns false).
 * Returns true if a row was deleted.
 */
export function deleteProject(id: string): boolean {
  if (id === "default") return false; // guard: default project is immutable

  const result = db.prepare(`DELETE FROM projects WHERE id = ?`).run(id);
  if (result.changes > 0) {
    projectCache.delete(id);
    return true;
  }
  return false;
}
