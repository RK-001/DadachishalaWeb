/**
 * Admin Authorization Middleware — Phase 4.2
 *
 * Provides an extra authentication layer for admin and observe endpoints.
 * If ADMIN_API_KEYS env var is set, only those keys are accepted on admin
 * routes. If unset, falls back to validating against regular API_KEYS
 * (backward-compatible single-key dev setup).
 *
 * Usage: mount as a middleware before admin/observe routers in index.ts.
 */

import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";

const ADMIN_KEYS_RAW = (process.env.ADMIN_API_KEYS || "")
  .split(",")
  .map((k) => k.trim())
  .filter(Boolean);

const REGULAR_KEYS_RAW = (process.env.API_KEYS || "")
  .split(",")
  .map((k) => k.trim())
  .filter(Boolean);

// If ADMIN_API_KEYS not set, use regular API_KEYS for backward compatibility
const EFFECTIVE_ADMIN_KEYS = new Set<string>(
  ADMIN_KEYS_RAW.length > 0 ? ADMIN_KEYS_RAW : REGULAR_KEYS_RAW
);

const ADMIN_AUTH_ENFORCED = EFFECTIVE_ADMIN_KEYS.size > 0;

function timingSafeMatch(candidate: string, keySet: Set<string>): boolean {
  let matched = false;
  for (const key of keySet) {
    if (candidate.length === key.length) {
      try {
        if (crypto.timingSafeEqual(Buffer.from(candidate), Buffer.from(key))) {
          matched = true;
          // Do NOT break — iterate all to avoid timing differences
        }
      } catch {
        // length mismatch or encoding error — not a match
      }
    }
  }
  return matched;
}

/**
 * Middleware: require admin-level API key.
 * Applied to /api/admin/* and /api/observe/* routes.
 */
export function requireAdminKey(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  if (!ADMIN_AUTH_ENFORCED) {
    return next();
  }

  const rawKey = req.headers["x-api-key"];
  const authHeader = req.headers.authorization;

  let candidate: string | null = null;
  if (typeof rawKey === "string" && rawKey.length > 0) {
    candidate = rawKey;
  } else if (
    typeof authHeader === "string" &&
    authHeader.startsWith("Bearer ")
  ) {
    candidate = authHeader.slice(7);
  }

  if (!candidate) {
    res.status(401).json({ error: "Admin authentication required" });
    return;
  }

  if (timingSafeMatch(candidate, EFFECTIVE_ADMIN_KEYS)) {
    return next();
  }

  res.status(403).json({ error: "Forbidden — admin privileges required" });
}
