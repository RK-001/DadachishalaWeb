/**
 * EventBus — Phase 2.2
 *
 * Typed in-process event bus that decouples SSE writing, message persistence,
 * and metrics collection from route handlers.
 *
 * Design principles:
 *   - Node.js native EventEmitter (no additional npm dependency)
 *   - Each handler wrapped in a fault boundary — one crash doesn't kill others
 *   - `subscribeForSession()` is the primary API for per-request handlers
 *   - `subscribe()` is for global handlers (metrics, etc.) that live forever
 *   - Unsubscribe functions returned for all subscriptions (no leaks)
 */

import { EventEmitter } from "events";
import type {
  UDFilePayload,
  ADOWorkItem,
  UDAttachedPayload,
  ArtifactSavedPayload,
  ArtifactDownloadPayload,
} from "@sdlc-copilot/shared";
import logger from "./logger.js";

// ─── Event Catalogue ──────────────────────────────────────────────────────────

export type SkillEventType =
  | "chunk"
  | "tool_start"
  | "tool_complete"
  | "ud_file_ready"
  | "artifact_download_ready"
  | "work_item_loaded"
  | "ud_attached"
  | "artifact_saved"
  | "skill_fallback"
  | "session_evicted"
  | "done"
  | "error"
  | "status";

// ── Per-event data shapes ─────────────────────────────────────────────────────

export interface ChunkData          { content: string }
export interface ToolStartData      { toolName: string; toolCallId: string; label: string }
export interface ToolCompleteData   { toolName: string; toolCallId: string; label: string; success: boolean; latencyMs: number | undefined; result?: { content?: string } }
export interface ArtifactSavedData  { buildId: string; stage: string; filename: string }
export interface SkillFallbackData  { from: string; to: string }
export interface SessionEvictedData { reason: string }
export interface DoneData           { latencyMs: number; mode: string }
export interface ErrorData          { message: string; code?: string }
export interface StatusData         { message: string }

// ── Discriminated union for full type safety ──────────────────────────────────

export type SkillEventMap = {
  chunk:                    ChunkData;
  tool_start:               ToolStartData;
  tool_complete:            ToolCompleteData;
  ud_file_ready:            UDFilePayload;
  artifact_download_ready:  ArtifactDownloadPayload;
  work_item_loaded:         ADOWorkItem;
  ud_attached:              UDAttachedPayload;
  artifact_saved:           ArtifactSavedPayload;
  skill_fallback:  SkillFallbackData;
  session_evicted: SessionEvictedData;
  done:            DoneData;
  error:           ErrorData;
  status:          StatusData;
};

/** A typed skill event emitted on the EventBus */
export interface SkillEvent<T extends SkillEventType = SkillEventType> {
  type: T;
  sessionKey: string;
  requestId: string | undefined;
  timestamp: string;
  data: SkillEventMap[T];
}

export type AnySkillEvent = SkillEvent<SkillEventType>;

export type SkillEventHandler = (event: AnySkillEvent) => void;

// ─── EventBus implementation ──────────────────────────────────────────────────

const INTERNAL_EVENT = "skill_event";
const MAX_LISTENERS = 200; // generous limit for concurrent sessions + global handlers

class EventBus {
  private readonly emitter: EventEmitter;

  constructor() {
    this.emitter = new EventEmitter();
    this.emitter.setMaxListeners(MAX_LISTENERS);
  }

  /**
   * Emit a typed skill event to all subscribers.
   */
  emit<T extends SkillEventType>(
    type: T,
    sessionKey: string,
    data: SkillEventMap[T],
    requestId?: string
  ): void {
    const event: SkillEvent<T> = {
      type,
      sessionKey,
      requestId,
      timestamp: new Date().toISOString(),
      data,
    };
    this.emitter.emit(INTERNAL_EVENT, event as AnySkillEvent);
  }

  /**
   * Subscribe to ALL events on the bus (global handler).
   * Returns an unsubscribe function.
   */
  subscribe(handler: SkillEventHandler): () => void {
    const wrapped = this.wrapHandler(handler, "global");
    this.emitter.on(INTERNAL_EVENT, wrapped);
    return () => this.emitter.off(INTERNAL_EVENT, wrapped);
  }

  /**
   * Subscribe to events for a SPECIFIC session only.
   * Returns an unsubscribe function. Call it on SSE connection close / done.
   */
  subscribeForSession(
    sessionKey: string,
    handler: SkillEventHandler
  ): () => void {
    const wrapped = this.wrapHandler(
      (event) => {
        if (event.sessionKey === sessionKey) handler(event);
      },
      sessionKey
    );
    this.emitter.on(INTERNAL_EVENT, wrapped);
    return () => this.emitter.off(INTERNAL_EVENT, wrapped);
  }

  /** Number of active listeners (useful for tests + diagnostics) */
  get listenerCount(): number {
    return this.emitter.listenerCount(INTERNAL_EVENT);
  }

  /**
   * Wraps a handler so that one handler's crash doesn't kill others.
   * Errors are logged but NOT re-thrown.
   */
  private wrapHandler(
    handler: SkillEventHandler,
    context: string
  ): SkillEventHandler {
    return (event: AnySkillEvent) => {
      try {
        handler(event);
      } catch (err) {
        logger.error(
          { err, context, eventType: event.type, sessionKey: event.sessionKey },
          "[event-bus] Handler error (isolated)"
        );
      }
    };
  }
}

// ─── Singleton ────────────────────────────────────────────────────────────────

/** Singleton EventBus. Import this throughout the server. */
export const eventBus = new EventBus();

/**
 * Export class for testing — each test can create a fresh isolated instance.
 */
export { EventBus };
