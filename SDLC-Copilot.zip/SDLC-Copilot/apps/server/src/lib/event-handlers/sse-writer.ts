/**
 * SSE Writer handler — Phase 2.2
 *
 * Subscribes to the EventBus for a specific session and formats
 * SkillEvents into SSE `data:` lines sent to the HTTP response.
 *
 * Responsibilities:
 *   - Format each SkillEvent as a ChatStreamEvent SSE frame
 *   - Manage heartbeat (20s) to prevent proxy/LB timeouts
 *   - Provide a cleanup function to unsubscribe on client disconnect
 *
 * One createSSEWriter() call per request. The returned cleanup()
 * must be called on res.close() or after the "done"/"error" event fires.
 */

import type { Response } from "express";
import { eventBus } from "../event-bus.js";
import type { AnySkillEvent, SkillEventType } from "../event-bus.js";
import logger from "../logger.js";

// ─── Helpers ──────────────────────────────────────────────────────────────────

const HEARTBEAT_INTERVAL_MS = Number(process.env.SSE_HEARTBEAT_MS) || 20_000;

/** Write a single SSE frame. Silently ignores write errors on closed responses. */
function sseWrite(res: Response, type: string, data: string): void {
  try {
    res.write(`data: ${JSON.stringify({ type, data })}\n\n`);
  } catch {
    // Response already closed
  }
}

// ─── SSE event formatting ─────────────────────────────────────────────────────

/**
 * Map a SkillEvent to an SSE (type, data) pair.
 * Returns null for events that should not be forwarded to the browser
 * (e.g. internal events like skill_fallback, session_evicted are
 * converted to a "status" message instead).
 */
function formatEvent(event: AnySkillEvent): { type: string; data: string } | null {
  const { type } = event;

  switch (type as SkillEventType) {
    case "chunk":
      return { type: "chunk", data: (event.data as { content: string }).content };

    case "tool_start":
      return { type: "tool_start", data: (event.data as { label: string }).label };

    case "tool_complete": {
      const d = event.data as { label: string; success: boolean; result?: { content?: string } };

      // For work_item_loaded: emit the structured payload before the tool_complete status
      if (d.label.startsWith("fetch_azure_work_item:") && d.success && d.result?.content) {
        // This is handled specially in createSSEWriter to emit two events
        return { type: "tool_complete_with_work_item", data: JSON.stringify(d) };
      }
      if (d.label.startsWith("attach_ud_to_work_item:") && d.success && d.result?.content) {
        return { type: "tool_complete_with_attachment", data: JSON.stringify(d) };
      }
      // Generic tool_complete message
      const label = (d.label || "file");
      const msg = d.success ? `Loaded ${label}` : `Failed to load ${label}`;
      return { type: "tool_complete", data: msg };
    }

    case "ud_file_ready":
      return { type: "ud_file_ready", data: JSON.stringify(event.data) };

    case "artifact_download_ready":
      return { type: "artifact_download_ready", data: JSON.stringify(event.data) };

    case "work_item_loaded":
      return { type: "work_item_loaded", data: JSON.stringify(event.data) };

    case "ud_attached":
      return { type: "ud_attached", data: JSON.stringify(event.data) };

    case "artifact_saved":
      return { type: "artifact_saved", data: JSON.stringify(event.data) };

    case "done":
      return { type: "done", data: "" };

    case "error":
      return { type: "error", data: (event.data as { message: string }).message };

    case "status":
      return { type: "status", data: (event.data as { message: string }).message };

    case "skill_fallback": {
      const d = event.data as { from: string; to: string };
      return { type: "status", data: `Routing to fallback mode (${d.to}) due to skill degradation.` };
    }

    case "session_evicted":
      return { type: "status", data: "Session was reset and will be recreated on next message." };

    default:
      return null;
  }
}

// ─── Public factory ───────────────────────────────────────────────────────────

/**
 * Attach an SSE writer to the given response for the given session.
 *
 * @returns cleanup  Call this when the SSE connection closes or on "done"/"error".
 */
export function createSSEWriter(res: Response, sessionKey: string): () => void {
  let heartbeatTimer: ReturnType<typeof setInterval> | null = setInterval(() => {
    try { res.write(": keepalive\n\n"); } catch { /* closed */ }
  }, HEARTBEAT_INTERVAL_MS);

  const unsubscribe = eventBus.subscribeForSession(sessionKey, (event) => {
    const formatted = formatEvent(event);
    if (!formatted) return;

    const { type } = formatted;

    // ── Special handling: tool_complete events that must emit extra SSE events first
    if (type === "tool_complete_with_work_item") {
      try {
        const d = JSON.parse(formatted.data) as { label: string; success: boolean; result: { content: string } };
        const workItem = JSON.parse(d.result.content);
        sseWrite(res, "work_item_loaded", JSON.stringify(workItem));
        const id = d.label.split(":")[1];
        sseWrite(res, "tool_complete", d.success ? `Loaded Work Item #${id}` : `Failed to fetch Work Item #${id}`);
      } catch {
        // Swallow — LLM still received the data
      }
      return;
    }

    if (type === "tool_complete_with_attachment") {
      try {
        const d = JSON.parse(formatted.data) as { label: string; success: boolean; result: { content: string } };
        const attachInfo = JSON.parse(d.result.content);
        sseWrite(res, "ud_attached", JSON.stringify(attachInfo));
        const id = d.label.split(":")[1];
        sseWrite(res, "tool_complete", d.success ? `UD attached to Work Item #${id}` : `Failed to attach UD to Work Item #${id}`);
      } catch {
        // Swallow
      }
      return;
    }

    sseWrite(res, formatted.type, formatted.data);

    // Stop heartbeat and end response after terminal events
    if (type === "done" || type === "error") {
      if (heartbeatTimer) {
        clearInterval(heartbeatTimer);
        heartbeatTimer = null;
      }
      try { res.end(); } catch { /* already ended */ }
    }
  });

  logger.debug({ sessionKey }, "[sse-writer] Attached");

  return () => {
    if (heartbeatTimer) {
      clearInterval(heartbeatTimer);
      heartbeatTimer = null;
    }
    unsubscribe();
    logger.debug({ sessionKey }, "[sse-writer] Detached");
  };
}
