/**
 * Metrics Collector handler — Phase 2.2
 *
 * A global EventBus subscriber that maps SkillEvents to MetricsService calls
 * and writes audit_log entries for tool completions.
 *
 * Lifetime: registered once on server startup, lives forever.
 *           Call initMetricsCollector() from index.ts.
 *
 * Replaces the direct metrics.* and auditLog() calls that were inline in
 * routes/chat.ts before the EventBus refactor.
 */

import { eventBus } from "../event-bus.js";
import type {
  ToolStartData,
  ToolCompleteData,
  DoneData,
  ErrorData,
} from "../event-bus.js";
import { metrics } from "../health.js";
import { auditLog } from "../db.js";
import logger from "../logger.js";

// ─── Per-session mode tracking ─────────────────────────────────────────────────
//
// We need the mode when recording done/error events, but those events carry
// mode in DoneData. However, we also need to record per-request mode in metrics.
// The EventBus emits DoneData.mode, so we use that directly.

// ─── Initializer ──────────────────────────────────────────────────────────────

let initialized = false;

/**
 * Register the global metrics + audit handler on the EventBus.
 * Idempotent — safe to call multiple times (only registers once).
 */
export function initMetricsCollector(): void {
  if (initialized) return;
  initialized = true;

  eventBus.subscribe((event) => {
    const { type, sessionKey, requestId } = event;

    switch (type) {
      case "tool_start": {
        const { toolName } = event.data as ToolStartData;
        metrics.recordToolCall(toolName);
        break;
      }

      case "tool_complete": {
        const d = event.data as ToolCompleteData;
        // Structured audit entry for every tool completion (preserves Phase 1.2 behavior)
        auditLog({
          action: "tool_call",
          userId: sessionKey.split(":")[0], // userId is first segment of composite key
          requestId,
          resource: d.toolName,
          details: {
            toolCallId: d.toolCallId,
            success: d.success,
            latencyMs: d.latencyMs,
            sessionKey,
          },
        });
        break;
      }

      case "done": {
        const { latencyMs, mode } = event.data as DoneData;
        metrics.recordLatency(mode, latencyMs);
        break;
      }

      case "error": {
        // Extract mode from sessionKey suffix (last segment)
        const segments = sessionKey.split(":");
        const mode = segments[segments.length - 1] ?? "unknown";
        const { message } = event.data as ErrorData;
        metrics.recordError(mode, message, requestId);
        break;
      }

      default:
        break; // Other event types not relevant to metrics
    }
  });

  logger.info("[metrics-collector] Global handler registered");
}
