/**
 * Message Persister handler — Phase 2.2
 *
 * Subscribes to the EventBus and persists conversation turns to the messages
 * table (via message-store.ts).
 *
 * Per-session lifecycle:
 *   - Call createMessagePersister(sessionKey, meta) when a new request starts
 *   - Accumulates assistant text chunks until "done" fires
 *   - On "done": saves the full assistant message and any recorded tool events
 *   - Automatically unsubscribes on "done" or "error" (no leaks)
 *
 * Non-fatal: write failures are logged but never thrown into the request pipeline.
 */

import { eventBus } from "../event-bus.js";
import type { ToolCompleteData, DoneData, ErrorData } from "../event-bus.js";
import { saveMessage } from "../message-store.js";
import logger from "../logger.js";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface MessagePersisterMeta {
  userIdHash: string;
  projectId: string;
  mode: string;
}

// ─── Per-request persister ────────────────────────────────────────────────────

/**
 * Creates a short-lived subscription that accumulates assistant chunks and
 * persists the full turn on completion.
 *
 * @returns cleanup  Called automatically on done/error. You can also call
 *                   it manually if the client disconnects before done fires.
 */
export function createMessagePersister(
  sessionKey: string,
  meta: MessagePersisterMeta
): () => void {
  let assistantContent = "";

  const unsubscribe = eventBus.subscribeForSession(sessionKey, (event) => {
    const { type } = event;

    if (type === "chunk") {
      assistantContent += (event.data as { content: string }).content;
      return;
    }

    if (type === "done") {
      const { latencyMs } = event.data as DoneData;
      // Persist accumulated assistant message
      if (assistantContent) {
        saveMessage({
          sessionKey,
          userIdHash: meta.userIdHash,
          projectId: meta.projectId,
          role: "assistant",
          content: assistantContent,
          mode: meta.mode,
        });
        logger.debug({ sessionKey, chars: assistantContent.length, latencyMs }, "[message-persister] Saved assistant turn");
      }
      unsubscribe();
      return;
    }

    if (type === "error") {
      const { message } = event.data as ErrorData;
      logger.warn({ sessionKey, message }, "[message-persister] Stream error — no assistant message saved");
      unsubscribe();
      return;
    }
  });

  return () => {
    unsubscribe();
  };
}
