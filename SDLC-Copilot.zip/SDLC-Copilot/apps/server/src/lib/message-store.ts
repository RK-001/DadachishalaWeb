/**
 * Message store — Phase 1.1 → Phase 2.2
 *
 * Richer per-turn message storage backed by the `messages` table (added in Phase 1).
 * Stores role, content, mode, tool_name, and tool_args per turn.
 *
 * Security: All queries use parameterized statements. Write failures are
 * non-fatal (logged but never bubble up to the request pipeline).
 *
 * Phase 2.2 — conversation_log table eliminated; messages table is now the single source
 * of truth for conversation history, session recovery, and analytics queries.
 */

import { db } from "./db.js";

// ─── Types ─────────────────────────────────────────────────────────────────────

export interface MessageRow {
  id: number;
  session_key: string;
  user_id_hash: string | null;
  project_id: string | null;
  role: string;
  content: string | null;
  mode: string;
  tool_name: string | null;
  tool_args: string | null;
  created_at: string;
}

export interface SaveMessageParams {
  sessionKey: string;
  userIdHash?: string | null;
  projectId?: string | null;
  role: "user" | "assistant" | "tool";
  content?: string | null;
  mode: string;
  toolName?: string | null;
  toolArgs?: Record<string, unknown> | null;
}

// ─── Writers ───────────────────────────────────────────────────────────────────

/**
 * Persist a single conversation turn.
 * Non-fatal — a write failure must never break the request pipeline.
 */
export function saveMessage(params: SaveMessageParams): void {
  try {
    db.prepare(`
      INSERT INTO messages
        (session_key, user_id_hash, project_id, role, content, mode, tool_name, tool_args)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      params.sessionKey,
      params.userIdHash ?? null,
      params.projectId ?? null,
      params.role,
      params.content ?? null,
      params.mode,
      params.toolName ?? null,
      params.toolArgs ? JSON.stringify(params.toolArgs) : null
    );
  } catch (err: any) {
    console.error("[message-store] saveMessage error:", err.message);
  }
}

// ─── Readers ───────────────────────────────────────────────────────────────────

/**
 * Load all turns for a session in chronological order.
 * Used by the admin history endpoint and conversation sidebar (Phase 4).
 */
export function getMessages(sessionKey: string, limit = 100): MessageRow[] {
  return db.prepare(`
    SELECT id, session_key, user_id_hash, project_id, role, content, mode, tool_name, tool_args, created_at
    FROM messages
    WHERE session_key = ?
    ORDER BY created_at ASC
    LIMIT ?
  `).all(sessionKey, limit) as MessageRow[];
}

/**
 * Load recent messages across all sessions for a project.
 * Results are newest-first for admin list views.
 */
export function getMessagesByProject(projectId: string, limit = 100): MessageRow[] {
  return db.prepare(`
    SELECT id, session_key, user_id_hash, project_id, role, content, mode, tool_name, tool_args, created_at
    FROM messages
    WHERE project_id = ?
    ORDER BY created_at DESC
    LIMIT ?
  `).all(projectId, limit) as MessageRow[];
}
