/**
 * Build Store — Phase 3
 *
 * CRUD layer for the build pipeline tables:
 *   builds, build_artifacts, build_approvals
 *
 * All queries are parameterized (zero string interpolation).
 * Phase 3 — Multi-stage Build Pipeline
 */

import { randomUUID } from "crypto";
import { db } from "./db.js";
import logger from "./logger.js";

// ─── Types ─────────────────────────────────────────────────────────────────────

export type BuildStage =
  | "brd_intake"
  | "brd_approved"
  | "ud_draft"
  | "ud_approved"
  | "impl_plan"
  | "plan_approved"
  | "coding"
  | "pr_created"
  | "release_docs"
  | "completed";

export type BuildStatus = "active" | "paused" | "failed" | "completed";
export type ApprovalDecision = "approved" | "rejected" | "revision_requested";

export interface Build {
  id: string;
  projectId: string;
  title: string;
  description: string | null;
  adoWorkItemId: number | null;
  currentStage: BuildStage;
  status: BuildStatus;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  releasedAt: string | null;
  isArchived: boolean;
}

export interface BuildArtifactLink {
  id: number;
  buildId: string;
  stage: string;
  artifactId: number;
  createdAt: string;
}

export interface BuildApproval {
  id: number;
  buildId: string;
  stage: string;
  approvedBy: string;
  approvedAt: string;
  decision: ApprovalDecision;
  comments: string | null;
}

// ─── Row Mapping ───────────────────────────────────────────────────────────────

interface BuildRow {
  id: string;
  project_id: string;
  title: string;
  description: string | null;
  ado_work_item_id: number | null;
  current_stage: string;
  status: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  released_at: string | null;
  is_archived: number;
}

function mapBuild(row: BuildRow): Build {
  return {
    id: row.id,
    projectId: row.project_id,
    title: row.title,
    description: row.description,
    adoWorkItemId: row.ado_work_item_id ?? null,
    currentStage: row.current_stage as BuildStage,
    status: row.status as BuildStatus,
    createdBy: row.created_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    releasedAt: row.released_at,
    isArchived: row.is_archived === 1,
  };
}

// ─── Build CRUD ────────────────────────────────────────────────────────────────

export interface CreateBuildParams {
  projectId: string;
  title: string;
  description?: string | null;
  adoWorkItemId?: number | null;
  createdBy: string;
}

/** Create a new build in the `brd_intake` stage. Returns the created Build. */
export function createBuild(params: CreateBuildParams): Build {
  const id = randomUUID();
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO builds (id, project_id, title, description, ado_work_item_id, current_stage, status, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, 'brd_intake', 'active', ?, ?, ?)
  `).run(
    id,
    params.projectId,
    params.title,
    params.description ?? null,
    params.adoWorkItemId ?? null,
    params.createdBy,
    now,
    now
  );

  logger.info({ buildId: id, projectId: params.projectId }, "[build-store] Build created");
  return getBuild(id)!;
}

/** Fetch a single build by ID. Returns null if not found or archived. */
export function getBuild(id: string): Build | null {
  const row = db
    .prepare(`SELECT * FROM builds WHERE id = ? AND is_archived = 0`)
    .get(id) as BuildRow | undefined;
  return row ? mapBuild(row) : null;
}

/** List builds for a project, optionally filtered by status. */
export function listBuilds(params: {
  projectId?: string;
  status?: BuildStatus;
  includeArchived?: boolean;
  limit?: number;
  offset?: number;
}): Build[] {
  const {
    projectId,
    status,
    includeArchived = false,
    limit = 50,
    offset = 0,
  } = params;

  let sql = `SELECT * FROM builds WHERE 1=1`;
  const args: unknown[] = [];

  if (!includeArchived) {
    sql += ` AND is_archived = 0`;
  }
  if (projectId) {
    sql += ` AND project_id = ?`;
    args.push(projectId);
  }
  if (status) {
    sql += ` AND status = ?`;
    args.push(status);
  }

  sql += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
  args.push(limit, offset);

  const rows = db.prepare(sql).all(...args) as BuildRow[];
  return rows.map(mapBuild);
}

/** Update the current stage of a build. Also touches updated_at. */
export function updateBuildStage(buildId: string, newStage: BuildStage): void {
  db.prepare(`
    UPDATE builds SET current_stage = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(newStage, buildId);
  logger.info({ buildId, newStage }, "[build-store] Stage updated");
}

/** Update build status. */
export function updateBuildStatus(buildId: string, status: BuildStatus): void {
  const extra = status === "completed"
    ? `, released_at = datetime('now')`
    : "";
  db.prepare(`
    UPDATE builds SET status = ?${extra}, updated_at = datetime('now')
    WHERE id = ?
  `).run(status, buildId);
}

/** Soft-delete (archive) a build. */
export function archiveBuild(buildId: string): void {
  db.prepare(`
    UPDATE builds SET is_archived = 1, updated_at = datetime('now') WHERE id = ?
  `).run(buildId);
  logger.info({ buildId }, "[build-store] Build archived");
}

// ─── Build Artifacts ───────────────────────────────────────────────────────────

/**
 * Link an artifact (from the `artifacts` table) to a build stage.
 * Called by the build-artifact tool after saving via artifact-store.
 */
export function linkArtifactToBuild(
  buildId: string,
  stage: string,
  artifactId: number
): void {
  db.prepare(`
    INSERT INTO build_artifacts (build_id, stage, artifact_id)
    VALUES (?, ?, ?)
  `).run(buildId, stage, artifactId);
  logger.info({ buildId, stage, artifactId }, "[build-store] Artifact linked");
}

/** Get the artifact ID linked to a specific build stage. Returns null if none. */
export function getBuildArtifactIdForStage(
  buildId: string,
  stage: string
): number | null {
  const row = db
    .prepare(
      `SELECT artifact_id FROM build_artifacts WHERE build_id = ? AND stage = ?
       ORDER BY created_at DESC LIMIT 1`
    )
    .get(buildId, stage) as { artifact_id: number } | undefined;
  return row?.artifact_id ?? null;
}

/** Get all artifact links for a build. */
export function getBuildArtifactLinks(buildId: string): BuildArtifactLink[] {
  return db
    .prepare(`
      SELECT id, build_id as buildId, stage, artifact_id as artifactId, created_at as createdAt
      FROM build_artifacts WHERE build_id = ? ORDER BY created_at ASC
    `)
    .all(buildId) as BuildArtifactLink[];
}

// ─── Build Approvals ───────────────────────────────────────────────────────────

export interface AddApprovalParams {
  buildId: string;
  stage: string;
  approvedBy: string;
  decision: ApprovalDecision;
  comments?: string | null;
}

/** Record an approval or rejection for a build stage. */
export function addBuildApproval(params: AddApprovalParams): void {
  db.prepare(`
    INSERT INTO build_approvals (build_id, stage, approved_by, decision, comments)
    VALUES (?, ?, ?, ?, ?)
  `).run(
    params.buildId,
    params.stage,
    params.approvedBy,
    params.decision,
    params.comments ?? null
  );
  logger.info(
    { buildId: params.buildId, stage: params.stage, decision: params.decision },
    "[build-store] Approval recorded"
  );
}

/** Get the most recent approval record for a build stage. */
export function getLatestApproval(
  buildId: string,
  stage: string
): BuildApproval | null {
  const row = db
    .prepare(`
      SELECT id, build_id as buildId, stage, approved_by as approvedBy,
             approved_at as approvedAt, decision, comments
      FROM build_approvals WHERE build_id = ? AND stage = ?
      ORDER BY approved_at DESC LIMIT 1
    `)
    .get(buildId, stage) as BuildApproval | undefined;
  return row ?? null;
}

/** Get all approvals for a build ordered by time. */
export function getAllApprovals(buildId: string): BuildApproval[] {
  return db
    .prepare(
      `SELECT id, build_id as buildId, stage, approved_by as approvedBy,
              approved_at as approvedAt, decision, comments
       FROM build_approvals WHERE build_id = ? ORDER BY approved_at ASC`
    )
    .all(buildId) as BuildApproval[];
}
