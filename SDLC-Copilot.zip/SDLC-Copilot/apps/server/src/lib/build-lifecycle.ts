/**
 * Build Lifecycle — Phase 3
 *
 * State machine for the multi-stage build pipeline.
 * Handles valid transitions, advancement, and rejection flows.
 *
 * Stage Order (Phase 3a + 3b):
 *   brd_intake → brd_approved → ud_draft → ud_approved →
 *   impl_plan → plan_approved → coding → pr_created →
 *   release_docs → completed
 *
 * Phase 3 — Multi-stage Build Pipeline
 */

import {
  type BuildStage,
  type Build,
  type ApprovalDecision,
  getBuild,
  updateBuildStage,
  updateBuildStatus,
  addBuildApproval,
  getBuildArtifactIdForStage,
} from "./build-store.js";
import { getArtifact } from "./artifact-store.js";
import { buildPriorStageContext } from "./build-context.js";
import logger from "./logger.js";

export type { BuildStage };

// ─── Stage Definitions ─────────────────────────────────────────────────────────

/** All valid stages in pipeline order. */
export const STAGE_ORDER: BuildStage[] = [
  "brd_intake",
  "brd_approved",
  "ud_draft",
  "ud_approved",
  "impl_plan",
  "plan_approved",
  "coding",
  "pr_created",
  "release_docs",
  "completed",
];

/**
 * Maps each stage to the mode the agent should use when working on it.
 * 'draft' stages require agent interaction; 'approved' stages are gate transitions.
 */
export const STAGE_TO_MODE: Record<BuildStage, string> = {
  brd_intake: "brd-analyst",
  brd_approved: "brd-analyst",   // transitional — UI should auto-advance
  ud_draft: "ud",
  ud_approved: "ud",              // transitional
  impl_plan: "impl-plan",
  plan_approved: "impl-plan",    // transitional
  coding: "coding",
  pr_created: "coding",          // polling stage
  release_docs: "release",
  completed: "release",          // terminal
};

/**
 * Agent-interaction stages — these require a chat session to produce an artifact.
 * Gate stages are in-between transitions that don't require a session.
 */
export const ACTIVE_STAGES: ReadonlySet<BuildStage> = new Set([
  "brd_intake",
  "ud_draft",
  "impl_plan",
  "coding",
  "release_docs",
]);

/**
 * Stages that require an artifact to exist before advancement is allowed.
 */
export const ARTIFACT_REQUIRED_STAGES: ReadonlySet<BuildStage> = new Set([
  "brd_intake",
  "ud_draft",
  "impl_plan",
  "release_docs",
]);

/** Reverse map: which stage stores the artifact for prior context. */
const PRIOR_ARTIFACT_STAGE: Partial<Record<BuildStage, BuildStage>> = {
  ud_draft: "brd_intake",
  impl_plan: "ud_draft",
  coding: "impl_plan",
  release_docs: "impl_plan",  // coding stage has no artifact; use the impl-plan
};

// ─── Navigation ────────────────────────────────────────────────────────────────

export function getStageIndex(stage: BuildStage): number {
  return STAGE_ORDER.indexOf(stage);
}

export function getNextStage(stage: BuildStage): BuildStage | null {
  const idx = getStageIndex(stage);
  return idx < 0 || idx >= STAGE_ORDER.length - 1
    ? null
    : STAGE_ORDER[idx + 1] ?? null;
}

export function getPriorDraftStage(stage: BuildStage): BuildStage | null {
  // On rejection: revert to the nearest prior active (draft) stage
  const idx = getStageIndex(stage);
  for (let i = idx - 1; i >= 0; i--) {
    const s = STAGE_ORDER[i]!;
    if (ACTIVE_STAGES.has(s)) return s;
  }
  return null;
}

// ─── Validation ────────────────────────────────────────────────────────────────

export interface AdvanceValidation {
  canAdvance: boolean;
  reason?: string;
}

/**
 * Check whether a build can advance to the next stage.
 * Requires an artifact to exist if the current stage mandates one.
 */
export function canAdvanceBuild(buildId: string): AdvanceValidation {
  const build = getBuild(buildId);
  if (!build) return { canAdvance: false, reason: "Build not found" };
  if (build.status !== "active") {
    return { canAdvance: false, reason: `Build status is '${build.status}', not active` };
  }
  if (build.currentStage === "completed") {
    return { canAdvance: false, reason: "Build is already completed" };
  }

  if (ARTIFACT_REQUIRED_STAGES.has(build.currentStage)) {
    const artifactId = getBuildArtifactIdForStage(buildId, build.currentStage);
    if (!artifactId) {
      return {
        canAdvance: false,
        reason: `Stage '${build.currentStage}' requires an artifact before approval`,
      };
    }
  }

  const nextStage = getNextStage(build.currentStage);
  if (!nextStage) {
    return { canAdvance: false, reason: "No next stage defined" };
  }

  return { canAdvance: true };
}

// ─── State Transitions ─────────────────────────────────────────────────────────

/**
 * Advance the build to the next stage after recording approval.
 * Returns the updated Build or throws if advancement is blocked.
 */
export function advanceBuildStage(
  buildId: string,
  approvedBy: string,
  comments?: string | null
): Build {
  const validation = canAdvanceBuild(buildId);
  if (!validation.canAdvance) {
    throw new Error(validation.reason ?? "Cannot advance build");
  }

  const build = getBuild(buildId)!;
  const nextStage = getNextStage(build.currentStage)!;

  // Record approval for current stage
  addBuildApproval({
    buildId,
    stage: build.currentStage,
    approvedBy,
    decision: "approved",
    comments,
  });

  // Transition
  updateBuildStage(buildId, nextStage);

  if (nextStage === "completed") {
    updateBuildStatus(buildId, "completed");
  }

  logger.info(
    { buildId, from: build.currentStage, to: nextStage },
    "[lifecycle] Build advanced"
  );

  return getBuild(buildId)!;
}

/**
 * Reject the current stage and revert to the prior draft stage for revision.
 * Records the rejection in build_approvals.
 */
export function rejectBuildStage(
  buildId: string,
  rejectedBy: string,
  comments: string
): Build {
  const build = getBuild(buildId);
  if (!build) throw new Error("Build not found");
  if (build.status !== "active") {
    throw new Error(`Build status is '${build.status}', cannot reject`);
  }

  const decision: ApprovalDecision = "rejected";

  addBuildApproval({
    buildId,
    stage: build.currentStage,
    approvedBy: rejectedBy,
    decision,
    comments,
  });

  const priorStage = getPriorDraftStage(build.currentStage);
  const revertTo = priorStage ?? build.currentStage;
  if (priorStage) {
    updateBuildStage(buildId, revertTo);
    logger.info(
      { buildId, from: build.currentStage, revertTo },
      "[lifecycle] Build stage rejected — reverted"
    );
  }

  return getBuild(buildId)!;
}

// ─── Prior Context Loading ─────────────────────────────────────────────────────

/**
 * Load the prior stage artifact content and compress it for injection
 * into the next stage's system prompt.
 *
 * Returns empty string if no prior artifact exists.
 */
export function loadPriorStageContext(buildId: string, targetStage: BuildStage): string {
  const priorStage = PRIOR_ARTIFACT_STAGE[targetStage];
  if (!priorStage) return "";

  const artifactId = getBuildArtifactIdForStage(buildId, priorStage);
  if (!artifactId) return "";

  const artifact = getArtifact(artifactId);
  if (!artifact) return "";

  return buildPriorStageContext(priorStage, artifact.content);
}

// ─── Mode Resolution ───────────────────────────────────────────────────────────

/**
 * Get the chat mode to use for a given build stage.
 */
export function getModeForStage(stage: BuildStage): string {
  return STAGE_TO_MODE[stage] ?? "chat";
}
