/**
 * GitHub Service — Phase 3b
 *
 * Wraps the GitHub REST API for Copilot Coding Agent integration.
 * Uses REST API (simpler MVP; GraphQL upgrade optional for Phase 4).
 *
 * Responsibilities:
 *   - Create a GitHub Issue from build context
 *   - Trigger GitHub Copilot Coding Agent on an issue
 *   - Poll for PR creation by the agent
 *   - Build PR review URL
 *
 * Security:
 *   - Token sourced from GITHUB_TOKEN env var only — never from request body
 *   - Parameterized URL construction — no template injection
 *   - SSRF guard: only github.com API endpoints used
 *
 * Phase 3b — Full Build Pipeline
 */

import logger from "./logger.js";

// ─── Config ────────────────────────────────────────────────────────────────────

const GITHUB_API_BASE = "https://api.github.com";

function getToken(): string {
  const token = process.env.GITHUB_TOKEN;
  if (!token) throw new Error("GITHUB_TOKEN env var is not set");
  return token;
}

function getRepo(): { owner: string; repo: string } {
  const owner = process.env.GITHUB_REPO_OWNER;
  const repo = process.env.GITHUB_REPO_NAME;
  if (!owner || !repo) {
    throw new Error("GITHUB_REPO_OWNER and GITHUB_REPO_NAME env vars are required");
  }
  return { owner, repo };
}

// ─── Types ─────────────────────────────────────────────────────────────────────

export interface GitHubIssue {
  number: number;
  title: string;
  html_url: string;
  node_id: string;
}

export interface GitHubPR {
  number: number;
  title: string;
  html_url: string;
  state: string;
  draft: boolean;
  head: { sha: string };
}

// ─── API helpers ───────────────────────────────────────────────────────────────

async function ghFetch(
  path: string,
  options: RequestInit = {}
): Promise<Response> {
  const url = `${GITHUB_API_BASE}${path}`;
  const token = getToken();

  const res = await fetch(url, {
    ...options,
    headers: {
      Accept: "application/vnd.github+json",
      Authorization: `Bearer ${token}`,
      "X-GitHub-Api-Version": "2022-11-28",
      "Content-Type": "application/json",
      ...(options.headers ?? {}),
    },
  });

  return res;
}

// ─── Issue Management ──────────────────────────────────────────────────────────

/**
 * Create a GitHub issue from the implementation plan.
 * The issue body contains the plan details for the Copilot agent.
 */
export async function createGitHubIssue(params: {
  title: string;
  body: string;
  labels?: string[];
}): Promise<GitHubIssue> {
  const { owner, repo } = getRepo();

  const res = await ghFetch(`/repos/${owner}/${repo}/issues`, {
    method: "POST",
    body: JSON.stringify({
      title: params.title,
      body: params.body,
      labels: params.labels ?? ["copilot-task"],
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`GitHub create issue failed (${res.status}): ${err}`);
  }

  const data = await res.json() as GitHubIssue;
  logger.info({ issueNumber: data.number }, "[github] Issue created");
  return data;
}

// ─── Copilot Coding Agent ──────────────────────────────────────────────────────

/**
 * Check whether "copilot" is a valid assignee for the configured repo.
 * Returns true (204), false (404), or throws on unexpected errors.
 * Useful as a pre-flight diagnostic before attempting assignment.
 */
export async function checkCopilotAssignee(): Promise<boolean> {
  const { owner, repo } = getRepo();
  const res = await ghFetch(`/repos/${owner}/${repo}/assignees/copilot`);
  if (res.status === 204) return true;
  if (res.status === 404) return false;
  const body = await res.text();
  throw new Error(`Unexpected response checking copilot assignee (${res.status}): ${body}`);
}

/**
 * Post a "@copilot" mention comment on an issue.
 * Fallback trigger when direct assignment silently fails.
 */
async function postCopilotMentionComment(issueNumber: number): Promise<void> {
  const { owner, repo } = getRepo();

  const res = await ghFetch(
    `/repos/${owner}/${repo}/issues/${issueNumber}/comments`,
    {
      method: "POST",
      body: JSON.stringify({
        body: "@copilot Please implement this issue according to the plan described above.",
      }),
    }
  );

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`GitHub post @copilot comment failed (${res.status}): ${err}`);
  }

  logger.info({ issueNumber }, "[github] @copilot comment posted as fallback trigger");
}

/**
 * Trigger the GitHub Copilot Coding Agent on an issue by assigning it.
 * The agent detects assignment and starts working.
 *
 * Important: GitHub's assignee API silently ignores invalid assignees and
 * returns 200 with an empty list — we must inspect the response body to
 * confirm the assignment actually landed. If it didn't, we fall back to
 * posting a @copilot mention comment.
 *
 * Requires: repo settings → "Copilot coding agent" enabled.
 */
export async function triggerCopilotAgent(issueNumber: number): Promise<void> {
  const { owner, repo } = getRepo();

  // Assign the issue to copilot so it triggers the coding agent
  const res = await ghFetch(
    `/repos/${owner}/${repo}/issues/${issueNumber}/assignees`,
    {
      method: "POST",
      body: JSON.stringify({ assignees: ["copilot"] }),
    }
  );

  // Always parse body — GitHub returns the updated issue object on success
  const responseBody = await res.json() as {
    assignees?: Array<{ login: string }>;
    message?: string;
  };

  const assigneeLogins = (responseBody.assignees ?? []).map((a) => a.login.toLowerCase());

  logger.info(
    {
      issueNumber,
      httpStatus: res.status,
      assignees: assigneeLogins,
    },
    "[github] Copilot assignment API response"
  );

  if (!res.ok) {
    throw new Error(
      `GitHub assign to Copilot failed (${res.status}): ${responseBody.message ?? JSON.stringify(responseBody)}`
    );
  }

  // GitHub silently ignores invalid assignees — verify copilot landed in the list
  const copilotAssigned = assigneeLogins.some((l) => l.includes("copilot"));

  if (copilotAssigned) {
    logger.info(
      { issueNumber },
      "[github] Copilot coding agent triggered via assignee"
    );
    return;
  }

  // Assignment was silently dropped — fall back to @copilot comment trigger
  logger.warn(
    {
      issueNumber,
      assignees: assigneeLogins,
      hint: "Verify 'Copilot coding agent' is enabled in repo Settings → Code and Automation → Copilot, and that the token has repo+issues scope",
    },
    "[github] copilot not in assignees after POST — falling back to @copilot comment"
  );

  await postCopilotMentionComment(issueNumber);
}

// ─── PR Polling ────────────────────────────────────────────────────────────────

/**
 * Poll for a PR created by Copilot agent referencing a given issue number.
 * Returns the first matching open/draft PR, or null if none found.
 *
 * Uses a simple list approach (max 20 PRs) — adequate for single-team use.
 */
export async function findAgentPR(issueNumber: number): Promise<GitHubPR | null> {
  const { owner, repo } = getRepo();

  const res = await ghFetch(
    `/repos/${owner}/${repo}/pulls?state=open&per_page=20&sort=created&direction=desc`
  );

  if (!res.ok) return null;

  const prs = await res.json() as Array<GitHubPR & { body?: string | null }>;

  // Find a PR whose body mentions the issue number
  const pattern = new RegExp(`#${issueNumber}\\b|closes\\s+#?${issueNumber}`, "i");
  return prs.find((pr) => pr.title && pattern.test(pr.body ?? "")) ?? null;
}

/**
 * Build a GitHub UI URL for reviewing a PR.
 */
export function buildPRReviewUrl(prNumber: number): string {
  const { owner, repo } = getRepo();
  // Safe: only alphanumeric + hyphen/underscore from env vars
  return `https://github.com/${owner}/${repo}/pull/${prNumber}`;
}

// ─── Feature Flag ──────────────────────────────────────────────────────────────

/** Check if the GitHub Coding Agent integration is enabled. */
export function isCodingAgentEnabled(): boolean {
  return process.env.GITHUB_CODING_AGENT_ENABLED === "true";
}
