/**
 * Build Context — Phase 3 Preparation
 *
 * Produces a compact, token-minimal summary of a prior build stage artifact
 * for injection into the next stage's system prompt.
 *
 * Rules:
 * - Strip markdown formatting to plain sentences
 * - Hard cap at MAX_PRIOR_CONTEXT_CHARS (3000 chars, ~750 tokens)
 * - Wrap in XML delimiter: <prior_stage_context stage="{stage}">...</prior_stage_context>
 * - If content exceeds cap: keep first 2500 chars + last 300 chars with ellipsis bridge
 *
 * Phase 3 — Multi-stage workflow with context propagation
 */

/**
 * Maximum character footprint for prior stage context.
 * 3000 chars ≈ 750 tokens, avoiding rapid context accumulation across stages.
 */
export const MAX_PRIOR_CONTEXT_CHARS = 3000;

/**
 * Strip markdown formatting from text, converting headers, bullets, and bold to plain sentences.
 *
 * Transformations:
 * - `# Header` → `Header:`
 * - `## Subheader` → `Subheader:`
 * - `- bullet` → `• bullet`
 * - `**bold**` → `bold`
 * - `> blockquote` → `blockquote`
 * - Multiple newlines → single space or newline between sentences
 */
export function stripMarkdownForContext(text: string): string {
  let result = text;

  // Headers: convert to sentence-form with colon
  result = result.replace(/^###+ (.+)$/gm, "$1:");
  result = result.replace(/^## (.+)$/gm, "$1:");
  result = result.replace(/^# (.+)$/gm, "$1:");

  // Code blocks: remove triple-backtick fences and inline backticks
  result = result.replace(/```[\s\S]*?```/g, "");
  result = result.replace(/`([^`]+)`/g, "$1");

  // Bold/italic formatting
  result = result.replace(/\*\*(.+?)\*\*/g, "$1");
  result = result.replace(/\*(.+?)\*/g, "$1");
  result = result.replace(/__(.+?)__/g, "$1");
  result = result.replace(/_(.+?)_/g, "$1");

  // Bullet points: convert to plain dots
  result = result.replace(/^[\s-*+]+ /gm, "• ");

  // Blockquotes: remove the marker
  result = result.replace(/^> +/gm, "");

  // Collapse excessive whitespace (multiple newlines → single newline)
  result = result.replace(/\n\n+/g, "\n");

  return result.trim();
}

/**
 * Build a compact context summary from prior stage artifact.
 *
 * If content fits within MAX_PRIOR_CONTEXT_CHARS, returns it as-is (minus markdown).
 * If content exceeds cap, returns: first 2500 chars + ellipsis bridge + last 300 chars.
 * All content is wrapped in XML delimiter.
 *
 * @param stage - The prior stage name (e.g., "requirements", "design")
 * @param content - The artifact content to summarize
 * @returns XML-wrapped context with stage attribute
 */
export function buildPriorStageContext(stage: string, content: string): string {
  const cleaned = stripMarkdownForContext(content);

  let contextContent = cleaned;

  if (cleaned.length > MAX_PRIOR_CONTEXT_CHARS) {
    // Keep first 2500 chars + last 300 chars with ellipsis bridge
    const first = cleaned.slice(0, 2500);
    const last = cleaned.slice(-300);
    contextContent = `${first}\n\n[... content summarized for context efficiency ...]\n\n${last}`;
  }

  return (
    `<prior_stage_context stage="${stage}">\n` +
    `${contextContent}\n` +
    `</prior_stage_context>`
  );
}
