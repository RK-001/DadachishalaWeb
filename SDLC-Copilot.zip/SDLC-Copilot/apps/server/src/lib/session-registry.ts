/**
 * SessionRegistry — Phase 2.1
 *
 * Tracks routing metadata for active SDK sessions. Designed to run in-process
 * today (single instance), with a clean interface that a Redis adapter can
 * implement without changing any caller code (Redis swap deferred to final phase).
 *
 * What is NOT stored here:
 *   - The Copilot SDK session object (not serializable — stays in chatAgent.ts Map)
 *
 * What IS stored here:
 *   - Which process instance owns the session (prep for multi-instance routing)
 *   - Session metadata: mode, projectId, lastSeen
 *   - TTL enforcement (entries expire after 30 min of inactivity)
 */

import { randomUUID } from "crypto";

// ─── Instance identity ────────────────────────────────────────────────────────

/** Unique ID for this server process. Stable for its lifetime. */
export const INSTANCE_ID = randomUUID();

// ─── Types ────────────────────────────────────────────────────────────────────

export interface SessionRegistryEntry {
  sessionKey: string;
  instanceId: string;
  mode: string;
  projectId: string;
  registeredAt: string;   // ISO timestamp
  lastSeenAt: string;     // ISO timestamp — updated on every touch()
}

/** Registry operations. Both In-Memory and Redis adapters implement this. */
export interface ISessionRegistry {
  /**
   * Register a new session. If the sessionKey already exists, the entry is
   * overwritten (idempotent re-registration on session resume).
   */
  register(sessionKey: string, meta: { mode: string; projectId: string }): void;

  /**
   * Returns the registry entry, or null if not found / expired.
   */
  lookup(sessionKey: string): SessionRegistryEntry | null;

  /**
   * Delete the entry. Silently ignores unknown keys.
   */
  remove(sessionKey: string): void;

  /**
   * Refresh the TTL on an existing entry. No-op if key not found.
   */
  touch(sessionKey: string): void;

  /**
   * Returns true if the entry exists AND is owned by this process instance.
   * Returns true for entries created by this instance (covers single-instance case).
   * Returns false when the key is owned by a different instance (future multi-node use).
   */
  isOwnedByThisInstance(sessionKey: string): boolean;

  /**
   * Returns all non-expired entries. Used by /api/observe/sessions.
   */
  listActive(): SessionRegistryEntry[];
}

// ─── In-Memory Implementation ─────────────────────────────────────────────────

const SESSION_TTL_MS = Number(process.env.SESSION_REGISTRY_TTL_MS) || 30 * 60 * 1000; // 30 min
const SWEEP_INTERVAL_MS = 60_000; // Sweep expired entries every 60 s

class InMemorySessionRegistry implements ISessionRegistry {
  private readonly store = new Map<string, SessionRegistryEntry>();
  private sweepTimer: ReturnType<typeof setInterval> | null = null;
  private readonly ttlMs: number;

  constructor(ttlMs?: number) {
    this.ttlMs = ttlMs ?? (Number(process.env.SESSION_REGISTRY_TTL_MS) || SESSION_TTL_MS);
    // Start TTL sweep
    this.sweepTimer = setInterval(() => this.sweep(), SWEEP_INTERVAL_MS);
    // Allow process to exit even if this timer is running
    this.sweepTimer.unref?.();
  }

  register(sessionKey: string, meta: { mode: string; projectId: string }): void {
    const now = new Date().toISOString();
    this.store.set(sessionKey, {
      sessionKey,
      instanceId: INSTANCE_ID,
      mode: meta.mode,
      projectId: meta.projectId,
      registeredAt: this.store.get(sessionKey)?.registeredAt ?? now,
      lastSeenAt: now,
    });
  }

  lookup(sessionKey: string): SessionRegistryEntry | null {
    const entry = this.store.get(sessionKey);
    if (!entry) return null;
    if (this.isExpired(entry)) {
      this.store.delete(sessionKey);
      return null;
    }
    return entry;
  }

  remove(sessionKey: string): void {
    this.store.delete(sessionKey);
  }

  touch(sessionKey: string): void {
    const entry = this.store.get(sessionKey);
    if (entry) {
      entry.lastSeenAt = new Date().toISOString();
    }
  }

  isOwnedByThisInstance(sessionKey: string): boolean {
    const entry = this.lookup(sessionKey);
    if (!entry) return false; // Not found — no owner, callers can claim it
    return entry.instanceId === INSTANCE_ID;
  }

  listActive(): SessionRegistryEntry[] {
    this.sweep();
    return Array.from(this.store.values());
  }

  /** Remove all entries whose last activity exceeds TTL */
  private sweep(): void {
    const now = Date.now();
    for (const [key, entry] of this.store.entries()) {
      if (now - new Date(entry.lastSeenAt).getTime() > this.ttlMs) {
        this.store.delete(key);
      }
    }
  }

  private isExpired(entry: SessionRegistryEntry): boolean {
    return Date.now() - new Date(entry.lastSeenAt).getTime() > this.ttlMs;
  }

  /** Only used in tests to stop background sweep and clear state */
  _reset(): void {
    this.store.clear();
  }

  _stopSweep(): void {
    if (this.sweepTimer) {
      clearInterval(this.sweepTimer);
      this.sweepTimer = null;
    }
  }
}

// ─── Singleton ────────────────────────────────────────────────────────────────

/**
 * Singleton session registry. Swap this export's implementation to RedisSessionRegistry
 * when multi-instance deployment is needed (see PRODUCT-PLAN Phase 2 / final phase).
 */
export const sessionRegistry: ISessionRegistry = new InMemorySessionRegistry();

/**
 * Export concrete class for testing (allows _reset() access)
 */
export { InMemorySessionRegistry };
