/**
 * SQLite persistence layer — Phase 0.1 → Phase 2.2
 *
 * All SQL statements use parameterized queries (zero string interpolation).
 * Tables are created by initDb(), which must be called once on server startup
 * before any helper function is invoked.
 *
 * Tables:
 *   projects         — multi-project config (Phase 0.4 wires this fully)
 *   session_state    — tracks session keys for recovery after server restarts
 *   messages         — per-turn message store: user, assistant, tool metadata (Phase 1.1)
 *   memories         — project-scoped long-term memory (Phase 0.2)
 *   audit_log        — structured security audit events
 *   artifacts        — generated documents (UDs, HLDs, test cases)
 *   metrics_snapshots — durable metrics flush (60-second snapshots)
 *
 * Phase 2.2: conversation_log table eliminated (migrated session recovery to messages table)
 */

import Database, { type Database as DatabaseType } from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import logger from "./logger.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const DB_PATH =
  process.env.SQLITE_PATH ||
  path.resolve(__dirname, "../../data/sdlc-copilot.db");

// Ensure parent directory exists before opening the database
const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

export const db: DatabaseType = new Database(DB_PATH);

// WAL mode: better concurrent read performance (readers don't block writers)
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.pragma("wal_autocheckpoint = 100"); // checkpoint after 100 pages to reduce latency spikes

// ─── Init guard ──────────────────────────────────────────────────────────────────────────────

let dbInitialized = false;

/**
 * Throws if called before initDb(). Provides a clear runtime error instead of
 * a silent "no such table" failure if a module accidentally runs a query early.
 */
export function assertDbReady(): void {
  if (!dbInitialized) {
    throw new Error("[db] initDb() has not been called — database is not ready. This is a startup ordering bug.");
  }
}

// ─── Schema ────────────────────────────────────────────────────────────────────

/**
 * Create all tables if they don't exist. Idempotent — safe to call on every
 * server start. Must complete before any helper function is called.
 */
export function initDb(): void {
  if (dbInitialized) return; // idempotent — safe to call multiple times
  db.exec(`
    CREATE TABLE IF NOT EXISTS projects (
      id            TEXT PRIMARY KEY,
      name          TEXT NOT NULL,
      kb_repo_owner TEXT,
      kb_repo_name  TEXT,
      kb_repo_ref   TEXT NOT NULL DEFAULT 'main',
      ado_org       TEXT,
      ado_project   TEXT,
      enabled_modes TEXT NOT NULL DEFAULT 'chat,ud,sdlc',
      model         TEXT,
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS session_state (
      composite_key TEXT PRIMARY KEY,
      user_id_hash  TEXT NOT NULL,
      project_id    TEXT,
      mode          TEXT NOT NULL,
      last_used_at  TEXT NOT NULL DEFAULT (datetime('now')),
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Phase 0.1: conversation_log — deprecated in Phase 2.2, replaced by messages table
    -- This table is no longer created or written to (eliminated via TASK 2 cleanup)

    CREATE TABLE IF NOT EXISTS memories (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT NOT NULL,
      category   TEXT NOT NULL,
      content    TEXT NOT NULL,
      source     TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      expires_at TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_memories_project_id ON memories(project_id);

    CREATE TABLE IF NOT EXISTS audit_log (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id   TEXT,
      user_id_hash TEXT,
      action       TEXT NOT NULL,
      resource     TEXT,
      details      TEXT,            -- JSON string
      request_id   TEXT,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_audit_log_project_id ON audit_log(project_id);
    CREATE INDEX IF NOT EXISTS idx_audit_log_request_id ON audit_log(request_id);

    -- Phase 1.1: Richer per-turn message store (supplements conversation_log for analytics)
    CREATE TABLE IF NOT EXISTS messages (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      session_key  TEXT NOT NULL,
      user_id_hash TEXT,
      project_id   TEXT,
      role         TEXT NOT NULL,   -- 'user' | 'assistant' | 'tool'
      content      TEXT,
      mode         TEXT NOT NULL,
      tool_name    TEXT,
      tool_args    TEXT,            -- JSON string
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_messages_session
      ON messages(session_key, created_at);

    CREATE INDEX IF NOT EXISTS idx_messages_project
      ON messages(project_id, created_at);

    -- Phase 1.1: Generated artifacts (UDs, HLDs, test cases, release notes, BRDs, impl-plans)
    CREATE TABLE IF NOT EXISTS artifacts (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      session_key   TEXT NOT NULL,
      project_id    TEXT,
      filename      TEXT NOT NULL,
      content       TEXT NOT NULL,
      artifact_type TEXT NOT NULL CHECK(artifact_type IN ('ud','hld','test','release-notes','brd','impl-plan')),
      version       INTEGER NOT NULL DEFAULT 1,
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_artifacts_session
      ON artifacts(session_key);

    CREATE INDEX IF NOT EXISTS idx_artifacts_project
      ON artifacts(project_id, created_at);

    -- Phase 1.2: Durable metrics flush (60-second snapshots, 24 h retention)
    CREATE TABLE IF NOT EXISTS metrics_snapshots (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      snapshot   TEXT NOT NULL,    -- JSON from MetricsService.getSnapshot()
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_metrics_snapshots_created_at ON metrics_snapshots(created_at);

    -- Phase 4.1: Observer Agent self-heal audit trail
    CREATE TABLE IF NOT EXISTS observer_log (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      skill      TEXT NOT NULL,
      diagnosis  TEXT NOT NULL,
      action     TEXT NOT NULL,
      confidence REAL NOT NULL,
      outcome    TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_observer_log_skill ON observer_log(skill, created_at);

    -- Phase 4.8: Per-project prompt template overrides with version tracking
    CREATE TABLE IF NOT EXISTS prompt_templates (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id  TEXT NOT NULL,
      mode        TEXT NOT NULL,
      version     INTEGER NOT NULL DEFAULT 1,
      content     TEXT NOT NULL,
      is_active   INTEGER NOT NULL DEFAULT 1,
      created_by  TEXT NOT NULL DEFAULT 'system',
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_prompt_templates_project_mode
      ON prompt_templates(project_id, mode, is_active);
  `);  logger.info({ path: DB_PATH }, "[db] SQLite initialized");
  dbInitialized = true;
  runMigrations();
}

// ─── Schema Migrations ─────────────────────────────────────────────────────────
//
// Add new entries to MIGRATIONS to safely evolve the schema without dropping tables.
// Each migration runs exactly once, tracked by its numeric version.
// Migrations run inside initDb() after the baseline schema is created.

interface Migration {
  version: number;
  description: string;
  sql: string;
}

const MIGRATIONS: Migration[] = [
  // Example — uncomment and increment version to add future schema changes:
  // {
  //   version: 1,
  //   description: "Add index on messages role",
  //   sql: "CREATE INDEX IF NOT EXISTS idx_messages_role ON messages(role);",
  // },
];

function runMigrations(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version    INTEGER PRIMARY KEY,
      description TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  const applied = new Set(
    (db.prepare("SELECT version FROM schema_migrations").all() as { version: number }[]).map(
      (r) => r.version
    )
  );

  for (const migration of MIGRATIONS) {
    if (applied.has(migration.version)) continue;
    try {
      db.exec(migration.sql);
      db.prepare("INSERT INTO schema_migrations (version, description) VALUES (?, ?)").run(
        migration.version,
        migration.description
      );
      logger.info({ version: migration.version, description: migration.description }, "[db] Migration applied");
    } catch (err) {
      logger.error({ version: migration.version, err }, "[db] Migration failed — aborting startup");
      throw err; // hard failure: don't serve traffic with a broken schema
    }
  }
}

// ─── session_state helpers ─────────────────────────────────────────────────────

/** Upsert a session state row (insert or touch last_used_at on conflict). */
export function persistSessionState(
  key: string,
  userId: string,
  mode: string,
  projectId: string | null = null
): void {
  db.prepare(`
    INSERT INTO session_state (composite_key, user_id_hash, project_id, mode, last_used_at)
    VALUES (?, ?, ?, ?, datetime('now'))
    ON CONFLICT(composite_key) DO UPDATE SET last_used_at = datetime('now')
  `).run(key, userId, projectId, mode);
}

/** Remove a session state row when the session is destroyed. */
export function deleteSessionState(key: string): void {
  db.prepare(`DELETE FROM session_state WHERE composite_key = ?`).run(key);
}

/** Update last_used_at for a session without changing other fields. */
export function touchSessionState(key: string): void {
  db.prepare(
    `UPDATE session_state SET last_used_at = datetime('now') WHERE composite_key = ?`
  ).run(key);
}

export interface SessionStateRow {
  composite_key: string;
  user_id_hash: string;
  project_id: string | null;
  mode: string;
}

/** Look up a session_state row by composite key. Returns null if not found. */
export function getSessionStateRow(key: string): SessionStateRow | null {
  return (
    db
      .prepare(
        `SELECT composite_key, user_id_hash, project_id, mode
         FROM session_state WHERE composite_key = ?`
      )
      .get(key) as SessionStateRow | undefined
  ) ?? null;
}

/**
 * Find the most recently used session key for a given user + mode.
 * Used by GET /api/chat/history to fall back to the last known session when
 * the client's localStorage ID has no matching conversation history
 * (e.g. first refresh after deploying the localStorage persistence feature).
 */
export function findMostRecentSessionKey(
  userId: string,
  mode: string
): string | null {
  const row = db
    .prepare(
      `SELECT composite_key FROM session_state
       WHERE user_id_hash = ? AND mode = ?
       ORDER BY last_used_at DESC
       LIMIT 1`
    )
    .get(userId, mode) as { composite_key: string } | undefined;
  return row?.composite_key ?? null;
}

// ─── Session Recovery Helpers (Phase 2.2) ─────────────────────────────────────

export interface ConversationTurn {
  role: string;
  content: string | null;
}

/**
 * Load conversation history from messages table for session recovery on server restart.
 * Returns up to `limit` most recent turns in chronological order (oldest first).
 * Used when reconstructing context after a server restart.
 */
export function loadConversationHistory(
  sessionKey: string,
  limit = 20
): ConversationTurn[] {
  const rows = db
    .prepare(
      `SELECT role, content
       FROM messages
       WHERE session_key = ?
       ORDER BY created_at DESC
       LIMIT ?`
    )
    .all(sessionKey, limit) as ConversationTurn[];
  return rows.reverse(); // DESC → chronological ASC
}

// ─── audit_log helpers ─────────────────────────────────────────────────────────

export interface AuditEvent {
  action: string;
  userId?: string;
  requestId?: string;
  resource?: string;
  details?: Record<string, unknown>;
}

/**
 * Write a structured audit event to stdout + SQLite.
 * stdout is always written first (immediate visibility); SQLite is additive.
 */
export function auditLog(event: AuditEvent): void {
  const entry = {
    audit: true,
    timestamp: new Date().toISOString(),
    ...event,
  };
  process.stdout.write(JSON.stringify(entry) + "\n");

  try {
    db.prepare(`
      INSERT INTO audit_log
        (user_id_hash, action, resource, details, request_id, project_id)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      event.userId ?? null,
      event.action,
      event.resource ?? null,
      event.details ? JSON.stringify(event.details) : null,
      event.requestId ?? null,
      null
    );
  } catch {
    // stdout fallback already written
  }
}

/** Dev-only: wipe all runtime data. Keeps the "default" project intact. */
export function clearAllData(): void {
  db.transaction(() => {
    db.prepare("DELETE FROM messages").run();
    db.prepare("DELETE FROM artifacts").run();
    db.prepare("DELETE FROM metrics_snapshots").run();
    db.prepare("DELETE FROM session_state").run();
    db.prepare("DELETE FROM memories").run();
    db.prepare("DELETE FROM audit_log").run();
    db.prepare("DELETE FROM observer_log").run();
    db.prepare("DELETE FROM projects WHERE id != 'default'").run();
  })();
}

// ─── Prompt Template helpers (Phase 4.8) ──────────────────────────────────────

export interface PromptTemplateRow {
  id: number;
  project_id: string;
  mode: string;
  version: number;
  content: string;
  is_active: number;
  created_by: string;
  created_at: string;
}

/**
 * Find the active prompt template for a project + mode.
 * Returns null when none is set (caller falls back to file default).
 */
export function getActivePromptTemplate(
  projectId: string,
  mode: string
): PromptTemplateRow | null {
  return (
    db
      .prepare(
        `SELECT * FROM prompt_templates
         WHERE project_id = ? AND mode = ? AND is_active = 1
         ORDER BY version DESC
         LIMIT 1`
      )
      .get(projectId, mode) as PromptTemplateRow | undefined
  ) ?? null;
}

/** List all templates for a project (all versions, all modes). */
export function listPromptTemplates(projectId: string): PromptTemplateRow[] {
  return db
    .prepare(
      `SELECT * FROM prompt_templates
       WHERE project_id = ?
       ORDER BY mode, version DESC`
    )
    .all(projectId) as PromptTemplateRow[];
}

/** Create a new template version. Deactivates previous version for same project+mode. */
export function upsertPromptTemplate(params: {
  projectId: string;
  mode: string;
  content: string;
  createdBy?: string;
}): PromptTemplateRow {
  const { projectId, mode, content, createdBy = "admin" } = params;

  return db.transaction(() => {
    // Get next version number
    const prev = db
      .prepare(
        `SELECT MAX(version) as maxV FROM prompt_templates WHERE project_id = ? AND mode = ?`
      )
      .get(projectId, mode) as { maxV: number | null };
    const nextVersion = (prev?.maxV ?? 0) + 1;

    // Deactivate existing active templates
    db.prepare(
      `UPDATE prompt_templates SET is_active = 0
       WHERE project_id = ? AND mode = ? AND is_active = 1`
    ).run(projectId, mode);

    // Insert new version
    const result = db
      .prepare(
        `INSERT INTO prompt_templates (project_id, mode, version, content, is_active, created_by)
         VALUES (?, ?, ?, ?, 1, ?)`
      )
      .run(projectId, mode, nextVersion, content, createdBy);

    return db
      .prepare(`SELECT * FROM prompt_templates WHERE id = ?`)
      .get(result.lastInsertRowid) as PromptTemplateRow;
  })();
}

/** Activate a specific template version (deactivates others for same project+mode). */
export function activatePromptTemplate(id: number): boolean {
  const template = db
    .prepare(`SELECT * FROM prompt_templates WHERE id = ?`)
    .get(id) as PromptTemplateRow | undefined;
  if (!template) return false;

  db.transaction(() => {
    db.prepare(
      `UPDATE prompt_templates SET is_active = 0
       WHERE project_id = ? AND mode = ?`
    ).run(template.project_id, template.mode);

    db.prepare(
      `UPDATE prompt_templates SET is_active = 1 WHERE id = ?`
    ).run(id);
  })();

  return true;
}

/** Delete a prompt template by id. Cannot delete active templates. */
export function deletePromptTemplate(id: number): boolean {
  const row = db
    .prepare(`SELECT is_active FROM prompt_templates WHERE id = ?`)
    .get(id) as { is_active: number } | undefined;
  if (!row) return false;
  if (row.is_active === 1) return false; // refuse to delete active templates

  db.prepare(`DELETE FROM prompt_templates WHERE id = ?`).run(id);
  return true;
}
