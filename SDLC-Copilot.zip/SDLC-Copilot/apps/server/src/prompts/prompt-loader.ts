/**
 * Prompt template loader
 * Reads the system-prompt.md template from disk and replaces placeholders.
 * Templates are cached in memory after first load to avoid repeated disk I/O.
 *
 * Phase 4.3: XML delimiters wrap external content inputs (L3 injection defense).
 * Phase 4.8: DB-first loading — checks prompt_templates table before disk file.
 *
 * Supported placeholders:
 *   {{KB_PROJECT_NAME}} — from env / KB service
 *   {{CORE_CONTEXT}}    — injected core file contents from KB service
 *   {{MEMORY_SUMMARY}}  — project-scoped memory entries
 */

import { readFileSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";
import { getActivePromptTemplate } from "../lib/db.js";

const __dirname = dirname(fileURLToPath(import.meta.url));

// ─── Template Cache ────────────────────────────────────────────────────────────
// Exported so observer-actions can clear it on reload_prompt action
export const templateCache = new Map<string, string>();

function readTemplate(filename: string, fallback: string): string {
  const cached = templateCache.get(filename);
  if (cached !== undefined) return cached;

  const templatePath = join(__dirname, filename);
  let content: string;
  try {
    content = readFileSync(templatePath, "utf-8");
  } catch (err: any) {
    console.error(`[prompt-loader] Failed to read ${filename}: ${err.message}`);
    content = fallback;
  }

  templateCache.set(filename, content);
  return content;
}

// ─── DB-first template loader (Phase 4.8) ─────────────────────────────────────

/**
 * Try to load an active prompt template from the database for a given
 * project + mode. Returns null when no DB override is configured
 * (caller falls back to the disk file template).
 */
function loadDbTemplate(projectId: string, mode: string): string | null {
  try {
    const row = getActivePromptTemplate(projectId, mode);
    return row?.content ?? null;
  } catch {
    return null;
  }
}

// ─── L3: XML delimiter wrappers ────────────────────────────────────────────────

/**
 * Wrap user-supplied or external content in XML delimiters to prevent
 * injected text from being interpreted as prompt instructions (L3 defense).
 */
function wrapExternal(content: string): string {
  return `<kb_content>\n${content}\n</kb_content>`;
}

function wrapMemory(summary: string): string {
  if (!summary.trim()) return "";
  return `<recovered_context>\n${summary}\n</recovered_context>`;
}

/** Load and assemble the system prompt template with given values. */
export function loadSystemPrompt(values: {
  projectName: string;
  coreContext: string;
  memorySummary?: string;
  projectId?: string;
}): string {
  const mode = "chat";
  const dbTemplate = values.projectId ? loadDbTemplate(values.projectId, mode) : null;
  const template = dbTemplate ?? readTemplate(
    "system-prompt.md",
    `You are a helpful assistant for **{{KB_PROJECT_NAME}}**.\n\n{{MEMORY_SUMMARY}}\n\n{{CORE_CONTEXT}}`
  );

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{MEMORY_SUMMARY\}\}/g, wrapMemory(values.memorySummary ?? ""))
    .replace(/\{\{CORE_CONTEXT\}\}/g, wrapExternal(values.coreContext));
}

/** Load and assemble the UD analyst system prompt template with given values. */
export function loadUDSystemPrompt(values: {
  projectName: string;
  coreContext: string;
  memorySummary?: string;
  projectId?: string;
  priorContext?: string;
}): string {
  const mode = "ud";
  const dbTemplate = values.projectId ? loadDbTemplate(values.projectId, mode) : null;
  const template = dbTemplate ?? readTemplate(
    "ud-system-prompt.md",
    `You are a UD Analyst for **{{KB_PROJECT_NAME}}**. ` +
      `Create Understanding Documents through iterative questioning and drafting.\n\n{{PRIOR_STAGE_CONTEXT}}\n\n{{MEMORY_SUMMARY}}\n\n{{CORE_CONTEXT}}`
  );

  const udTemplate = readTemplate(
    "ud-template.md",
    "(UD template file not found — use your best judgment for structure, " +
      "covering: Summary, Requirements, Data Mapping, Business Rules, Acceptance Criteria, " +
      "Affected Components, Prerequisites, Deployment Order, Assumptions, Effort Estimate)"
  );

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{PRIOR_STAGE_CONTEXT\}\}/g, values.priorContext ?? "")
    .replace(/\{\{MEMORY_SUMMARY\}\}/g, wrapMemory(values.memorySummary ?? ""))
    .replace(/\{\{CORE_CONTEXT\}\}/g, wrapExternal(values.coreContext))
    .replace(/\{\{UD_TEMPLATE\}\}/g, udTemplate);
}

/** Load and assemble the BRD Analyst system prompt. */
export function loadBRDSystemPrompt(values: {
  projectName: string;
  coreContext: string;
  memorySummary?: string;
}): string {
  const template = readTemplate(
    "brd-system-prompt.md",
    `You are a BRD Analyst for **{{KB_PROJECT_NAME}}**. ` +
      `Gather requirements through Q&A and produce a BRD artifact.\n\n{{MEMORY_SUMMARY}}\n\n{{CORE_CONTEXT}}`
  );

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{MEMORY_SUMMARY\}\}/g, wrapMemory(values.memorySummary ?? ""))
    .replace(/\{\{CORE_CONTEXT\}\}/g, wrapExternal(values.coreContext));
}

/** Load and assemble the Implementation Planner system prompt. */
export function loadImplPlanSystemPrompt(values: {
  projectName: string;
  coreContext: string;
  memorySummary?: string;
  priorContext?: string;
}): string {
  const template = readTemplate(
    "impl-plan-system-prompt.md",
    `You are an Implementation Planner for **{{KB_PROJECT_NAME}}**. ` +
      `Read the approved UD and produce a step-by-step plan.\n\n{{PRIOR_STAGE_CONTEXT}}\n\n{{MEMORY_SUMMARY}}\n\n{{CORE_CONTEXT}}`
  );

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{PRIOR_STAGE_CONTEXT\}\}/g, values.priorContext ?? "")
    .replace(/\{\{MEMORY_SUMMARY\}\}/g, wrapMemory(values.memorySummary ?? ""))
    .replace(/\{\{CORE_CONTEXT\}\}/g, wrapExternal(values.coreContext));
}

/** Load and assemble the Coding Agent Coordinator system prompt. */
export function loadCodingSystemPrompt(values: {
  projectName: string;
  coreContext: string;
  memorySummary?: string;
  priorContext?: string;
}): string {
  const template = readTemplate(
    "coding-system-prompt.md",
    `You are a Coding Agent Coordinator for **{{KB_PROJECT_NAME}}**. ` +
      `Coordinate the GitHub Copilot Coding Agent to implement the plan.\n\n{{PRIOR_STAGE_CONTEXT}}\n\n{{MEMORY_SUMMARY}}\n\n{{CORE_CONTEXT}}`
  );

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{PRIOR_STAGE_CONTEXT\}\}/g, values.priorContext ?? "")
    .replace(/\{\{MEMORY_SUMMARY\}\}/g, wrapMemory(values.memorySummary ?? ""))
    .replace(/\{\{CORE_CONTEXT\}\}/g, wrapExternal(values.coreContext));
}

/** Load and assemble the Release Documentation system prompt. */
export function loadReleaseSystemPrompt(values: {
  projectName: string;
  coreContext: string;
  memorySummary?: string;
  priorContext?: string;
}): string {
  const template = readTemplate(
    "release-system-prompt.md",
    `You are a Release Documentation Specialist for **{{KB_PROJECT_NAME}}**. ` +
      `Generate release notes from the completed build.\n\n{{PRIOR_STAGE_CONTEXT}}\n\n{{MEMORY_SUMMARY}}\n\n{{CORE_CONTEXT}}`
  );

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{PRIOR_STAGE_CONTEXT\}\}/g, values.priorContext ?? "")
    .replace(/\{\{MEMORY_SUMMARY\}\}/g, wrapMemory(values.memorySummary ?? ""))
    .replace(/\{\{CORE_CONTEXT\}\}/g, wrapExternal(values.coreContext));
}
