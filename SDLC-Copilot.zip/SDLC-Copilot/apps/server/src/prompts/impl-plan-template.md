# Implementation Plan: {{workitem_title}}

**Based on:** UD v{{ud_version}}  
**Date:** {{date}}  
**Status:** {{status}}  
**Work Item:** #{{workitem_id}}

---

## Overview

{{1-paragraph summary of what will be built, key components, and expected outcome}}

---

## Architecture Impact

**Files to Create:**
- {{path/to/new/file.ts}} — {{description}}

**Files to Modify:**
- {{path/to/existing/file.ts}} — {{what changes}}

**Database Changes:**
- {{migration or schema change description, or "None"}}

**API Changes:**
- {{new endpoints or modifications, or "None"}}

---

## Implementation Steps

### Step 1 — {{Category: e.g., Database Schema}}
**File:** `{{path/to/file}}`  
**Change:** {{What will be done}}

**Details:**
- {{Specific implementation detail}}
- {{SQL/migration logic or description}}
- {{Any constraints or considerations}}

**Acceptance Criteria:**
- {{How to verify this step is complete}}
- {{Test or validation method}}

### Step 2 — {{Category: e.g., Backend API}}
**File:** `{{path/to/file}}`  
**Change:** {{What will be done}}

**Details:**
- {{Specific implementation detail}}
- {{API endpoint pattern or method}}
- {{Input/output parameters or logic}}

**Acceptance Criteria:**
- {{How to verify this step is complete}}

### Step 3 — {{Category: e.g., Frontend Component}}
**File:** `{{path/to/file}}`  
**Change:** {{What will be done}}

**Details:**
- {{Component structure or UI pattern}}
- {{State management or props}}
- {{Event handlers or user interactions}}

**Acceptance Criteria:**
- {{How to verify this step is complete}}

---

## Technical Specifications

### Backend Implementation

**API Endpoints:**
- `{{METHOD}} /api/{{route}}` — {{description of endpoint purpose}}
  - **Input:** {{parameter names and types}}
  - **Output:** {{response structure}}
  - **Error Handling:** {{error cases and codes}}

**Database Layer:**
- {{Query class or method name}} — {{description}}
  - **SQL Logic:** {{query description or pseudocode}}
  - **Indexes:** {{Any indexes to create}}

**Service/Business Logic:**
- {{Service class name}} — {{key methods and responsibilities}}
  - **Method 1:** {{description}}
  - **Method 2:** {{description}}

### Frontend Implementation

**UI Components:**
- {{Component name}} — {{description}}
  - **Props:** {{prop names and types}}
  - **State:** {{state variables or hooks}}
  - **Events:** {{event handlers}}

**Presentation Layer Logic:**
- {{Processing logic for display}}
- {{Form validation or input handling}}
- {{State management (Redux, Context, etc.)}}

**User Interface Details:**
- **Layout:** {{Component layout description}}
- **Styling:** {{CSS/styling approach}}
- **Responsive Behavior:** {{Mobile/tablet handling}}

**User Screen/Page Flow:**
- {{Page/Screen 1}}: {{Action or navigation trigger}} → {{Next screen}}
- {{Page/Screen 2}}: {{Action or navigation trigger}} → {{Next screen}}

### Integration Points

**Session Variables:**
- `{{variable_name}}` — {{data stored and purpose}}

**Configuration Changes:**
- {{Config file or setting}} — {{What is being configured}}
- {{Environment variables}} — {{Setup requirements}}

**Impacted Backend Components:**
- {{Component/Service name}} — {{How it is affected}}

**Impacted Frontend Components:**
- {{Component name}} — {{How it is affected}}

---

## Changes to Existing Features

{{Describe any modifications to existing functionality, backward compatibility concerns, or deprecations}}

- **Feature:** {{Existing feature name}}
- **Change:** {{What is being modified}}
- **Impact:** {{Affected areas or users}}

---

## Testing Plan

### Unit Tests
- **File:** `{{path/to/test/file}}`
- **What to Test:** {{Test cases and expected outcomes}}
- **Coverage Target:** {{% code coverage}}

### Integration Tests
- **File:** `{{path/to/test/file}}`
- **Scenario:** {{Integration scenario}}
- **Expected Result:** {{Expected outcome}}

### End-to-End Tests
- **Scenario:** {{User workflow or business scenario}}
- **Steps:** {{Step-by-step test execution}}
- **Expected Result:** {{Expected outcome}}

---

## Setup & Configuration

**Prerequisites:**
- {{Required tools, libraries, or setup}}

**Environment Variables:**
- `{{VAR_NAME}}` = {{value or description}}

**Manual Setup Steps:**
1. {{Setup step 1}}
2. {{Setup step 2}}

---

## Rollout Order

1. **{{Step 1}}** — {{Reason: dependency or prerequisite}}
2. **{{Step 2}}** — {{Reason: depends on step 1}}
3. **{{Step 3}}** — {{Reason: can be parallel or sequential}}

---

## Risks & Mitigation

| Risk | Impact | Mitigation |
|------|--------|------------|
| {{Risk description}} | {{High/Medium/Low}} | {{Mitigation strategy}} |
| {{Risk description}} | {{High/Medium/Low}} | {{Mitigation strategy}} |

---

## Open Points & Follow-ups

- {{Unresolved question or item requiring clarification}}
- {{Item to be addressed in subsequent phases}}

---

**Implementation Plan ID:** WI-{{workitem_id}}-IMPL-v{{version}}  
**Status:** {{status}}  
**Last Updated:** {{date}}