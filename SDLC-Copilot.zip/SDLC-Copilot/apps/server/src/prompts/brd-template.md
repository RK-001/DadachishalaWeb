# BRD: {{workitem_title}}

**Version:** {{version}}  
**Date:** {{date}}  
**Work Item:** #{{workitem_id}}  

---

## Executive Summary

{1–2 paragraph description of the business need and proposed solution}

---

## Business Objectives

1. **Objective 1** — {{description of first key business objective}}

2. **Objective 2** — {{description of second key business objective}}

3. **Objective 3** — {{description of third key business objective}}

---

## Scope

### In Scope

- {{Feature/Component 1 description}}
- {{Feature/Component 2 description}}
- {{Feature/Component 3 description}}
- {{Objects/Systems modified}}

### Out of Scope

- {{What is explicitly NOT included}}
- {{Why certain features are excluded}}
- {{Future enhancements or Phase 2 items}}

---

## Requirements

### Functional Requirements

- **FR-001 (Must Have):** {{Functional requirement description}} — {{Any reference or context}}
- **FR-002 (Must Have):** {{Functional requirement description}} — {{Any reference or context}}
- **FR-003 (Should Have):** {{Functional requirement description}} — {{Any reference or context}}
- **FR-004 (Could Have):** {{Functional requirement description}} — {{Any reference or context}}

### Non-Functional Requirements

- **NFR-001 (Performance):** {{Performance benchmark or target}}
- **NFR-002 (Scalability):** {{Scalability requirements}}
- **NFR-003 (Security):** {{Security or compliance requirements}}
- **NFR-004 (Reliability):** {{Availability or reliability targets}}
- **NFR-005 (Usability):** {{User experience standards}}

---

## Constraints & Assumptions

- **ASSUMPTION:** {{Key assumption that impacts scope or design}}
- **ASSUMPTION:** {{Key assumption that impacts scope or design}}
- **CONSTRAINT:** {{Operational or technical constraint}}
- **CONSTRAINT:** {{Operational or technical constraint}}

---

## Acceptance Criteria

| # | Given | When | Then | Source |
|---|-------|------|------|--------|
| **AC-1** | {{Pre-condition/context}} | {{Action/trigger}} | {{Expected outcome}} | {{Requirement ID}} |
| **AC-2** | {{Pre-condition/context}} | {{Action/trigger}} | {{Expected outcome}} | {{Requirement ID}} |
| **AC-3** | {{Pre-condition/context}} | {{Action/trigger}} | {{Expected outcome}} | {{Requirement ID}} |

---

## Open Points

| # | Question / Area | Why It Matters | To Be Resolved In |
|---|-----------------|----------------|-------------------|
| **1** | {{Unresolved question or decision point}} | {{Impact on design/scope}} | **{{Phase/Timeline}}** — {{Who resolves}} |
| **2** | {{Unresolved question or decision point}} | {{Impact on design/scope}} | **{{Phase/Timeline}}** — {{Who resolves}} |

---
