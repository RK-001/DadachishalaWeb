/**
 * Unit tests — SkillRegistry
 *
 * Tests: register, resolve, resolveFallback, markDegraded, markHealthy,
 *        getHealth, APPROVED_FALLBACKS enforcement (S9 protection)
 *
 * Isolated — no DB, no SDK, no env vars required.
 */
import { describe, it, expect, beforeEach } from "vitest";

// ── Inline replica matching registry.ts ───────────────────────────────────────

type SkillHealth = "healthy" | "degraded" | "unknown";

interface SkillDescriptor {
  readonly mode: string;
  readonly displayName: string;
  readonly fallbackMode: string | null;
}

interface SkillRegistryEntry {
  descriptor: SkillDescriptor;
  health: SkillHealth;
}

const APPROVED_FALLBACKS: Record<string, string | null> = {
  sdlc: null,
  "ephemeral-analysis": null,
};

class SkillRegistry {
  private entries = new Map<string, SkillRegistryEntry>();

  register(descriptor: SkillDescriptor): void {
    const { mode, fallbackMode } = descriptor;
    if (fallbackMode !== undefined && fallbackMode !== null) {
      const approved = APPROVED_FALLBACKS[mode];
      if (approved !== fallbackMode) {
        throw new Error(
          `[registry] Skill "${mode}" declares fallback "${fallbackMode}" ` +
            `but approved fallback is "${approved ?? "null"}". Blocked.`
        );
      }
    }
    this.entries.set(mode, { descriptor, health: "healthy" });
  }

  resolve(mode: string): SkillDescriptor {
    const entry = this.entries.get(mode);
    if (!entry) throw new Error(`Unknown skill mode: "${mode}"`);
    return entry.descriptor;
  }

  resolveFallback(mode: string): SkillDescriptor | null {
    const entry = this.entries.get(mode);
    if (!entry?.descriptor.fallbackMode) return null;
    return this.entries.get(entry.descriptor.fallbackMode)?.descriptor ?? null;
  }

  getHealth(mode: string): SkillHealth {
    return this.entries.get(mode)?.health ?? "unknown";
  }

  markDegraded(mode: string): void {
    const entry = this.entries.get(mode);
    if (entry) entry.health = "degraded";
  }

  markHealthy(mode: string): void {
    const entry = this.entries.get(mode);
    if (entry) entry.health = "healthy";
  }
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe("SkillRegistry", () => {
  let registry: SkillRegistry;

  beforeEach(() => {
    registry = new SkillRegistry();
    registry.register({ mode: "sdlc", displayName: "SDLC Agent", fallbackMode: null });
    registry.register({
      mode: "ephemeral-analysis",
      displayName: "Content Analyzer",
      fallbackMode: null,
    });
  });

  it("resolves a registered skill by mode", () => {
    const skill = registry.resolve("sdlc");
    expect(skill.mode).toBe("sdlc");
    expect(skill.displayName).toBe("SDLC Agent");
  });

  it("throws for an unknown mode", () => {
    expect(() => registry.resolve("unknown-mode")).toThrow();
  });

  it("returns null fallback for sdlc (no fallback declared)", () => {
    expect(registry.resolveFallback("sdlc")).toBeNull();
  });

  it("returns null fallback for ephemeral-analysis", () => {
    expect(registry.resolveFallback("ephemeral-analysis")).toBeNull();
  });

  it("initial health is healthy", () => {
    expect(registry.getHealth("sdlc")).toBe("healthy");
    expect(registry.getHealth("ephemeral-analysis")).toBe("healthy");
  });

  it("getHealth returns unknown for unregistered mode", () => {
    expect(registry.getHealth("ghost")).toBe("unknown");
  });

  it("markDegraded sets skill to degraded", () => {
    registry.markDegraded("sdlc");
    expect(registry.getHealth("sdlc")).toBe("degraded");
  });

  it("markHealthy recovers a degraded skill", () => {
    registry.markDegraded("sdlc");
    registry.markHealthy("sdlc");
    expect(registry.getHealth("sdlc")).toBe("healthy");
  });

  it("rejects an unapproved fallback (S9 protection)", () => {
    // sdlc fallback must be null per APPROVED_FALLBACKS
    expect(() =>
      registry.register({ mode: "sdlc", displayName: "x", fallbackMode: "chat" })
    ).toThrow(/Blocked/);
  });

  it("rejects any fallback for ephemeral-analysis", () => {
    expect(() =>
      registry.register({ mode: "ephemeral-analysis", displayName: "x", fallbackMode: "sdlc" })
    ).toThrow(/Blocked/);
  });
});
