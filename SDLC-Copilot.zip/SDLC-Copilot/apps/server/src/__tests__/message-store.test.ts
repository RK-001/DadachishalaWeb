/**
 * Unit tests — message store (Phase 1.1)
 *
 * Tests: saveMessage round-trip, getMessages, getMessagesByProject,
 *        non-fatal write failures, empty result for unknown session.
 *
 * Uses an in-memory SQLite database via vi.mock so no files are written.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mock db.ts with an in-memory SQLite instance ───────────────────────────────
vi.mock("../lib/db.js", async () => {
  const { default: Database } = await import("better-sqlite3");
  const db = new Database(":memory:");
  db.exec(`
    CREATE TABLE IF NOT EXISTS messages (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      session_key  TEXT NOT NULL,
      user_id_hash TEXT,
      project_id   TEXT,
      role         TEXT NOT NULL,
      content      TEXT,
      mode         TEXT NOT NULL,
      tool_name    TEXT,
      tool_args    TEXT,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);
  return { db };
});

import {
  saveMessage,
  getMessages,
  getMessagesByProject,
} from "../lib/message-store.js";
import { db } from "../lib/db.js";

// ── Helpers ───────────────────────────────────────────────────────────────────────────────────

function clearMessages() {
  db.exec("DELETE FROM messages");
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe("saveMessage + getMessages round-trip", () => {
  beforeEach(clearMessages);

  it("saves a user message and retrieves it", () => {
    saveMessage({
      sessionKey: "user1:sess1:sdlc",
      userIdHash: "abc123",
      projectId: "default",
      role: "user",
      content: "Hello agent",
      mode: "sdlc",
    });

    const rows = getMessages("user1:sess1:sdlc");
    expect(rows).toHaveLength(1);
    expect(rows[0].role).toBe("user");
    expect(rows[0].content).toBe("Hello agent");
    expect(rows[0].mode).toBe("sdlc");
    expect(rows[0].user_id_hash).toBe("abc123");
    expect(rows[0].project_id).toBe("default");
  });

  it("saves an assistant message with null tool fields", () => {
    saveMessage({
      sessionKey: "user1:sess1:sdlc",
      role: "assistant",
      content: "Here is your answer.",
      mode: "sdlc",
    });

    const rows = getMessages("user1:sess1:sdlc");
    expect(rows[0].tool_name).toBeNull();
    expect(rows[0].tool_args).toBeNull();
  });

  it("saves a tool message with args as JSON string", () => {
    saveMessage({
      sessionKey: "user1:sess1:sdlc",
      role: "tool",
      mode: "sdlc",
      toolName: "fetch_kb_file",
      toolArgs: { filePath: "auth.md" },
    });

    const rows = getMessages("user1:sess1:sdlc");
    expect(rows[0].tool_name).toBe("fetch_kb_file");
    expect(rows[0].tool_args).toBe(JSON.stringify({ filePath: "auth.md" }));
    expect(rows[0].content).toBeNull();
  });

  it("returns messages in chronological order (ASC)", () => {
    saveMessage({ sessionKey: "key:asc:sdlc", role: "user", content: "first", mode: "sdlc" });
    saveMessage({ sessionKey: "key:asc:sdlc", role: "assistant", content: "second", mode: "sdlc" });

    const rows = getMessages("key:asc:sdlc");
    expect(rows[0].content).toBe("first");
    expect(rows[1].content).toBe("second");
  });

  it("returns empty array for unknown session", () => {
    expect(getMessages("no-such:session:sdlc")).toHaveLength(0);
  });

  it("respects limit parameter", () => {
    for (let i = 0; i < 5; i++) {
      saveMessage({ sessionKey: "key:limit:sdlc", role: "user", content: `msg ${i}`, mode: "sdlc" });
    }
    expect(getMessages("key:limit:sdlc", 3)).toHaveLength(3);
  });

  it("does not throw on invalid toolArgs — non-fatal", () => {
    // toolArgs accepts any object; store stringifies it
    expect(() =>
      saveMessage({
        sessionKey: "key:safe:sdlc",
        role: "tool",
        mode: "sdlc",
        toolArgs: { nested: { deep: true } },
      })
    ).not.toThrow();
  });
});

describe("getMessagesByProject", () => {
  beforeEach(clearMessages);

  it("returns messages filtered by projectId (newest-first)", () => {
    saveMessage({ sessionKey: "s1", projectId: "proj-a", role: "user", content: "from A", mode: "sdlc" });
    saveMessage({ sessionKey: "s2", projectId: "proj-b", role: "user", content: "from B", mode: "sdlc" });
    saveMessage({ sessionKey: "s3", projectId: "proj-a", role: "assistant", content: "also from A", mode: "sdlc" });

    const rows = getMessagesByProject("proj-a");
    expect(rows).toHaveLength(2);
    rows.forEach((r) => expect(r.project_id).toBe("proj-a"));
  });

  it("returns empty array for unknown projectId", () => {
    expect(getMessagesByProject("unknown-project")).toHaveLength(0);
  });
});
