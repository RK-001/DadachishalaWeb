/**
 * Unit tests — Build Lifecycle (Phase 3)
 *
 * Tests: canAdvanceBuild validation, advanceBuildStage transitions,
 *        rejectBuildStage revert logic, getNextStage, getPriorDraftStage,
 *        loadPriorStageContext
 */
import { describe, it, expect, beforeEach } from "vitest";
import {
  canAdvanceBuild,
  advanceBuildStage,
  rejectBuildStage,
  getNextStage,
  getPriorDraftStage,
  STAGE_ORDER,
  ACTIVE_STAGES,
} from "../lib/build-lifecycle.js";
import { createBuild, linkArtifactToBuild } from "../lib/build-store.js";
import { db, initDb } from "../lib/db.js";
import { initBuildDb } from "../lib/build-db.js";

function seedDefaultProject() {
  db.prepare(`INSERT OR IGNORE INTO projects (id, name, enabled_modes) VALUES ('default', 'Test', 'chat')`).run();
}

describe("build-lifecycle — STAGE_ORDER", () => {
  it("starts with brd_intake and ends with completed", () => {
    expect(STAGE_ORDER[0]).toBe("brd_intake");
    expect(STAGE_ORDER[STAGE_ORDER.length - 1]).toBe("completed");
  });

  it("has 10 stages total", () => {
    expect(STAGE_ORDER).toHaveLength(10);
  });
});

describe("build-lifecycle — getNextStage", () => {
  it("returns brd_approved after brd_intake", () => {
    expect(getNextStage("brd_intake")).toBe("brd_approved");
  });

  it("returns completed after release_docs", () => {
    expect(getNextStage("release_docs")).toBe("completed");
  });

  it("returns null for completed (terminal)", () => {
    expect(getNextStage("completed")).toBeNull();
  });
});

describe("build-lifecycle — getPriorDraftStage", () => {
  it("reverts ud_approved to ud_draft", () => {
    expect(getPriorDraftStage("ud_approved")).toBe("ud_draft");
  });

  it("reverts brd_approved to brd_intake", () => {
    expect(getPriorDraftStage("brd_approved")).toBe("brd_intake");
  });

  it("reverts impl_plan to impl_plan (itself is active)", () => {
    // impl_plan is an active stage — prior active is ud_draft
    expect(getPriorDraftStage("impl_plan")).toBe("ud_draft");
  });
});

describe("build-lifecycle — canAdvanceBuild", () => {
  beforeEach(() => {
    try { initDb(); initBuildDb(); } catch { /* idempotent */ }
    seedDefaultProject();
  });

  it("returns false for missing build ID", () => {
    const result = canAdvanceBuild("nonexistent");
    expect(result.canAdvance).toBe(false);
    expect(result.reason).toMatch(/not found/i);
  });

  it("returns false when artifact is required but missing", () => {
    const build = createBuild({
      projectId: "default",
      title: "No Artifact Build",
      createdBy: "test",
    });
    // brd_intake requires artifact before advancing
    const result = canAdvanceBuild(build.id);
    expect(result.canAdvance).toBe(false);
    expect(result.reason).toMatch(/artifact/i);
  });

  it("returns true when artifact is present at current stage", async () => {
    const build = createBuild({
      projectId: "default",
      title: "With Artifact Build",
      createdBy: "test",
    });

    const { db } = await import("../lib/db.js");
    const fakeArtifactId = (db.prepare(`
      INSERT INTO artifacts (session_key, filename, content, artifact_type, version)
      VALUES ('lifecycle-test', 'brd.md', 'content', 'brd', 1)
    `).run().lastInsertRowid) as number;

    linkArtifactToBuild(build.id, "brd_intake", fakeArtifactId);

    const result = canAdvanceBuild(build.id);
    expect(result.canAdvance).toBe(true);
  });
});

describe("build-lifecycle — advanceBuildStage", () => {
  beforeEach(() => {
    try { initDb(); initBuildDb(); } catch { /* idempotent */ }
    seedDefaultProject();
  });

  it("throws when no artifact present", () => {
    const build = createBuild({
      projectId: "default",
      title: "Advance Test",
      createdBy: "test",
    });
    expect(() => advanceBuildStage(build.id, "approver")).toThrow();
  });

  it("advances stage and records approval when artifact present", () => {
    const build = createBuild({
      projectId: "default",
      title: "Full Advance Test",
      createdBy: "test",
    });

    const fakeId = (db.prepare(`
      INSERT INTO artifacts (session_key, filename, content, artifact_type, version)
      VALUES ('adv-test', 'brd.md', 'brd content', 'brd', 1)
    `).run().lastInsertRowid) as number;

    linkArtifactToBuild(build.id, "brd_intake", fakeId);

    const updated = advanceBuildStage(build.id, "product-owner", "LGTM");
    expect(updated.currentStage).toBe("brd_approved");
  });
});

describe("build-lifecycle — rejectBuildStage", () => {
  beforeEach(() => {
    try { initDb(); initBuildDb(); } catch { /* idempotent */ }
    seedDefaultProject();
  });

  it("reverts to prior draft stage", () => {
    const build = createBuild({
      projectId: "default",
      title: "Reject Test",
      createdBy: "test",
    });

    // Manufacture a build at brd_approved stage
    db.prepare(
      `UPDATE builds SET current_stage = 'brd_approved' WHERE id = ?`
    ).run(build.id);

    const reverted = rejectBuildStage(build.id, "reviewer", "Needs more detail");
    // brd_approved rejects back to brd_intake
    expect(reverted.currentStage).toBe("brd_intake");
  });
});
