/**
 * Unit tests — EventBus
 *
 * Tests: emit, subscribe, subscribeForSession, unsubscribe cleanup,
 *        error isolation (one handler crash doesn't kill others),
 *        listener count, typed data shapes
 *
 * Isolated — no DB, no SDK, no env vars required.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";
import { EventBus } from "../lib/event-bus.js";
import type { AnySkillEvent } from "../lib/event-bus.js";

function makeBus() {
  return new EventBus();
}

describe("EventBus", () => {
  let bus: ReturnType<typeof makeBus>;

  beforeEach(() => {
    bus = makeBus();
  });

  // ── emit + subscribe ───────────────────────────────────────────────────────

  it("subscriber receives emitted events", () => {
    const received: AnySkillEvent[] = [];
    bus.subscribe((e: AnySkillEvent) => received.push(e));

    bus.emit("chunk", "user:sess1:sdlc", { content: "Hello" });

    expect(received).toHaveLength(1);
    expect(received[0].type).toBe("chunk");
    expect(received[0].sessionKey).toBe("user:sess1:sdlc");
    expect((received[0].data as { content: string }).content).toBe("Hello");
  });

  it("emitted event has correct timestamp shape", () => {
    const received: AnySkillEvent[] = [];
    bus.subscribe((e: AnySkillEvent) => received.push(e));

    bus.emit("done", "user:sess1:chat", { latencyMs: 123, mode: "chat" }, "req-id-1");

    expect(received[0].requestId).toBe("req-id-1");
    expect(received[0].timestamp).toMatch(/^\d{4}-\d{2}-\d{2}T/);
  });

  it("multiple subscribers all receive the event", () => {
    const counts = [0, 0, 0];
    bus.subscribe(() => counts[0]++);
    bus.subscribe(() => counts[1]++);
    bus.subscribe(() => counts[2]++);

    bus.emit("status", "user:sess1:chat", { message: "Processing..." });

    expect(counts).toEqual([1, 1, 1]);
  });

  // ── unsubscribe ────────────────────────────────────────────────────────────

  it("unsubscribe stops receiving events", () => {
    const received: AnySkillEvent[] = [];
    const unsub = bus.subscribe((e: AnySkillEvent) => received.push(e));

    bus.emit("chunk", "user:sess1:chat", { content: "first" });
    unsub();
    bus.emit("chunk", "user:sess1:chat", { content: "second" });

    expect(received).toHaveLength(1);
    expect((received[0].data as { content: string }).content).toBe("first");
  });

  it("listenerCount decreases after unsubscribe", () => {
    const unsub = bus.subscribe(() => {});
    const before = bus.listenerCount;
    unsub();
    expect(bus.listenerCount).toBe(before - 1);
  });

  // ── subscribeForSession ────────────────────────────────────────────────────

  it("subscribeForSession only receives events for that session", () => {
    const received: AnySkillEvent[] = [];
    bus.subscribeForSession("user:sess1:chat", (e: AnySkillEvent) => received.push(e));

    bus.emit("chunk", "user:sess1:chat", { content: "for session 1" });
    bus.emit("chunk", "user:sess2:chat", { content: "for session 2" });

    expect(received).toHaveLength(1);
    expect((received[0].data as { content: string }).content).toBe("for session 1");
  });

  it("subscribeForSession unsubscribe stops session-scoped events", () => {
    const received: AnySkillEvent[] = [];
    const unsub = bus.subscribeForSession("user:sess1:chat", (e: AnySkillEvent) => received.push(e));

    bus.emit("chunk", "user:sess1:chat", { content: "before unsub" });
    unsub();
    bus.emit("chunk", "user:sess1:chat", { content: "after unsub" });

    expect(received).toHaveLength(1);
  });

  // ── error isolation ────────────────────────────────────────────────────────

  it("a crashing handler does not prevent other handlers from running", () => {
    const successCount = { n: 0 };
    bus.subscribe(() => { throw new Error("Handler crash!"); });
    bus.subscribe(() => { successCount.n++; });

    bus.emit("chunk", "user:sess1:sdlc", { content: "test" });

    expect(successCount.n).toBe(1); // second handler still ran
  });

  it("does not throw when all handlers crash", () => {
    bus.subscribe(() => { throw new Error("Crash 1"); });
    bus.subscribe(() => { throw new Error("Crash 2"); });

    expect(() => {
      bus.emit("chunk", "user:sess1:sdlc", { content: "test" });
    }).not.toThrow();
  });

  // ── typed event data ───────────────────────────────────────────────────────

  it("error event carries message and code", () => {
    const received: AnySkillEvent[] = [];
    bus.subscribe((e: AnySkillEvent) => received.push(e));

    bus.emit("error", "user:sess1:sdlc", { message: "Something broke", code: "ERR_001" });

    const data = received[0].data as { message: string; code?: string };
    expect(data.message).toBe("Something broke");
    expect(data.code).toBe("ERR_001");
  });

  it("skill_fallback event carries from/to", () => {
    const received: AnySkillEvent[] = [];
    bus.subscribe((e: AnySkillEvent) => received.push(e));

    bus.emit("skill_fallback", "user:sess1:sdlc", { from: "sdlc", to: "ud" });

    const data = received[0].data as { from: string; to: string };
    expect(data.from).toBe("sdlc");
    expect(data.to).toBe("ud");
  });
});
