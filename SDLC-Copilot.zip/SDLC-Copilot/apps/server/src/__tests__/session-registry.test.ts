/**
 * Unit tests — InMemorySessionRegistry
 *
 * Tests: register, lookup, remove, touch, isOwnedByThisInstance,
 *        listActive, TTL expiry sweep, idempotent re-registration
 *
 * Isolated — no DB, no env vars required.
 */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { InMemorySessionRegistry, INSTANCE_ID } from "../lib/session-registry.js";

describe("InMemorySessionRegistry", () => {
  let registry: InMemorySessionRegistry;

  beforeEach(() => {
    registry = new InMemorySessionRegistry();
    registry._stopSweep();
  });

  afterEach(() => {
    registry._reset();
  });

  // ── register + lookup ──────────────────────────────────────────────────────

  it("registers a new session and looks it up", () => {
    registry.register("user:session1:sdlc", { mode: "sdlc", projectId: "default" });
    const entry = registry.lookup("user:session1:sdlc");
    expect(entry).not.toBeNull();
    expect(entry?.mode).toBe("sdlc");
    expect(entry?.projectId).toBe("default");
    expect(entry?.instanceId).toBe(INSTANCE_ID);
  });

  it("returns null for unknown sessionKey", () => {
    expect(registry.lookup("does:not:exist")).toBeNull();
  });

  it("re-registration is idempotent and preserves registeredAt", () => {
    registry.register("user:session1:sdlc", { mode: "sdlc", projectId: "default" });
    const first = registry.lookup("user:session1:sdlc");
    const registeredAt1 = first!.registeredAt;

    registry.register("user:session1:sdlc", { mode: "sdlc", projectId: "default" });
    const second = registry.lookup("user:session1:sdlc");
    expect(second!.registeredAt).toBe(registeredAt1); // registeredAt preserved
  });

  // ── remove ────────────────────────────────────────────────────────────────

  it("removes a registered session", () => {
    registry.register("user:session1:sdlc", { mode: "sdlc", projectId: "default" });
    registry.remove("user:session1:sdlc");
    expect(registry.lookup("user:session1:sdlc")).toBeNull();
  });

  it("remove is a no-op for unknown keys", () => {
    expect(() => registry.remove("does:not:exist")).not.toThrow();
  });

  // ── touch ─────────────────────────────────────────────────────────────────

  it("touch updates lastSeenAt", async () => {
    registry.register("user:session1:sdlc", { mode: "sdlc", projectId: "default" });
    const before = registry.lookup("user:session1:sdlc")!.lastSeenAt;

    await new Promise((r) => setTimeout(r, 10)); // ensure timestamp changes
    registry.touch("user:session1:sdlc");

    const after = registry.lookup("user:session1:sdlc")!.lastSeenAt;
    expect(after > before).toBe(true);
  });

  it("touch is a no-op for unknown keys", () => {
    expect(() => registry.touch("does:not:exist")).not.toThrow();
  });

  // ── isOwnedByThisInstance ─────────────────────────────────────────────────

  it("isOwnedByThisInstance returns true for newly registered sessions", () => {
    registry.register("user:session1:sdlc", { mode: "sdlc", projectId: "default" });
    expect(registry.isOwnedByThisInstance("user:session1:sdlc")).toBe(true);
  });

  it("isOwnedByThisInstance returns false for unknown (unclaimed) sessions", () => {
    // Unknown key: no owner → treated as unowned (not this instance)
    expect(registry.isOwnedByThisInstance("unknown:session:mode")).toBe(false);
  });

  // ── listActive ────────────────────────────────────────────────────────────

  it("listActive returns all registered sessions", () => {
    registry.register("user:a:sdlc", { mode: "sdlc", projectId: "default" });
    registry.register("user:b:sdlc", { mode: "sdlc", projectId: "proj2" });

    const list = registry.listActive();
    expect(list).toHaveLength(2);
    expect(list.map((e) => e.sessionKey).sort()).toEqual(["user:a:sdlc", "user:b:sdlc"].sort());
  });

  it("listActive returns empty array when no sessions registered", () => {
    expect(registry.listActive()).toHaveLength(0);
  });

  // ── TTL expiry ────────────────────────────────────────────────────────────

  it("lookup returns null for expired entries", async () => {
    const shortRegistry = new InMemorySessionRegistry(1); // 1ms TTL
    shortRegistry._stopSweep();
    shortRegistry.register("user:session1:sdlc", { mode: "sdlc", projectId: "default" });

    await new Promise((r) => setTimeout(r, 50)); // Wait for TTL to expire

    expect(shortRegistry.lookup("user:session1:sdlc")).toBeNull();
  });

  it("listActive filters out expired entries via sweep", async () => {
    const shortRegistry = new InMemorySessionRegistry(1); // 1ms TTL
    shortRegistry._stopSweep();
    shortRegistry.register("user:session1:sdlc", { mode: "sdlc", projectId: "default" });

    await new Promise((r) => setTimeout(r, 50));

    expect(shortRegistry.listActive()).toHaveLength(0); // sweep runs in listActive
  });
});
