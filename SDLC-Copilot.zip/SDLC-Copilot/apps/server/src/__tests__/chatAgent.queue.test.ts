/**
 * Unit tests — chatAgent session queue (FIFO concurrency guard)
 *
 * Tests: makeSessionKey, acquireSessionSlot, releaseSessionSlot,
 *        cancelSessionQueue, getSessionQueueDepth
 *
 * These functions are pure in-memory with no I/O, safe to test in isolation.
 */
import { describe, it, expect, beforeEach } from "vitest";

// ── Inline replica of the queue logic from chatAgent.ts ───────────────────────
// We replicate rather than import to avoid SDK / SQLite initialisation side-effects.

function makeSessionKey(
  userId: string,
  sessionId: string,
  mode: string
): string {
  return `${userId}:${sessionId}:${mode}`;
}

const activeKeys = new Set<string>();
const sessionWaiters = new Map<string, Array<(granted: boolean) => void>>();

function resetQueues() {
  activeKeys.clear();
  sessionWaiters.clear();
}

function getSessionQueueDepth(key: string): number {
  return (
    (activeKeys.has(key) ? 1 : 0) + (sessionWaiters.get(key)?.length ?? 0)
  );
}

async function acquireSessionSlot(key: string): Promise<boolean> {
  if (!activeKeys.has(key)) {
    activeKeys.add(key);
    return true;
  }
  return new Promise<boolean>((resolve) => {
    const waiters = sessionWaiters.get(key) ?? [];
    waiters.push(resolve);
    sessionWaiters.set(key, waiters);
  });
}

function releaseSessionSlot(key: string): void {
  const waiters = sessionWaiters.get(key) ?? [];
  const next = waiters.shift();
  if (next) {
    sessionWaiters.set(key, waiters);
    next(true);
  } else {
    sessionWaiters.delete(key);
    activeKeys.delete(key);
  }
}

function cancelSessionQueue(key: string): void {
  const waiters = sessionWaiters.get(key) ?? [];
  waiters.forEach((resolve) => resolve(false));
  sessionWaiters.delete(key);
  activeKeys.delete(key);
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe("makeSessionKey", () => {
  it("produces correct composite key", () => {
    expect(makeSessionKey("user1", "sess-abc", "chat")).toBe(
      "user1:sess-abc:chat"
    );
  });

  it("different users produce different keys for same session id", () => {
    const k1 = makeSessionKey("alice", "sess-1", "chat");
    const k2 = makeSessionKey("bob", "sess-1", "chat");
    expect(k1).not.toBe(k2);
  });
});

describe("session slot queue", () => {
  beforeEach(() => resetQueues());

  it("grants first acquire immediately (depth becomes 1)", async () => {
    const key = "u:s:chat";
    const granted = await acquireSessionSlot(key);
    expect(granted).toBe(true);
    expect(getSessionQueueDepth(key)).toBe(1);
  });

  it("second acquire becomes a waiter (depth becomes 2)", async () => {
    const key = "u:s:chat";
    const first = acquireSessionSlot(key); // sets active
    const second = acquireSessionSlot(key); // enqueues

    // Only resolve first so second keeps waiting
    await first;
    expect(getSessionQueueDepth(key)).toBe(2);

    // Cleanup
    releaseSessionSlot(key);
    await second;
    releaseSessionSlot(key);
  });

  it("releasing the active slot grants it to the next waiter", async () => {
    const key = "u:s:ud";
    let secondGranted = false;

    await acquireSessionSlot(key); // active slot held

    const secondPromise = acquireSessionSlot(key).then((g) => {
      secondGranted = g;
    });

    expect(secondGranted).toBe(false); // still waiting

    releaseSessionSlot(key); // triggers next waiter
    await secondPromise;
    expect(secondGranted).toBe(true);

    releaseSessionSlot(key);
  });

  it("releasing with no waiters clears the active slot", () => {
    const key = "u:s:sdlc";
    activeKeys.add(key);
    releaseSessionSlot(key);
    expect(activeKeys.has(key)).toBe(false);
    expect(getSessionQueueDepth(key)).toBe(0);
  });

  it("cancelSessionQueue resolves all waiters with false", async () => {
    const key = "u:s:chat";
    await acquireSessionSlot(key); // active

    const results: boolean[] = [];
    const p1 = acquireSessionSlot(key).then((g) => results.push(g));
    const p2 = acquireSessionSlot(key).then((g) => results.push(g));

    cancelSessionQueue(key);
    await Promise.all([p1, p2]);

    expect(results).toEqual([false, false]);
    expect(getSessionQueueDepth(key)).toBe(0);
  });

  it("queue depth is zero after acquiring and releasing", async () => {
    const key = "u:s:chat";
    await acquireSessionSlot(key);
    releaseSessionSlot(key);
    expect(getSessionQueueDepth(key)).toBe(0);
  });
});
