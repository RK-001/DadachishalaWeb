/**
 * Unit tests — Build Context (Phase 3 preparation)
 *
 * Tests: buildPriorStageContext truncation and XML wrapping,
 *        stripMarkdownForContext formatting removal,
 *        MAX_PRIOR_CONTEXT_CHARS enforcement
 */
import { describe, it, expect } from "vitest";
import {
  buildPriorStageContext,
  stripMarkdownForContext,
  MAX_PRIOR_CONTEXT_CHARS,
} from "../lib/build-context.js";

describe("stripMarkdownForContext", () => {
  it("removes headers (# ## ###) and replaces with colons", () => {
    const input = "# Main Title\n## Subsection\n### Details";
    const result = stripMarkdownForContext(input);
    expect(result).toBe("Main Title:\nSubsection:\nDetails:");
  });

  it("removes bold and italic markers", () => {
    const input = "This is **bold** and *italic* and __underline__ and _slant_.";
    const result = stripMarkdownForContext(input);
    expect(result).toBe("This is bold and italic and underline and slant.");
  });

  it("converts bullet points to dots", () => {
    const input = "- Item one\n- Item two\n* Item three";
    const result = stripMarkdownForContext(input);
    expect(result).toContain("• Item one");
    expect(result).toContain("• Item two");
    expect(result).toContain("• Item three");
  });

  it("removes blockquote markers", () => {
    const input = "> This is a quote\n> Continued";
    const result = stripMarkdownForContext(input);
    expect(result).toContain("This is a quote");
    expect(result).toContain("Continued");
    expect(result).not.toContain(">");
  });

  it("collapses multiple newlines to single newline", () => {
    const input = "Line 1\n\n\n\nLine 2\n\n\nLine 3";
    const result = stripMarkdownForContext(input);
    expect(result).toBe("Line 1\nLine 2\nLine 3");
  });
});

describe("buildPriorStageContext", () => {
  it("short content passes through unchanged within XML wrapper", () => {
    const content = "# Design\n\nThe system uses TypeScript.\n\n- Point 1\n- Point 2";
    const result = buildPriorStageContext("design", content);

    expect(result).toContain('<prior_stage_context stage="design">');
    expect(result).toContain("</prior_stage_context>");
    expect(result).toContain("The system uses TypeScript.");
    expect(result).toContain("• Point 1");
    expect(result).toContain("• Point 2");
    expect(result).not.toContain("[... content summarized");
  });

  it("includes correct stage attribute in XML wrapper", () => {
    const content = "Some content";
    const result = buildPriorStageContext("requirements", content);

    expect(result).toContain('<prior_stage_context stage="requirements">');
  });

  it("truncates content exceeding MAX_PRIOR_CONTEXT_CHARS with bridge", () => {
    // Create content that exceeds the limit
    const longContent = "A".repeat(4000);
    const result = buildPriorStageContext("design", longContent);

    expect(result).toContain("[... content summarized for context efficiency ...]");
    expect(result).toContain("</prior_stage_context>");
    // Check that it follows the bridge pattern: first 2500 + ... + last 300
    expect(result).toContain('AAAA'); // first part
    expect(result).toContain('AAAA'); // last part (visible after bridge)
  });

  it("respects MAX_PRIOR_CONTEXT_CHARS hard cap", () => {
    const longContent = "Content: ".repeat(500); // Ensure very long content
    const result = buildPriorStageContext("analysis", longContent);

    // Strip the XML wrapper tags to measure internal content length
    const stripped = result
      .replace(/<prior_stage_context[^>]*>\n?/, "")
      .replace(/\n?<\/prior_stage_context>/, "");

    // The cap should be enforced
    expect(stripped.length).toBeLessThanOrEqual(MAX_PRIOR_CONTEXT_CHARS + "[... content summarized for context efficiency ...]\n\n".length);
  });

  it("combines markdown stripping and truncation correctly", () => {
    const contentWithMarkdown = `# Phase 1 Report

## Requirements
- User auth required
- **3-tier** system
- Works on _all platforms_

## Implementation
\`\`\`
const code = "here";
\`\`\`

${"Extra content ".repeat(200)}
`;

    const result = buildPriorStageContext("phase1", contentWithMarkdown);

    expect(result).toContain('<prior_stage_context stage="phase1">');
    // Markdown should be stripped
    expect(result).not.toContain("##");
    expect(result).not.toContain("**");
    // Content removed
    expect(result).not.toContain("```");
  });
});
