﻿/**
 * Unit tests — Metrics Collector handler
 *
 * Tests: tool_start  recordToolCall, done  recordLatency,
 *        error  recordError, tool_complete  auditLog,
 *        idempotent initialization (only registers once)
 *
 * Isolated — no DB, no SDK.
 *
 * vi.mock factories are hoisted to the top before any const declarations.
 * Outer-scope variables are NOT accessible inside vi.mock factories — use
 * vi.fn() directly inside them, then access via vi.mocked() in assertions.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

//  Mock modules (vi.fn() inline — NOT outer-scope variables) 

vi.mock("../lib/health.js", () => ({
  metrics: {
    recordToolCall: vi.fn(),
    recordLatency: vi.fn(),
    recordError: vi.fn(),
    recordRequest: vi.fn(),
  },
}));

vi.mock("../lib/db.js", () => ({
  auditLog: vi.fn(),
  db: { prepare: vi.fn(() => ({ run: vi.fn() })) },
  findMostRecentSessionKey: vi.fn(() => null),
  initDb: vi.fn(),
}));

vi.mock("../lib/logger.js", () => ({
  default: { info: vi.fn(), warn: vi.fn(), debug: vi.fn(), error: vi.fn() },
  logger: { info: vi.fn(), warn: vi.fn(), debug: vi.fn(), error: vi.fn() },
  AppError: class AppError extends Error {
    constructor(message: string, public code: string, public statusCode: number) {
      super(message);
    }
  },
  sanitizeError: (e: Error) => ({ message: (e as Error).message }),
}));

import { metrics } from "../lib/health.js";
import { auditLog } from "../lib/db.js";
import { eventBus } from "../lib/event-bus.js";
import { initMetricsCollector } from "../lib/event-handlers/metrics-collector.js";

const SESSION_KEY = "hash123:sess1:sdlc";

describe("initMetricsCollector", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("tool_start event records tool call in metrics", () => {
    initMetricsCollector();

    eventBus.emit("tool_start", SESSION_KEY, {
      toolName: "fetch_kb_file",
      toolCallId: "tc1",
      label: "Fetching INDEX.md...",
    });

    expect(vi.mocked(metrics.recordToolCall)).toHaveBeenCalledWith("fetch_kb_file");
  });

  it("tool_complete event writes audit log entry", () => {
    initMetricsCollector();

    eventBus.emit("tool_complete", SESSION_KEY, {
      toolName: "fetch_kb_file",
      toolCallId: "tc1",
      label: "INDEX.md",
      success: true,
      latencyMs: 150,
    }, "req-id-1");

    expect(vi.mocked(auditLog)).toHaveBeenCalledWith(
      expect.objectContaining({
        action: "tool_call",
        resource: "fetch_kb_file",
        requestId: "req-id-1",
      })
    );
  });

  it("done event records latency with correct mode", () => {
    initMetricsCollector();

    eventBus.emit("done", SESSION_KEY, { latencyMs: 2500, mode: "sdlc" });

    expect(vi.mocked(metrics.recordLatency)).toHaveBeenCalledWith("sdlc", 2500);
  });

  it("error event records error with mode extracted from sessionKey", () => {
    initMetricsCollector();
    // sessionKey format: userId:sessionId:mode => last segment is mode
    eventBus.emit("error", "hash123:sess1:sdlc", { message: "Something broke" }, "req-id-2");

    expect(vi.mocked(metrics.recordError)).toHaveBeenCalledWith("sdlc", "Something broke", "req-id-2");
  });

  it("is idempotent — calling initMetricsCollector twice doesn't double-count events", () => {
    initMetricsCollector();
    initMetricsCollector(); // second call should be no-op

    eventBus.emit("tool_start", SESSION_KEY, {
      toolName: "fetch_kb_file",
      toolCallId: "tc1",
      label: "Fetching...",
    });

    // Should only be called once even though init was called twice
    expect(vi.mocked(metrics.recordToolCall)).toHaveBeenCalledTimes(1);
  });

  it("chunk events are ignored by the collector", () => {
    initMetricsCollector();

    eventBus.emit("chunk", SESSION_KEY, { content: "Hello" });

    expect(vi.mocked(metrics.recordToolCall)).not.toHaveBeenCalled();
    expect(vi.mocked(metrics.recordLatency)).not.toHaveBeenCalled();
    expect(vi.mocked(metrics.recordError)).not.toHaveBeenCalled();
    expect(vi.mocked(auditLog)).not.toHaveBeenCalled();
  });
});
