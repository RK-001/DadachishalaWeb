/**
 * Unit tests — SSE Writer handler
 *
 * Tests: correct SSE event formatting for each SkillEventType,
 *        special handling for tool_complete_with_work_item and _with_attachment,
 *        unknown event types return null (dropped),
 *        heartbeat management (cleanup stops interval)
 *
 * Uses a mock Response and a fresh EventBus instance per test.
 * Isolated — no DB, no SDK, no network.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

// ── Inline formatEvent logic to test without spinning up the full server ──────
// We extract and test the formatting logic independently.

type SkillEventType =
  | "chunk" | "tool_start" | "tool_complete" | "ud_file_ready"
  | "work_item_loaded" | "ud_attached" | "skill_fallback" | "session_evicted"
  | "done" | "error" | "status";

interface MockEvent {
  type: SkillEventType;
  data: unknown;
  sessionKey: string;
  requestId?: string;
  timestamp: string;
}

function formatEvent(event: MockEvent): { type: string; data: string } | null {
  const { type } = event;
  switch (type) {
    case "chunk":
      return { type: "chunk", data: (event.data as { content: string }).content };
    case "tool_start":
      return { type: "tool_start", data: (event.data as { label: string }).label };
    case "tool_complete": {
      const d = event.data as { label: string; success: boolean; result?: { content?: string } };
      if (d.label.startsWith("fetch_azure_work_item:") && d.success && d.result?.content) {
        return { type: "tool_complete_with_work_item", data: JSON.stringify(d) };
      }
      if (d.label.startsWith("attach_ud_to_work_item:") && d.success && d.result?.content) {
        return { type: "tool_complete_with_attachment", data: JSON.stringify(d) };
      }
      return { type: "tool_complete", data: d.success ? `Loaded ${d.label}` : `Failed to load ${d.label}` };
    }
    case "ud_file_ready":
      return { type: "ud_file_ready", data: JSON.stringify(event.data) };
    case "work_item_loaded":
      return { type: "work_item_loaded", data: JSON.stringify(event.data) };
    case "ud_attached":
      return { type: "ud_attached", data: JSON.stringify(event.data) };
    case "done":
      return { type: "done", data: "" };
    case "error":
      return { type: "error", data: (event.data as { message: string }).message };
    case "status":
      return { type: "status", data: (event.data as { message: string }).message };
    case "skill_fallback": {
      const d = event.data as { from: string; to: string };
      return { type: "status", data: `Routing to fallback mode (${d.to}) due to skill degradation.` };
    }
    case "session_evicted":
      return { type: "status", data: "Session was reset and will be recreated on next message." };
    default:
      return null;
  }
}

function makeEvent(type: SkillEventType, data: unknown): MockEvent {
  return { type, data, sessionKey: "user:sess1:sdlc", timestamp: new Date().toISOString() };
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe("formatEvent (SSE writer logic)", () => {
  it("chunk → {type:'chunk', data: content}", () => {
    const result = formatEvent(makeEvent("chunk", { content: "Hello world" }));
    expect(result).toEqual({ type: "chunk", data: "Hello world" });
  });

  it("tool_start → {type:'tool_start', data: label}", () => {
    const result = formatEvent(makeEvent("tool_start", { toolName: "fetch_kb_file", toolCallId: "abc", label: "Fetching INDEX.md..." }));
    expect(result).toEqual({ type: "tool_start", data: "Fetching INDEX.md..." });
  });

  it("tool_complete for kb file → status message", () => {
    const result = formatEvent(makeEvent("tool_complete", {
      toolName: "fetch_kb_file", toolCallId: "abc", label: "INDEX.md",
      success: true, latencyMs: 100
    }));
    expect(result).toEqual({ type: "tool_complete", data: "Loaded INDEX.md" });
  });

  it("tool_complete for kb file failure → failure message", () => {
    const result = formatEvent(makeEvent("tool_complete", {
      toolName: "fetch_kb_file", toolCallId: "abc", label: "MISSING.md",
      success: false, latencyMs: 50
    }));
    expect(result).toEqual({ type: "tool_complete", data: "Failed to load MISSING.md" });
  });

  it("tool_complete for fetch_azure_work_item with result → tool_complete_with_work_item", () => {
    const workItemJson = JSON.stringify({ id: 42, title: "Test" });
    const result = formatEvent(makeEvent("tool_complete", {
      toolName: "fetch_azure_work_item", toolCallId: "abc", label: "fetch_azure_work_item:42",
      success: true, latencyMs: 200, result: { content: workItemJson }
    }));
    expect(result?.type).toBe("tool_complete_with_work_item");
  });

  it("tool_complete for attach_ud_to_work_item with result → tool_complete_with_attachment", () => {
    const attachJson = JSON.stringify({ workItemId: 42, attachmentUrl: "https://...", webUrl: "https://..." });
    const result = formatEvent(makeEvent("tool_complete", {
      toolName: "attach_ud_to_work_item", toolCallId: "abc", label: "attach_ud_to_work_item:42",
      success: true, latencyMs: 300, result: { content: attachJson }
    }));
    expect(result?.type).toBe("tool_complete_with_attachment");
  });

  it("ud_file_ready → JSON stringified payload", () => {
    const payload = { filename: "UD_TEST-123.md", content: "# UD Content" };
    const result = formatEvent(makeEvent("ud_file_ready", payload));
    expect(result?.type).toBe("ud_file_ready");
    expect(JSON.parse(result!.data)).toEqual(payload);
  });

  it("done → {type:'done', data:''}", () => {
    const result = formatEvent(makeEvent("done", { latencyMs: 500, mode: "sdlc" }));
    expect(result).toEqual({ type: "done", data: "" });
  });

  it("error → {type:'error', data: message}", () => {
    const result = formatEvent(makeEvent("error", { message: "Something went wrong", code: "ERR_001" }));
    expect(result).toEqual({ type: "error", data: "Something went wrong" });
  });

  it("status → {type:'status', data: message}", () => {
    const result = formatEvent(makeEvent("status", { message: "Processing..." }));
    expect(result).toEqual({ type: "status", data: "Processing..." });
  });

  it("skill_fallback → status message with fallback mode", () => {
    const result = formatEvent(makeEvent("skill_fallback", { from: "sdlc", to: "ud" }));
    expect(result?.type).toBe("status");
    expect(result?.data).toContain("ud");
  });

  it("session_evicted → status message", () => {
    const result = formatEvent(makeEvent("session_evicted", { reason: "health" }));
    expect(result?.type).toBe("status");
    expect(result?.data.length).toBeGreaterThan(0);
  });
});
