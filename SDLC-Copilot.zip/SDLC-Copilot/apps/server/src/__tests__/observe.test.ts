/**
 * Unit tests — observe response shapes (Phase 1.2)
 *
 * Tests: MetricsService snapshot shape, ErrorEntry shape,
 *        HealthMonitor integration (markDegraded/RECOVERED),
 *        RingBuffer overflow behaviour.
 *
 * Isolated — uses inline replicas and in-memory state.
 * No DB, no SDK, no env vars required.
 */
import { describe, it, expect, beforeEach } from "vitest";

// ─── Inline MetricsService replica (mirrors lib/health.ts) ────────────────────

interface SkillMetrics {
  requestCount: number;
  errorCount: number;
  totalLatencyMs: number;
  requestsWithLatency: number;
  avgLatencyMs: number;
  lastErrorAt: string | null;
}

interface ErrorEntry {
  timestamp: string;
  skill: string;
  message: string;
  requestId?: string;
}

interface MetricsSnapshot {
  skills: Record<string, SkillMetrics>;
  toolCallCount: Record<string, number>;
  uptimeSecs: number;
  capturedAt: string;
}

class RingBuffer<T> {
  private buf: T[] = [];
  private cap: number;
  constructor(capacity: number) { this.cap = capacity; }
  push(item: T): void { if (this.buf.length >= this.cap) this.buf.shift(); this.buf.push(item); }
  all(): T[] { return [...this.buf]; }
  size(): number { return this.buf.length; }
}

class MetricsService {
  private skillMetrics: Record<string, SkillMetrics> = {};
  private toolCallCount: Record<string, number> = {};
  private errorBuffer = new RingBuffer<ErrorEntry>(50);
  private startedAt = Date.now();

  private ensure(skill: string): SkillMetrics {
    if (!this.skillMetrics[skill]) {
      this.skillMetrics[skill] = {
        requestCount: 0, errorCount: 0, totalLatencyMs: 0,
        requestsWithLatency: 0, avgLatencyMs: 0, lastErrorAt: null,
      };
    }
    return this.skillMetrics[skill];
  }

  recordRequest(skill: string): void { this.ensure(skill).requestCount++; }
  recordError(skill: string, message: string, requestId?: string): void {
    const m = this.ensure(skill);
    m.errorCount++;
    m.lastErrorAt = new Date().toISOString();
    this.errorBuffer.push({ timestamp: m.lastErrorAt, skill, message, requestId });
  }
  recordLatency(skill: string, ms: number): void {
    const m = this.ensure(skill);
    m.totalLatencyMs += ms;
    m.requestsWithLatency++;
    m.avgLatencyMs = Math.round(m.totalLatencyMs / m.requestsWithLatency);
  }
  recordToolCall(tool: string): void {
    this.toolCallCount[tool] = (this.toolCallCount[tool] ?? 0) + 1;
  }
  getSnapshot(): MetricsSnapshot {
    return {
      skills: { ...this.skillMetrics },
      toolCallCount: { ...this.toolCallCount },
      uptimeSecs: Math.floor((Date.now() - this.startedAt) / 1000),
      capturedAt: new Date().toISOString(),
    };
  }
  getErrors(): ErrorEntry[] { return this.errorBuffer.all(); }
  reset(): void {
    this.skillMetrics = {};
    this.toolCallCount = {};
    this.errorBuffer = new RingBuffer<ErrorEntry>(50);
  }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("MetricsService — snapshot shape", () => {
  let metrics: MetricsService;

  beforeEach(() => { metrics = new MetricsService(); });

  it("getSnapshot returns required top-level fields", () => {
    const snap = metrics.getSnapshot();
    expect(snap).toHaveProperty("skills");
    expect(snap).toHaveProperty("toolCallCount");
    expect(snap).toHaveProperty("uptimeSecs");
    expect(snap).toHaveProperty("capturedAt");
    expect(typeof snap.uptimeSecs).toBe("number");
    expect(typeof snap.capturedAt).toBe("string");
  });

  it("recordRequest increments requestCount for the skill", () => {
    metrics.recordRequest("sdlc");
    metrics.recordRequest("sdlc");
    expect(metrics.getSnapshot().skills["sdlc"].requestCount).toBe(2);
  });

  it("recordError increments errorCount and sets lastErrorAt", () => {
    metrics.recordError("sdlc", "boom");
    const snap = metrics.getSnapshot();
    expect(snap.skills["sdlc"].errorCount).toBe(1);
    expect(snap.skills["sdlc"].lastErrorAt).not.toBeNull();
  });

  it("recordLatency computes avgLatencyMs correctly", () => {
    metrics.recordLatency("sdlc", 100);
    metrics.recordLatency("sdlc", 200);
    expect(metrics.getSnapshot().skills["sdlc"].avgLatencyMs).toBe(150);
  });

  it("recordToolCall increments toolCallCount", () => {
    metrics.recordToolCall("fetch_kb_file");
    metrics.recordToolCall("fetch_kb_file");
    metrics.recordToolCall("create_ud_file");
    const snap = metrics.getSnapshot();
    expect(snap.toolCallCount["fetch_kb_file"]).toBe(2);
    expect(snap.toolCallCount["create_ud_file"]).toBe(1);
  });

  it("returns separate counters for different skills", () => {
    metrics.recordRequest("sdlc");
    metrics.recordRequest("ephemeral-analysis");
    const snap = metrics.getSnapshot();
    expect(snap.skills["sdlc"].requestCount).toBe(1);
    expect(snap.skills["ephemeral-analysis"].requestCount).toBe(1);
  });
});

describe("MetricsService — error ring buffer", () => {
  let metrics: MetricsService;

  beforeEach(() => { metrics = new MetricsService(); });

  it("getErrors returns recorded errors", () => {
    metrics.recordError("sdlc", "error 1", "req-a");
    metrics.recordError("sdlc", "error 2");
    const errors = metrics.getErrors();
    expect(errors).toHaveLength(2);
    expect(errors[0].message).toBe("error 1");
    expect(errors[0].requestId).toBe("req-a");
    expect(errors[1].requestId).toBeUndefined();
  });

  it("ring buffer caps at 50 entries without throwing", () => {
    const buf = new RingBuffer<ErrorEntry>(50);
    for (let i = 0; i < 60; i++) {
      buf.push({ timestamp: "", skill: "test", message: `error ${i}` });
    }
    // Buffer wraps around — size stays at cap
    expect(buf.size()).toBe(50);
    // Oldest entries are evicted — buffer now holds entries 10-59
    expect(buf.all()[0].message).toBe("error 10");
    expect(buf.all()[49].message).toBe("error 59");
  });
});

describe("Observe response shapes", () => {
  it("/observe/health shape: has skills array with required fields", () => {
    // Simulate what the route handler returns
    const mockSkillList = [
      { mode: "brd-analyst", displayName: "BRD Analyst", health: "healthy" as const, fallbackMode: null },
    ];
    const response = { skills: mockSkillList, capturedAt: new Date().toISOString() };
    expect(Array.isArray(response.skills)).toBe(true);
    expect(response.skills[0]).toHaveProperty("mode");
    expect(response.skills[0]).toHaveProperty("health");
    expect(response.skills[0]).toHaveProperty("fallbackMode");
  });

  it("/observe/sessions shape: has sessions array and count", () => {
    const mockResponse = {
      sessions: [
        { sessionKeyHash: "abc123", lastUsedAt: new Date().toISOString(), mode: "chat", isProcessing: false, queueDepth: 0 },
      ],
      totalCount: 1,
      capturedAt: new Date().toISOString(),
    };
    expect(mockResponse.totalCount).toBe(mockResponse.sessions.length);
    expect(mockResponse.sessions[0]).toHaveProperty("sessionKeyHash");
    expect(mockResponse.sessions[0]).toHaveProperty("isProcessing");
  });

  it("/observe/errors shape: has errors array and count", () => {
    const mockResponse = {
      errors: [{ timestamp: new Date().toISOString(), skill: "sdlc", message: "test error" }],
      count: 1,
      capturedAt: new Date().toISOString(),
    };
    expect(mockResponse.count).toBe(mockResponse.errors.length);
    expect(mockResponse.errors[0]).toHaveProperty("skill");
    expect(mockResponse.errors[0]).toHaveProperty("message");
  });
});
