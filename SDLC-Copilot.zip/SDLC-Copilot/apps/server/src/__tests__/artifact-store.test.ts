/**
 * Unit tests — artifact store (Phase 1.1)
 *
 * Tests: saveArtifact round-trip, getArtifact, listArtifacts,
 *        auto-version increment, filtering by session/project,
 *        artifact type CHECK constraint enforcement.
 *
 * Uses an in-memory SQLite database via vi.mock so no files are written.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mock db.ts with an in-memory SQLite instance ───────────────────────────────
vi.mock("../lib/db.js", async () => {
  const { default: Database } = await import("better-sqlite3");
  const db = new Database(":memory:");
  db.exec(`
    CREATE TABLE IF NOT EXISTS artifacts (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      session_key   TEXT NOT NULL,
      project_id    TEXT,
      filename      TEXT NOT NULL,
      content       TEXT NOT NULL,
      artifact_type TEXT NOT NULL CHECK(artifact_type IN ('ud','hld','test','release-notes')),
      version       INTEGER NOT NULL DEFAULT 1,
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);
  return { db };
});

import {
  saveArtifact,
  getArtifact,
  listArtifacts,
  getLatestArtifactVersion,
  type ArtifactRow,
} from "../lib/artifact-store.js";
import { db } from "../lib/db.js";

// ── Helpers ───────────────────────────────────────────────────────────────────────────────────

function clearArtifacts() {
  // Disable foreign keys temporarily during cleanup
  db.pragma("foreign_keys = OFF");
  db.prepare("DELETE FROM artifacts").run();
  db.pragma("foreign_keys = ON");
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe("saveArtifact + getArtifact round-trip", () => {
  beforeEach(clearArtifacts);

  it("saves a UD artifact and retrieves it by id", () => {
    const id = saveArtifact({
      sessionKey: "user1:sess1:sdlc",
      projectId: "default",
      filename: "UD_WI-100.md",
      content: "# UD Content",
      artifactType: "ud",
    });

    expect(id).toBeGreaterThan(0);
    const row = getArtifact(id);
    expect(row).not.toBeNull();
    expect(row!.filename).toBe("UD_WI-100.md");
    expect(row!.content).toBe("# UD Content");
    expect(row!.artifact_type).toBe("ud");
    expect(row!.version).toBe(1);
    expect(row!.project_id).toBe("default");
  });

  it("returns null for a non-existent id", () => {
    expect(getArtifact(999999)).toBeNull();
  });

  it("saves with null projectId", () => {
    const id = saveArtifact({
      sessionKey: "s:x:sdlc",
      filename: "UD_NO_PROJ.md",
      content: "content",
      artifactType: "ud",
    });
    const row = getArtifact(id);
    expect(row!.project_id).toBeNull();
  });
});

describe("auto-version increment", () => {
  beforeEach(clearArtifacts);

  it("first save for a filename gets version 1", () => {
    const id = saveArtifact({
      sessionKey: "s:v:sdlc",
      filename: "UD_V.md",
      content: "v1",
      artifactType: "ud",
    });
    expect(getArtifact(id)!.version).toBe(1);
  });

  it("second save for the same filename in the same session gets version 2", () => {
    saveArtifact({ sessionKey: "s:v:sdlc", filename: "UD_V.md", content: "v1", artifactType: "ud" });
    const id2 = saveArtifact({ sessionKey: "s:v:sdlc", filename: "UD_V.md", content: "v2", artifactType: "ud" });
    expect(getArtifact(id2)!.version).toBe(2);
  });

  it("version resets for the same filename in a different session", () => {
    saveArtifact({ sessionKey: "session-A", filename: "UD.md", content: "A", artifactType: "ud" });
    const id = saveArtifact({ sessionKey: "session-B", filename: "UD.md", content: "B", artifactType: "ud" });
    expect(getArtifact(id)!.version).toBe(1);
  });

  it("getLatestArtifactVersion returns 0 for unknown session+filename", () => {
    expect(getLatestArtifactVersion("no-session", "no-file.md")).toBe(0);
  });

  it("explicit version overrides auto-increment", () => {
    const id = saveArtifact({
      sessionKey: "s:exp:sdlc",
      filename: "UD.md",
      content: "pinned",
      artifactType: "ud",
      version: 7,
    });
    expect(getArtifact(id)!.version).toBe(7);
  });
});

describe("listArtifacts filtering", () => {
  beforeEach(clearArtifacts);

  it("lists all artifacts when no filter provided", () => {
    saveArtifact({ sessionKey: "s1", projectId: "p1", filename: "a.md", content: "x", artifactType: "ud" });
    saveArtifact({ sessionKey: "s2", projectId: "p2", filename: "b.md", content: "y", artifactType: "ud" });
    expect(listArtifacts()).toHaveLength(2);
  });

  it("filters by sessionKey", () => {
    saveArtifact({ sessionKey: "s1", filename: "a.md", content: "x", artifactType: "ud" });
    saveArtifact({ sessionKey: "s2", filename: "b.md", content: "y", artifactType: "ud" });
    const results = listArtifacts({ sessionKey: "s1" });
    expect(results).toHaveLength(1);
    expect(results[0].session_key).toBe("s1");
  });

  it("filters by projectId", () => {
    saveArtifact({ sessionKey: "s1", projectId: "proj-x", filename: "a.md", content: "x", artifactType: "ud" });
    saveArtifact({ sessionKey: "s2", projectId: "proj-y", filename: "b.md", content: "y", artifactType: "ud" });
    const results = listArtifacts({ projectId: "proj-x" });
    expect(results).toHaveLength(1);
    expect(results[0].project_id).toBe("proj-x");
  });

  it("filters by both sessionKey and projectId", () => {
    saveArtifact({ sessionKey: "s1", projectId: "p1", filename: "a.md", content: "content", artifactType: "ud" });
    saveArtifact({ sessionKey: "s1", projectId: "p2", filename: "b.md", content: "content", artifactType: "ud" });
    const results = listArtifacts({ sessionKey: "s1", projectId: "p1" });
    expect(results).toHaveLength(1);
  });

  it("returns empty array when no artifacts match", () => {
    expect(listArtifacts({ sessionKey: "no-such-session" })).toHaveLength(0);
  });

  it("respects limit parameter (default 50)", () => {
    for (let i = 0; i < 5; i++) {
      saveArtifact({ sessionKey: "s:limit", filename: `f${i}.md`, content: "c", artifactType: "ud" });
    }
    expect(listArtifacts({ limit: 3 })).toHaveLength(3);
  });

  it("returns newest artifact first (DESC order)", () => {
    saveArtifact({ sessionKey: "s:order", filename: "first.md", content: "c1", artifactType: "ud" });
    saveArtifact({ sessionKey: "s:order", filename: "second.md", content: "c2", artifactType: "ud" });
    const results = listArtifacts({ sessionKey: "s:order" });
    expect(results[0].filename).toBe("second.md");
  });
});
