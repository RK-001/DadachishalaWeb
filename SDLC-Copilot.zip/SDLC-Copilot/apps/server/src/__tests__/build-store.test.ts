/**
 * Unit tests — Build Store (Phase 3)
 *
 * Tests: createBuild, getBuild, listBuilds, updateBuildStage,
 *        linkArtifactToBuild, getBuildArtifactIdForStage,
 *        addBuildApproval, getLatestApproval, archiveBuild
 */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import Database from "better-sqlite3";
import path from "path";
import os from "os";
import fs from "fs";

// ── Use a temp in-memory-backed DB for isolation ───────────────────────────────
// We need to swap the exported `db` from db.ts to a fresh instance.
// Use the vitest module mock approach via a fresh isolated module.

let tmpDbPath: string;

// We import these AFTER setting up the test DB path env var
import {
  createBuild,
  getBuild,
  listBuilds,
  updateBuildStage,
  archiveBuild,
  linkArtifactToBuild,
  getBuildArtifactIdForStage,
  addBuildApproval,
  getLatestApproval,
} from "../lib/build-store.js";

import { db, initDb } from "../lib/db.js";
import { initBuildDb } from "../lib/build-db.js";

describe("build-store", () => {
  beforeEach(() => {
    try {
      initDb();
      initBuildDb();
    } catch {
      // Tables may already exist — idempotent
    }
    // Seed default project to satisfy FK constraint on builds.project_id
    db.prepare(`INSERT OR IGNORE INTO projects (id, name, enabled_modes) VALUES ('default', 'Test Project', 'chat')`).run();
  });

  it("createBuild returns a Build with brd_intake stage", () => {
    const build = createBuild({
      projectId: "default",
      title: "Test Feature",
      description: "A test build",
      createdBy: "test-user",
    });

    expect(build.id).toBeTruthy();
    expect(build.title).toBe("Test Feature");
    expect(build.currentStage).toBe("brd_intake");
    expect(build.status).toBe("active");
    expect(build.isArchived).toBe(false);
  });

  it("getBuild returns null for missing ID", () => {
    expect(getBuild("nonexistent-id")).toBeNull();
  });

  it("getBuild retrieves a created build", () => {
    const created = createBuild({
      projectId: "default",
      title: "Fetch Test",
      createdBy: "tester",
    });

    const fetched = getBuild(created.id);
    expect(fetched).not.toBeNull();
    expect(fetched!.id).toBe(created.id);
    expect(fetched!.title).toBe("Fetch Test");
  });

  it("listBuilds returns builds for projectId", () => {
    createBuild({ projectId: "default", title: "Build A", createdBy: "u1" });
    createBuild({ projectId: "default", title: "Build B", createdBy: "u2" });

    const results = listBuilds({ projectId: "default" });
    const titles = results.map((b) => b.title);
    expect(titles).toContain("Build A");
    expect(titles).toContain("Build B");
  });

  it("updateBuildStage transitions stage", () => {
    const build = createBuild({
      projectId: "default",
      title: "Stage Test",
      createdBy: "u1",
    });

    updateBuildStage(build.id, "brd_approved");
    const updated = getBuild(build.id);
    expect(updated!.currentStage).toBe("brd_approved");
  });

  it("archiveBuild soft-deletes (getBuild returns null)", () => {
    const build = createBuild({
      projectId: "default",
      title: "Archive Test",
      createdBy: "u1",
    });

    archiveBuild(build.id);
    expect(getBuild(build.id)).toBeNull();
  });

  it("linkArtifactToBuild and getBuildArtifactIdForStage", async () => {
    const build = createBuild({
      projectId: "default",
      title: "Artifact Link Test",
      createdBy: "u1",
    });

    // Insert a fake artifact directly into the DB
    const fakeArtifactId = (db.prepare(`
      INSERT INTO artifacts (session_key, filename, content, artifact_type, version)
      VALUES ('test-key', 'test.md', 'content', 'brd', 1)
    `).run().lastInsertRowid) as number;

    linkArtifactToBuild(build.id, "brd_intake", fakeArtifactId);
    const retrieved = getBuildArtifactIdForStage(build.id, "brd_intake");
    expect(retrieved).toBe(fakeArtifactId);
  });

  it("addBuildApproval and getLatestApproval", () => {
    const build = createBuild({
      projectId: "default",
      title: "Approval Test",
      createdBy: "u1",
    });

    addBuildApproval({
      buildId: build.id,
      stage: "brd_intake",
      approvedBy: "product-owner",
      decision: "approved",
      comments: "Looks good",
    });

    const approval = getLatestApproval(build.id, "brd_intake");
    expect(approval).not.toBeNull();
    expect(approval!.decision).toBe("approved");
    expect(approval!.approvedBy).toBe("product-owner");
    expect(approval!.comments).toBe("Looks good");
  });

  it("getLatestApproval returns null when no approval exists", () => {
    const build = createBuild({
      projectId: "default",
      title: "No Approval",
      createdBy: "u1",
    });

    expect(getLatestApproval(build.id, "brd_intake")).toBeNull();
  });
});
