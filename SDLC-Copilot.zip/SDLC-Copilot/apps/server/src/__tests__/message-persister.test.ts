/**
 * Unit tests — Message Persister handler
 *
 * Tests: accumulates chunks then saves on done,
 *        unsubscribes after done,
 *        unsubscribes after error (no save),
 *        handles empty assistant content gracefully,
 *        does not persist tool events as assistant messages
 *
 * Uses a fresh EventBus and mocked saveMessage.
 * Isolated — no DB, no SDK.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// vi.hoisted ensures the mock variable is available when vi.mock factory runs
const { mockSaveMessage } = vi.hoisted(() => ({
  mockSaveMessage: vi.fn(),
}));

vi.mock("../lib/message-store.js", () => ({
  saveMessage: mockSaveMessage,
}));

vi.mock("../lib/db.js", () => ({
  // db is used by other imports, provide a stub
  db: { prepare: vi.fn(() => ({ run: vi.fn() })) },
  auditLog: vi.fn(),
  findMostRecentSessionKey: vi.fn(() => null),
  initDb: vi.fn(),
}));

vi.mock("../lib/logger.js", () => ({
  default: { info: vi.fn(), warn: vi.fn(), debug: vi.fn(), error: vi.fn() },
  logger: { info: vi.fn(), warn: vi.fn(), debug: vi.fn(), error: vi.fn() },
  AppError: class AppError extends Error {
    constructor(message: string, public code: string, public statusCode: number) {
      super(message);
    }
  },
  sanitizeError: (e: Error) => ({ message: e.message }),
}));

import { eventBus } from "../lib/event-bus.js";
import { createMessagePersister } from "../lib/event-handlers/message-persister.js";

const SESSION_KEY = "user:sess1:sdlc";
const META = { userIdHash: "user", projectId: "default", mode: "sdlc" };

describe("createMessagePersister", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("accumulates chunks and saves assistant message on done", () => {
    createMessagePersister(SESSION_KEY, META);

    eventBus.emit("chunk", SESSION_KEY, { content: "Hello " });
    eventBus.emit("chunk", SESSION_KEY, { content: "world" });
    eventBus.emit("done", SESSION_KEY, { latencyMs: 100, mode: "sdlc" });

    expect(mockSaveMessage).toHaveBeenCalledWith(
      expect.objectContaining({
        sessionKey: SESSION_KEY,
        role: "assistant",
        content: "Hello world",
        mode: "sdlc",
      })
    );
  });

  it("does not call saveMessage when no assistant content was received", () => {
    createMessagePersister(SESSION_KEY, META);

    eventBus.emit("done", SESSION_KEY, { latencyMs: 10, mode: "sdlc" });

    expect(mockSaveMessage).not.toHaveBeenCalled();
  });

  it("does not save assistant message after error", () => {
    createMessagePersister(SESSION_KEY, META);

    eventBus.emit("chunk", SESSION_KEY, { content: "partial" });
    eventBus.emit("error", SESSION_KEY, { message: "Stream error" });

    expect(mockSaveMessage).not.toHaveBeenCalled();
  });

  it("unsubscribes after done (no leak — second done is ignored)", () => {
    createMessagePersister(SESSION_KEY, META);

    eventBus.emit("chunk", SESSION_KEY, { content: "first" });
    eventBus.emit("done", SESSION_KEY, { latencyMs: 10, mode: "sdlc" });

    const callCountAfterFirst = mockSaveMessage.mock.calls.length;

    // Second done should not trigger another save
    eventBus.emit("chunk", SESSION_KEY, { content: "should be ignored" });
    eventBus.emit("done", SESSION_KEY, { latencyMs: 10, mode: "sdlc" });

    expect(mockSaveMessage.mock.calls.length).toBe(callCountAfterFirst);
  });

  it("cleanup() function unsubscribes the handler", () => {
    const cleanup = createMessagePersister(SESSION_KEY, META);

    eventBus.emit("chunk", SESSION_KEY, { content: "text" });
    cleanup(); // manually unsubscribe
    eventBus.emit("done", SESSION_KEY, { latencyMs: 10, mode: "sdlc" });

    expect(mockSaveMessage).not.toHaveBeenCalled();
  });

  it("only handles events for the registered sessionKey", () => {
    createMessagePersister(SESSION_KEY, META);

    // Events for a different session should not trigger save
    eventBus.emit("chunk", "user:OTHER:sdlc", { content: "other session" });
    eventBus.emit("done", "user:OTHER:sdlc", { latencyMs: 10, mode: "sdlc" });

    expect(mockSaveMessage).not.toHaveBeenCalled();
  });
});
