/**
 * Unit tests — project store CRUD (Phase 1.3)
 *
 * Tests: listProjects, createProject, updateProject, deleteProject,
 *        default project protection, cache invalidation, persistence.
 *
 * Uses an in-memory SQLite database via vi.mock.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mock db.ts with in-memory SQLite ──────────────────────────────────────────
vi.mock("../lib/db.js", async () => {
  const { default: Database } = await import("better-sqlite3");
  const db = new Database(":memory:");
  db.exec(`
    CREATE TABLE IF NOT EXISTS projects (
      id            TEXT PRIMARY KEY,
      name          TEXT NOT NULL,
      kb_repo_owner TEXT,
      kb_repo_name  TEXT,
      kb_repo_ref   TEXT NOT NULL DEFAULT 'main',
      ado_org       TEXT,
      ado_project   TEXT,
      enabled_modes TEXT NOT NULL DEFAULT 'sdlc',
      model         TEXT,
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);
  // Seed default project (mirrors project-store.ts upsertDefaultProject)
  db.prepare(
    `INSERT OR IGNORE INTO projects (id, name, enabled_modes)
     VALUES ('default', 'Default Project', 'sdlc')`
  ).run();
  return { db };
});

import {
  getProject,
  listProjects,
  createProject,
  updateProject,
  deleteProject,
  invalidateProjectCache,
} from "../lib/project-store.js";
import { db } from "../lib/db.js";

// ── Helpers ───────────────────────────────────────────────────────────────────────────────────

/** Reset to only the default project between tests */
function resetProjects() {
  db.exec("DELETE FROM projects WHERE id != 'default'");
  // Clear the in-proc cache by invalidating any created ids
  invalidateProjectCache("default");
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe("listProjects", () => {
  beforeEach(resetProjects);

  it("returns at least the default project", () => {
    const projects = listProjects();
    expect(projects.length).toBeGreaterThanOrEqual(1);
    expect(projects.some((p) => p.id === "default")).toBe(true);
  });

  it("includes a freshly created project in the list", () => {
    createProject({ id: "proj-alpha", name: "Alpha Project" });
    const projects = listProjects();
    expect(projects.some((p) => p.id === "proj-alpha")).toBe(true);
  });
});

describe("createProject", () => {
  beforeEach(resetProjects);

  it("creates a project and retrieves it by id", () => {
    createProject({
      id: "proj-1",
      name: "Test Project",
      kbRepoOwner: "myorg",
      kbRepoName: "my-kb",
      enabledModes: ["sdlc", "ud"],
    });

    invalidateProjectCache("proj-1"); // ensure fresh read
    const project = getProject("proj-1");
    expect(project).not.toBeNull();
    expect(project!.name).toBe("Test Project");
    expect(project!.kbRepoOwner).toBe("myorg");
    expect(project!.enabledModes).toEqual(["sdlc", "ud"]);
  });

  it("defaults kbRepoRef to 'main' when not provided", () => {
    createProject({ id: "proj-2", name: "Defaults Test" });
    invalidateProjectCache("proj-2");
    expect(getProject("proj-2")!.kbRepoRef).toBe("main");
  });

  it("sets null for optional fields when not provided", () => {
    createProject({ id: "proj-null", name: "Null Fields" });
    invalidateProjectCache("proj-null");
    const p = getProject("proj-null");
    expect(p!.kbRepoOwner).toBeNull();
    expect(p!.model).toBeNull();
  });
});

describe("updateProject", () => {
  beforeEach(resetProjects);

  it("updates name and returns true", () => {
    createProject({ id: "proj-upd", name: "Before" });
    const ok = updateProject("proj-upd", { name: "After" });
    expect(ok).toBe(true);
    invalidateProjectCache("proj-upd");
    expect(getProject("proj-upd")!.name).toBe("After");
  });

  it("returns false for unknown id", () => {
    expect(updateProject("no-such-project", { name: "X" })).toBe(false);
  });

  it("returns false when updating with no fields (empty partial)", () => {
    createProject({ id: "proj-empty", name: "E" });
    expect(updateProject("proj-empty", {})).toBe(false);
  });

  it("updates enabledModes list", () => {
    createProject({ id: "proj-modes", name: "Modes Test" });
    updateProject("proj-modes", { enabledModes: ["sdlc"] });
    invalidateProjectCache("proj-modes");
    expect(getProject("proj-modes")!.enabledModes).toEqual(["sdlc"]);
  });
});

describe("deleteProject", () => {
  beforeEach(resetProjects);

  it("deletes an existing project and returns true", () => {
    createProject({ id: "proj-del", name: "To Delete" });
    const ok = deleteProject("proj-del");
    expect(ok).toBe(true);
    invalidateProjectCache("proj-del");
    expect(getProject("proj-del")).toBeNull();
  });

  it("returns false for non-existent id", () => {
    expect(deleteProject("ghost-project")).toBe(false);
  });

  it("cannot delete the default project — returns false", () => {
    const ok = deleteProject("default");
    expect(ok).toBe(false);
    // Default project must still exist
    invalidateProjectCache("default");
    expect(getProject("default")).not.toBeNull();
  });
});

describe("full CRUD lifecycle", () => {
  beforeEach(resetProjects);

  it("create → get → update → list → delete — consistent state", () => {
    createProject({ id: "lifecycle", name: "Lifecycle Project" });

    invalidateProjectCache("lifecycle");
    expect(getProject("lifecycle")!.name).toBe("Lifecycle Project");

    updateProject("lifecycle", { name: "Lifecycle Renamed" });
    invalidateProjectCache("lifecycle");
    expect(getProject("lifecycle")!.name).toBe("Lifecycle Renamed");

    const list = listProjects();
    expect(list.some((p) => p.id === "lifecycle")).toBe(true);

    deleteProject("lifecycle");
    invalidateProjectCache("lifecycle");
    expect(getProject("lifecycle")).toBeNull();
  });
});
