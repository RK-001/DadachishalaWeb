﻿/**
 * Middleware — Authentication, validation, rate limiting.
 *
 * Merged from middleware/auth.ts + middleware/validate.ts + middleware/rate-limit.ts.
 *
 * Phase 0.0 — Security Prerequisites
 */

import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import rateLimit from "express-rate-limit";
import logger from "./lib/logger.js";

// ═══════════════════════════════════════════════════════════════════════════════
// Authentication
// ═══════════════════════════════════════════════════════════════════════════════

const API_KEYS: Set<string> = new Set(
  (process.env.API_KEYS || "")
    .split(",")
    .map((k) => k.trim())
    .filter(Boolean)
);

const AUTH_ENABLED = API_KEYS.size > 0;

if (!AUTH_ENABLED) {
  logger.warn("[auth] API_KEYS not set — authentication is DISABLED. Set API_KEYS in .env for production.");
}

/**
 * Timing-safe string comparison: hashes both values first so key length
 * is never revealed through early-exit timing differences.
 */
function safeCompare(a: string, b: string): boolean {
  const ha = crypto.createHash("sha256").update(a).digest();
  const hb = crypto.createHash("sha256").update(b).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function validateApiKey(key: string): boolean {
  for (const valid of API_KEYS) {
    if (safeCompare(key, valid)) return true;
  }
  return false;
}

export interface AuthenticatedRequest extends Request {
  userId: string;
}

export function authenticate(req: Request, res: Response, next: NextFunction): void {
  if (!AUTH_ENABLED) {
    (req as AuthenticatedRequest).userId = "dev";
    return next();
  }

  const apiKey = req.headers["x-api-key"];
  if (typeof apiKey === "string" && apiKey.length > 0) {
    if (validateApiKey(apiKey)) {
      (req as AuthenticatedRequest).userId = crypto
        .createHash("sha256")
        .update(apiKey)
        .digest("hex")
        .slice(0, 16);
      return next();
    }
    res.status(401).json({ error: "Invalid API key" });
    return;
  }

  const authHeader = req.headers.authorization;
  if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
    const token = authHeader.slice(7);
    if (validateApiKey(token)) {
      (req as AuthenticatedRequest).userId = crypto
        .createHash("sha256")
        .update(token)
        .digest("hex")
        .slice(0, 16);
      return next();
    }
    res.status(401).json({ error: "Invalid bearer token" });
    return;
  }

  res.status(401).json({ error: "Authentication required. Provide x-api-key header or Bearer token." });
}

// ═══════════════════════════════════════════════════════════════════════════════
// Input Validation
// ═══════════════════════════════════════════════════════════════════════════════

export const MAX_LENGTHS = {
  sessionId: 80,   // uuid(36) + "-" + stage slug (~12) = ~49; 80 gives headroom
  message: 32_000,
  projectId: 64,
} as const;

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const SAFE_STRING_RE = /^[a-zA-Z0-9._\-/]+$/;

export function isValidUUID(value: string): boolean {
  return UUID_RE.test(value);
}

export function isValidString(value: unknown, maxLength: number): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= maxLength;
}

export function isSafePathSegment(value: string): boolean {
  // Disallow empty, leading slash (absolute paths), or traversal sequences
  if (!value || value.startsWith("/")) return false;
  return SAFE_STRING_RE.test(value) && !value.includes("..");
}

// ─── Repo Allowlist (SSRF protection) ──────────────────────────────────────────

// ─── Chat Request Validation ───────────────────────────────────────────────────

export const VALID_MODES = new Set([
  "brd-analyst",
  "ud",
  "impl-plan",
  "coding",
  "release",
  "chat",
  "ephemeral-analysis",
]);

export interface ValidatedChatRequest {
  sessionId: string;
  message: string;
  mode: string;
  projectId: string;
}

export function validateChatRequest(body: any): {
  valid: true;
  data: ValidatedChatRequest;
} | { valid: false; error: string } {
  const { sessionId, message, mode, projectId: rawProjectId } = body || {};

  if (!isValidString(sessionId, MAX_LENGTHS.sessionId)) {
    return { valid: false, error: `Missing or invalid 'sessionId' (max ${MAX_LENGTHS.sessionId} chars)` };
  }
  if (!isSafePathSegment(sessionId.trim())) {
    return { valid: false, error: "'sessionId' contains invalid characters" };
  }
  if (!isValidString(message, MAX_LENGTHS.message)) {
    return { valid: false, error: `Missing or invalid 'message' (max ${MAX_LENGTHS.message} chars)` };
  }
  if (mode !== undefined && !VALID_MODES.has(mode)) {
    return { valid: false, error: `Invalid 'mode' — must be one of: ${[...VALID_MODES].join(", ")}` };
  }

  const resolvedMode = (typeof mode === "string" && mode.length > 0) ? mode : "chat";

  const projectId = typeof rawProjectId === "string" && rawProjectId.trim().length > 0
    ? rawProjectId.trim()
    : "default";
  if (!isSafePathSegment(projectId) || projectId.length > MAX_LENGTHS.projectId) {
    return { valid: false, error: "Invalid 'projectId'" };
  }

  return {
    valid: true,
    data: {
      sessionId: sessionId.trim(),
      message: message.trim(),
      mode: resolvedMode,
      projectId,
    },
  };
}

// ─── Summarize Request Validation ──────────────────────────────────────────────



const INJECTION_PATTERNS: RegExp[] = [
  /ignore\s+(?:previous|above|prior|all)\s+(?:\w+\s+)*(?:instructions?|prompts?|system|context)/i,
  /disregard\s+(?:previous|above|prior|all)\s+(?:\w+\s+)*(?:instructions?|prompts?|system|context)/i,
  /forget\s+(?:previous|above|prior|all)\s+(?:\w+\s+)*(?:instructions?|prompts?|system|context)/i,
  /override\s+(?:your\s+)?(?:instructions?|role|system\s+prompt)/i,
  /you\s+are\s+now\s+(?:a|an)\s+/i,
  /pretend\s+(?:to\s+be|you\s+are)\s+/i,
  /\bact\s+as\s+(?:a|an)\s+(?!bridge|proxy|intermediary|filter|validator|coordinator)/i,
  /\[SYSTEM\]/i,
  /<\|im_start\|>/i,
  /###\s*(?:instructions?|system)\b/i,
  /---(?:new|override)\s*system/i,
  /\bDAN\s+mode\b/i,
  /\bdeveloper\s+mode\b.*\benabled\b/i,
  /your\s+real\s+instructions?\s+are/i,
  /new\s+instructions?:/i,
  // Phase 4.5 L1 additions
  /print\s+(?:your|the)\s+(?:system\s+)?(?:instructions?|prompt|configuration)/i,
  /reveal\s+(?:your|the)\s+(?:system\s+)?(?:instructions?|prompt|configuration)/i,
  /what\s+(?:are|is)\s+your\s+(?:system\s+)?(?:prompt|instructions?)/i,
  /output\s+(?:your|the)\s+(?:previous\s+)?(?:instructions?|system\s+prompt)/i,
  /<\/?(system|context|instruction|user_input|kb_content|assistant)\s*>/i,
  /\{\{.*\}\}/,  // block template injection attempts via {{placeholder}} syntax
  /\[\[.*\]\]/,  // block wiki/template bracket injection
];

export function detectInjectionAttempt(message: string): boolean {
  for (const pattern of INJECTION_PATTERNS) {
    if (pattern.test(message)) return true;
  }
  return false;
}

// ═══════════════════════════════════════════════════════════════════════════════
// Rate Limiting
// ═══════════════════════════════════════════════════════════════════════════════

const windowMs = Number(process.env.RATE_LIMIT_WINDOW_MS) || 60_000;
const max = Number(process.env.RATE_LIMIT_MAX) || 30;
const streamMax = Number(process.env.RATE_LIMIT_STREAM_MAX) || 10;

export const apiLimiter = rateLimit({
  windowMs,
  max,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests — please try again later" },
});

export const streamLimiter = rateLimit({
  windowMs,
  max: streamMax,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many streaming requests — please try again later" },
});
