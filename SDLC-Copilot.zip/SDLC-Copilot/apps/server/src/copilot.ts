/**
 * Copilot SDK wrapper
 * Manages the CopilotClient lifecycle and provides a helper
 * for chat completions.
 *
 * File fetching is done separately via GitHub REST API (see github.ts)
 * so that private repos work with a PAT. The Copilot SDK is used
 * purely for LLM summarization.
 */
import { CopilotClient } from "@github/copilot-sdk";
import logger from "./lib/logger.js";

/** Model to use for summarization */
const DEFAULT_MODEL = "claude-haiku-4.5";
// Map user-friendly dashed names → actual dot-notation API model IDs
const MODEL_ALIASES: Record<string, string> = {
  "claude-haiku-4-5": "claude-haiku-4.5",
  "claude-sonnet-4-6": "claude-sonnet-4.6",
  "claude-opus-4-6": "claude-opus-4.6",
};

export function getConfiguredModel(): string {
  const configured = (process.env.COPILOT_MODEL || DEFAULT_MODEL).trim();
  const normalized = MODEL_ALIASES[configured] || configured;

  if (normalized !== configured) {
    logger.warn({ from: configured, to: normalized }, "[copilot] Normalized model alias");
  }

  return normalized;
}

let clientInstance: CopilotClient | null = null;
let resetting = false;
let healthCheckTimer: NodeJS.Timeout | null = null;

/**
 * Reset the Copilot client after a detected failure.
 * Retries up to 3 times with exponential backoff (2 s / 5 s / 10 s).
 * Coalesced — concurrent calls are ignored while one reset is in progress.
 * On success: new client is connected. On total failure: logs error, continues.
 */
async function resetClient(): Promise<void> {
  if (resetting) return;
  resetting = true;
  logger.warn("[copilot] Health check failed — resetting client...");

  if (clientInstance) {
    try { await clientInstance.stop(); } catch { /* already stopped */ }
    clientInstance = null;
  }

  const delays = [2_000, 5_000, 10_000];
  for (let attempt = 0; attempt < delays.length; attempt++) {
    await new Promise<void>((resolve) => setTimeout(resolve, delays[attempt]));
    try {
      logger.warn({ attempt: attempt + 1 }, "[copilot] Reconnect attempt...");
      const client = await getCopilotClient();
      await client.start();
      logger.info("[copilot] Client reconnected successfully");
      resetting = false;
      return;
    } catch (err) {
      logger.error({ attempt: attempt + 1, err }, "[copilot] Reconnect attempt failed");
      clientInstance = null; // force fresh instance on next attempt
    }
  }

  logger.error("[copilot] All reconnect attempts failed — client is unhealthy");
  resetting = false;
}

/**
 * Start the background health-check loop.
 * Interval: COPILOT_HEALTH_INTERVAL_MS env var, default 120 000 ms (2 min).
 * On failure: triggers coalesced resetClient() — keeps sessions alive.
 * Called automatically by warmUpCopilotClient() on successful warm-up.
 */
function startHealthCheck(): void {
  if (healthCheckTimer) return;
  const INTERVAL_MS = Number(process.env.COPILOT_HEALTH_INTERVAL_MS) || 120_000;
  healthCheckTimer = setInterval(async () => {
    if (!clientInstance || resetting) return;
    try {
      await clientInstance.listModels();
    } catch (err) {
      logger.warn({ err }, "[copilot] Health ping failed");
      void resetClient();
    }
  }, INTERVAL_MS);
  healthCheckTimer.unref();
  logger.info({ intervalMs: INTERVAL_MS }, "[copilot] Health check started");
}

/** Get or create the singleton CopilotClient */
export async function getCopilotClient(): Promise<CopilotClient> {
  if (!clientInstance) {
    console.time("[copilot] Client init");

    // The Copilot SDK needs a token from a GitHub account with an active
    // Copilot subscription. Set COPILOT_TOKEN in .env with the gho_ OAuth
    // token from your personal account (run: gh auth token on personal account).
    // If unset, the SDK uses useLoggedInUser=true to authenticate via
    // the gh CLI's currently active account.
    const token = process.env.COPILOT_TOKEN || process.env.COPILOT_GITHUB_TOKEN;

    const options: Record<string, any> = {
      autoStart: true,   // SDK reconnects automatically on startup
      autoRestart: true, // SDK respawns CLI process if it crashes
    };
    if (token) {
      options.githubToken = token;
      logger.info("[copilot] Using explicit COPILOT_TOKEN for auth");
    } else {
      options.useLoggedInUser = true;
      logger.info("[copilot] No COPILOT_TOKEN set — using gh CLI logged-in user");
    }

    clientInstance = new CopilotClient(options);
    console.timeEnd("[copilot] Client init");
  }
  return clientInstance;
}

/** Pre-warm the client so the first request isn't slow */
export async function warmUpCopilotClient(): Promise<void> {
  try {
    logger.info("[copilot] Pre-warming client...");
    const client = await getCopilotClient();

    // Explicitly wait for the CLI connection to be established
    await client.start();
    logger.info("[copilot] Client connected");

    // List available models so we know what's valid
    try {
      const models = await client.listModels();
      logger.info({ models: models.map((m: any) => m.id || m.name || m) }, "[copilot] Available models");
    } catch (e) {
      logger.warn({ err: e }, "[copilot] Could not list models");
    }

    // Start background health monitoring after successful warm-up
    startHealthCheck();
  } catch (err) {
    logger.error({ err }, "[copilot] Warm-up failed");
  }
}

/** Stop the client (call on shutdown) */
export async function stopCopilotClient(): Promise<void> {
  if (healthCheckTimer) {
    clearInterval(healthCheckTimer);
    healthCheckTimer = null;
  }
  if (clientInstance) {
    await clientInstance.stop();
    clientInstance = null;
  }
}

/**
 * Summarize pre-fetched file content using Copilot LLM.
 *
 * This does NOT use MCP / GitHub tools — the file content is already
 * fetched via the GitHub REST API (github.ts). We just ask the model
 * to analyze and summarize the provided text.
 */
export async function summarizeFileContent(params: {
  owner: string;
  repo: string;
  filePath: string;
  ref: string;
  fileContent: string;
  onChunk?: (chunk: string) => void;
}): Promise<string> {
  const { owner, repo, filePath, ref, fileContent, onChunk } = params;
  const model = getConfiguredModel();

  // Truncate very large files to keep LLM responses fast
  const MAX_CHARS = 30_000;
  let content = fileContent;
  let truncated = false;
  if (content.length > MAX_CHARS) {
    content = content.slice(0, MAX_CHARS);
    truncated = true;
    console.log(`[copilot] File truncated from ${fileContent.length} to ${MAX_CHARS} chars`);
  }
  console.log(`[copilot] Sending ${content.length} chars to LLM`);

  console.time("[copilot] getCopilotClient");
  const client = await getCopilotClient();
  console.timeEnd("[copilot] getCopilotClient");

  const systemPrompt = `You are a code analysis assistant. Your job is to analyze the provided file content and produce a clear, well-structured summary.

When summarizing, include:
- **Purpose**: What the file/code is for
- **Key Components**: Main classes, functions, exports, or sections
- **Dependencies**: Notable imports or external dependencies
- **Architecture Notes**: Design patterns, data flow, or important decisions
- **Notable Details**: Anything else worth highlighting

Format your response in clean Markdown.`;

  const useStreaming = !!onChunk;
  console.log(`[copilot] Using model: ${model}, streaming: ${useStreaming}`);
  console.time("[copilot] createSession");
  const session = await client.createSession({
    model,
    streaming: useStreaming,
    systemMessage: {
      mode: "replace",
      content: systemPrompt,
    },
    onPermissionRequest: async (request) => {
      console.warn("[copilot] Permission requested (auto-approving):", request.kind);
      return { kind: "approved" };
    },
    onUserInputRequest: async (request) => {
      console.warn("[copilot] User input requested (auto-responding):", request.question);
      return { answer: "", wasFreeform: true };
    },
  });
  console.timeEnd("[copilot] createSession");

  // Debug: log ALL session events to see what's happening
  session.on((event: any) => {
    if (event.type !== "pending_messages.modified") {
      console.log(`[copilot] Event: ${event.type}`, event.type === "session.error" ? event.data : "");
    }
  });

  const truncateNote = truncated ? `\n\n⚠️ Note: File was truncated to first ${MAX_CHARS} characters for analysis.` : "";

  const userPrompt = `Please analyze and summarize the following file.

**Repository:** \`${owner}/${repo}\` (branch: \`${ref}\`)
**File:** \`${filePath}\`${truncateNote}

---

\`\`\`
${content}
\`\`\`

---

Provide a detailed, well-structured summary of what this file does.`;

  let fullResponse = "";

  if (onChunk) {
    session.on("assistant.message_delta", (event: any) => {
      const delta = event.data.deltaContent;
      if (delta) {
        fullResponse += delta;
        onChunk(delta);
      }
    });
  }

  try {
    console.time("[copilot] sendAndWait");
    const response = await session.sendAndWait(
      { prompt: userPrompt },
      180_000 // 3-minute timeout
    );
    console.timeEnd("[copilot] sendAndWait");

    if (!onChunk && response?.data?.content) {
      fullResponse = response.data.content;
    }

    return fullResponse;
  } finally {
    await session.destroy();
  }
}
