/**
 * Express server entry point
 * Provides REST + SSE endpoints for file summarization via Copilot SDK.
 */
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import resetRouter from "./routes/reset.js";
// Load .env from monorepo root (../../ relative to apps/server/)
const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, "../../../.env") });

import express from "express";
import cors from "cors";
import helmet from "helmet";
import pinoHttp from "pino-http";
import { randomUUID } from "crypto";
import chatRouter from "./routes/chat.js";
import observeRouter from "./routes/observe.js";
import projectsRouter from "./routes/projects.js";
import artifactsRouter from "./routes/artifacts.js";
import buildsRouter from "./routes/builds.js";
import { stopCopilotClient, warmUpCopilotClient } from "./copilot.js";
import { initializeKnowledgeBase } from "./knowledgeBase.js";
import { startSessionCleanup, destroyAllSessions } from "./chatAgent.js";
import { authenticate, apiLimiter } from "./middleware.js";
import { requireAdminKey } from "./lib/authorize.js";
import { azureDevOps } from "./azureDevOps.js";
import { initDb } from "./lib/db.js";
import { initBuildDb } from "./lib/build-db.js";
import { upsertDefaultProject } from "./lib/project-store.js";
import { registerSkills } from "./agents/orchestrator.js";
import { logger } from "./lib/logger.js";
import { startHealthMonitor, stopHealthMonitor, startMetricsFlush, stopMetricsFlush } from "./lib/health.js";
import { initMetricsCollector } from "./lib/event-handlers/metrics-collector.js";
import promptTemplatesRouter from "./routes/prompt-templates.js";

const PORT = Number(process.env.SERVER_PORT) || 4000;

const app = express();

// ── Security middleware ────────────────────────────────────────────────────────
app.use(helmet());                                          // Security headers
app.use(cors({
  origin: process.env.WEB_ORIGIN || "http://localhost:3000",
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type", "x-api-key", "Authorization"],
}));
app.use(express.json({ limit: "100kb" }));                  // Body size limit
app.use(apiLimiter);                                        // Global rate limit

// ── Structured request logging (pino-http) ─────────────────────────────────────────────
app.use(
  pinoHttp({
    logger,
    genReqId: () => randomUUID(),
    // Suppress noisy endpoints from access log in production
    autoLogging: {
      ignore: (req) => req.url === "/healthz",
    },
    customLogLevel: (_req, res) => {
      if (res.statusCode >= 500) return "error";
      if (res.statusCode >= 400) return "warn";
      return "info";
    },
  })
);

// ── Authentication (all /api routes) ───────────────────────────────────────────
app.use("/api", authenticate);

// ── Phase 4.2: Admin/Observe extra auth guard ───────────────────────────────────
app.use("/api/observe", requireAdminKey);
app.use("/api/admin", requireAdminKey);

// ── Phase 4.6: Thread requestId into res.locals for downstream audit calls ─────
app.use((_req, res, next) => {
  res.locals.requestId = (_req as any).id as string | undefined;
  next();
});

// ── Routes ─────────────────────────────────────────────────────────────────────
app.use("/api/chat", chatRouter);
app.use("/api/observe", observeRouter);                              // Phase 1.2 — observability
app.use("/api/admin/projects", projectsRouter);                     // Phase 1.3 — project CRUD
app.use("/api/admin/artifacts", artifactsRouter);                   // Phase 1.3 — artifact list/download
app.use("/api/admin/prompt-templates", promptTemplatesRouter);     // Phase 4.8 — prompt versioning
app.use("/api/admin/reset", resetRouter);                          // Dev reset — wipe all data
app.use("/api/builds", buildsRouter);                              // Phase 3 — Build pipeline
// Health check (behind auth — use /healthz for unauthenticated probe)
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Unauthenticated health probe for load balancers / k8s
app.get("/healthz", (_req, res) => {
  res.json({ status: "ok" });
});

// ── Synchronous startup init — runs BEFORE the server accepts any traffic ────
// Order matters: DB tables → seeded data → skills → event handlers
initDb();
initBuildDb();
upsertDefaultProject();
registerSkills();
initMetricsCollector();

// Start
const server = app.listen(PORT, async () => {
  logger.info(`SDLC-Copilot server running at http://localhost:${PORT}`);
  logger.info("Routes: POST /api/chat/stream | GET /api/chat/status | GET /api/health | GET /api/observe/* | GET /api/admin/*");

  // Start health monitor — polls MetricsService every 30s, marks degraded skills
  startHealthMonitor();

  // Start periodic metrics flush to SQLite (Phase 1.2)
  startMetricsFlush();

  // Purge expired memory entries from previous runs
  const { purgeExpiredMemories } = await import("./lib/memory-store.js");
  purgeExpiredMemories();

  // Pre-warm the Copilot client so the first request isn't slow
  warmUpCopilotClient();

  // Initialize knowledge base (fetch core files from GitHub)
  await initializeKnowledgeBase();

  // Validate Azure DevOps configuration for SDLC Agent mode
  azureDevOps.validateConfig();

  // Start idle session cleanup (reap sessions idle > 30 min)
  startSessionCleanup(30 * 60 * 1000);
});

// Graceful shutdown
async function shutdown() {
  logger.info("[server] Shutting down...");
  stopHealthMonitor();
  stopMetricsFlush(); // Phase 1.2
  await destroyAllSessions();
  await stopCopilotClient();
  server.close(() => process.exit(0));
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
