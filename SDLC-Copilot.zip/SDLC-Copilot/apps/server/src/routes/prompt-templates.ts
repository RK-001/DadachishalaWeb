/**
 * Prompt Templates Admin Routes — Phase 4.8
 *
 * CRUD for per-project, per-mode prompt template overrides.
 * prompt-loader.ts reads the active template from DB before falling back to disk files.
 *
 * GET  /api/admin/prompt-templates?projectId=  — list all templates for a project
 * POST /api/admin/prompt-templates             — create/update template (new version)
 * PUT  /api/admin/prompt-templates/:id/activate — activate a specific version
 * DELETE /api/admin/prompt-templates/:id       — delete an inactive template
 * GET  /api/admin/prompt-templates/defaults    — list all file-based defaults (for reference)
 *
 * Auth: requires admin key (via requireAdminKey middleware mounted at index.ts)
 */

import { Router, Request, Response } from "express";
import {
  listPromptTemplates,
  upsertPromptTemplate,
  activatePromptTemplate,
  deletePromptTemplate,
  getActivePromptTemplate,
} from "../lib/db.js";
import { templateCache } from "../prompts/prompt-loader.js";
import type { AuthenticatedRequest } from "../middleware.js";
import { isSafePathSegment } from "../middleware.js";
import { auditLog } from "../lib/db.js";
import logger from "../lib/logger.js";

const router = Router();

const VALID_MODES = [
  "chat", "ud", "sdlc", "brd-analyst", "impl-plan", "coding", "release",
] as const;

type ValidMode = (typeof VALID_MODES)[number];

function isValidMode(m: unknown): m is ValidMode {
  return typeof m === "string" && (VALID_MODES as readonly string[]).includes(m);
}

// ─── GET /api/admin/prompt-templates?projectId= ────────────────────────────────

router.get("/", (req: Request, res: Response) => {
  const projectId = (req.query.projectId as string) || "default";
  if (!isSafePathSegment(projectId)) {
    return res.status(400).json({ error: "Invalid projectId" });
  }

  const templates = listPromptTemplates(projectId);
  res.json({ templates, count: templates.length });
});

// ─── GET /api/admin/prompt-templates/defaults ─────────────────────────────────

router.get("/defaults", (_req: Request, res: Response) => {
  // Return available modes — the caller can GET /api/admin/prompt-templates/defaults/:mode
  res.json({
    modes: VALID_MODES,
    description: "Use POST to create a DB override; omit to use disk file defaults",
  });
});

// ─── GET /api/admin/prompt-templates/active?projectId=&mode= ─────────────────

router.get("/active", (req: Request, res: Response) => {
  const projectId = (req.query.projectId as string) || "default";
  const mode = req.query.mode as string;

  if (!isSafePathSegment(projectId)) {
    return res.status(400).json({ error: "Invalid projectId" });
  }
  if (!isValidMode(mode)) {
    return res.status(400).json({ error: `Invalid mode. Valid modes: ${VALID_MODES.join(", ")}` });
  }

  const template = getActivePromptTemplate(projectId, mode);
  if (!template) {
    return res.json({ template: null, source: "file-default" });
  }
  res.json({ template, source: "database" });
});

// ─── POST /api/admin/prompt-templates ─────────────────────────────────────────

router.post("/", (req: Request, res: Response) => {
  const { projectId = "default", mode, content } = req.body as {
    projectId?: string;
    mode: unknown;
    content: unknown;
  };
  const userId = (req as AuthenticatedRequest).userId;

  if (!isSafePathSegment(projectId as string)) {
    return res.status(400).json({ error: "Invalid projectId" });
  }
  if (!isValidMode(mode)) {
    return res.status(400).json({ error: `Invalid mode. Valid modes: ${VALID_MODES.join(", ")}` });
  }
  if (typeof content !== "string" || content.trim().length === 0) {
    return res.status(400).json({ error: "content must be a non-empty string" });
  }
  if (content.length > 50_000) {
    return res.status(400).json({ error: "content must not exceed 50 000 characters" });
  }

  try {
    const template = upsertPromptTemplate({
      projectId: projectId as string,
      mode,
      content: content.trim(),
      createdBy: userId,
    });

    // Invalidate prompt file cache so next request uses the new DB template
    templateCache.clear();

    auditLog({
      action: "prompt_template_created",
      userId,
      resource: `${projectId}/${mode}`,
      details: { templateId: template.id, version: template.version },
    });

    logger.info(
      { projectId, mode, version: template.version },
      "[prompt-templates] template created/updated"
    );

    res.status(201).json({ template });
  } catch (err: any) {
    logger.error({ err }, "[prompt-templates] create error");
    res.status(500).json({ error: "Failed to create template" });
  }
});

// ─── PUT /api/admin/prompt-templates/:id/activate ─────────────────────────────

router.put("/:id/activate", (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const userId = (req as AuthenticatedRequest).userId;

  if (!Number.isFinite(id) || id <= 0) {
    return res.status(400).json({ error: "Invalid template id" });
  }

  const success = activatePromptTemplate(id);
  if (!success) {
    return res.status(404).json({ error: "Template not found" });
  }

  // Invalidate cache
  templateCache.clear();

  auditLog({
    action: "prompt_template_activated",
    userId,
    resource: `template:${id}`,
  });

  res.json({ success: true, id });
});

// ─── DELETE /api/admin/prompt-templates/:id ────────────────────────────────────

router.delete("/:id", (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const userId = (req as AuthenticatedRequest).userId;

  if (!Number.isFinite(id) || id <= 0) {
    return res.status(400).json({ error: "Invalid template id" });
  }

  const success = deletePromptTemplate(id);
  if (!success) {
    return res.status(409).json({
      error: "Cannot delete template — either not found or it is currently active",
    });
  }

  auditLog({
    action: "prompt_template_deleted",
    userId,
    resource: `template:${id}`,
  });

  res.json({ success: true });
});

export default router;
