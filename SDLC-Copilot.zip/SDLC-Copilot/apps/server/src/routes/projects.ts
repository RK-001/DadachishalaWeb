/**
 * Projects admin routes — Phase 1.3
 *
 * CRUD endpoints for project configuration.
 * No auth guard in Phase 1 (dev-only). Auth will be added in Phase 3.3 (RBAC).
 * The "default" project cannot be deleted (it is the fallback for all requests
 * that omit projectId).
 *
 * GET    /api/admin/projects         — list all projects
 * GET    /api/admin/projects/:id     — get single project
 * POST   /api/admin/projects         — create new project
 * PUT    /api/admin/projects/:id     — update project (partial)
 * DELETE /api/admin/projects/:id     — delete project (blocks id="default")
 *
 * Phase 1.3 — Admin APIs
 */

import { Router, Request, Response } from "express";
import {
  getProject,
  listProjects,
  createProject,
  updateProject,
  deleteProject,
} from "../lib/project-store.js";
import { sanitizeError } from "../lib/logger.js";
import logger from "../lib/logger.js";

const router = Router();

// ─── Validation helpers ────────────────────────────────────────────────────────

const VALID_ID_RE = /^[a-zA-Z0-9_\-]+$/;
const MAX_ID_LEN = 64;
const MAX_NAME_LEN = 128;

function isValidId(value: unknown): value is string {
  return (
    typeof value === "string" &&
    value.length > 0 &&
    value.length <= MAX_ID_LEN &&
    VALID_ID_RE.test(value)
  );
}

function isValidName(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0 && value.length <= MAX_NAME_LEN;
}

// ─── GET /api/admin/projects ───────────────────────────────────────────────────

router.get("/", (_req: Request, res: Response) => {
  try {
    const projects = listProjects();
    res.json({ projects, count: projects.length });
  } catch (err) {
    logger.error({ err }, "[admin/projects] listProjects error");
    res.status(500).json(sanitizeError(err));
  }
});

// ─── GET /api/admin/projects/:id ──────────────────────────────────────────────

router.get("/:id", (req: Request, res: Response) => {
  const { id } = req.params;
  if (!isValidId(id)) {
    return res.status(400).json({ error: "Invalid project id" });
  }
  const project = getProject(id);
  if (!project) {
    return res.status(404).json({ error: `Project "${id}" not found` });
  }
  res.json(project);
});

// ─── POST /api/admin/projects ─────────────────────────────────────────────────

router.post("/", (req: Request, res: Response) => {
  const body = req.body || {};
  const { id, name, kbRepoOwner, kbRepoName, kbRepoRef, adoOrg, adoProject, enabledModes, model } = body;

  if (!isValidId(id)) {
    return res.status(400).json({ error: "id is required and must match [a-zA-Z0-9_-] (max 64 chars)" });
  }
  if (!isValidName(name)) {
    return res.status(400).json({ error: "name is required (max 128 chars)" });
  }

  // Check if id already exists
  if (getProject(id)) {
    return res.status(409).json({ error: `Project "${id}" already exists` });
  }

  // Validate enabledModes if provided
  const modes = Array.isArray(enabledModes) ? enabledModes.filter((m: unknown) => typeof m === "string") : undefined;

  try {
    createProject({
      id: id.trim(),
      name: name.trim(),
      kbRepoOwner: typeof kbRepoOwner === "string" ? kbRepoOwner : null,
      kbRepoName: typeof kbRepoName === "string" ? kbRepoName : null,
      kbRepoRef: typeof kbRepoRef === "string" ? kbRepoRef : "main",
      adoOrg: typeof adoOrg === "string" ? adoOrg : null,
      adoProject: typeof adoProject === "string" ? adoProject : null,
      enabledModes: modes,
      model: typeof model === "string" ? model : null,
    });
    logger.info({ projectId: id }, "[admin/projects] Project created");
    res.status(201).json({ created: true, id });
  } catch (err: any) {
    // SQLite UNIQUE constraint violation
    if (err?.code === "SQLITE_CONSTRAINT_PRIMARYKEY" || err?.message?.includes("UNIQUE constraint")) {
      return res.status(409).json({ error: `Project "${id}" already exists` });
    }
    logger.error({ err, id }, "[admin/projects] createProject error");
    res.status(500).json(sanitizeError(err));
  }
});

// ─── PUT /api/admin/projects/:id ──────────────────────────────────────────────

router.put("/:id", (req: Request, res: Response) => {
  const { id } = req.params;
  if (!isValidId(id)) {
    return res.status(400).json({ error: "Invalid project id" });
  }

  const body = req.body || {};
  const partial: Parameters<typeof updateProject>[1] = {};

  if ("name" in body) {
    if (!isValidName(body.name)) return res.status(400).json({ error: "name must be a non-empty string (max 128 chars)" });
    partial.name = body.name.trim();
  }
  if ("kbRepoOwner" in body) partial.kbRepoOwner = typeof body.kbRepoOwner === "string" ? body.kbRepoOwner : null;
  if ("kbRepoName" in body) partial.kbRepoName = typeof body.kbRepoName === "string" ? body.kbRepoName : null;
  if ("kbRepoRef" in body) partial.kbRepoRef = typeof body.kbRepoRef === "string" ? body.kbRepoRef : "main";
  if ("adoOrg" in body) partial.adoOrg = typeof body.adoOrg === "string" ? body.adoOrg : null;
  if ("adoProject" in body) partial.adoProject = typeof body.adoProject === "string" ? body.adoProject : null;
  if ("model" in body) partial.model = typeof body.model === "string" ? body.model : null;
  if ("enabledModes" in body && Array.isArray(body.enabledModes)) {
    partial.enabledModes = (body.enabledModes as unknown[]).filter((m): m is string => typeof m === "string");
  }

  if (Object.keys(partial).length === 0) {
    return res.status(400).json({ error: "No valid fields provided for update" });
  }

  try {
    const updated = updateProject(id, partial);
    if (!updated) {
      return res.status(404).json({ error: `Project "${id}" not found` });
    }
    logger.info({ projectId: id }, "[admin/projects] Project updated");
    res.json({ updated: true, id });
  } catch (err) {
    logger.error({ err, id }, "[admin/projects] updateProject error");
    res.status(500).json(sanitizeError(err));
  }
});

// ─── DELETE /api/admin/projects/:id ───────────────────────────────────────────

router.delete("/:id", (req: Request, res: Response) => {
  const { id } = req.params;
  if (!isValidId(id)) {
    return res.status(400).json({ error: "Invalid project id" });
  }
  if (id === "default") {
    return res.status(403).json({ error: 'The "default" project cannot be deleted' });
  }

  try {
    const deleted = deleteProject(id);
    if (!deleted) {
      return res.status(404).json({ error: `Project "${id}" not found` });
    }
    logger.info({ projectId: id }, "[admin/projects] Project deleted");
    res.json({ deleted: true, id });
  } catch (err) {
    logger.error({ err, id }, "[admin/projects] deleteProject error");
    res.status(500).json(sanitizeError(err));
  }
});

export default router;
