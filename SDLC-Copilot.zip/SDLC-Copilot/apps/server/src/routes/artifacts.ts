/**
 * Artifacts admin routes — Phase 1.3
 *
 * List, retrieve, and download generated artifacts (UDs and future SDLC outputs).
 * No auth guard in Phase 1 (dev-only). Auth will be added in Phase 3.3 (RBAC).
 *
 * GET /api/admin/artifacts                     — list artifacts (filter: ?sessionKey=&projectId=&limit=)
 * GET /api/admin/artifacts/:id                 — get artifact (with content)
 * GET /api/admin/artifacts/:id/download        — download artifact as file attachment
 *
 * Phase 1.3 — Admin APIs
 */

import { Router, Request, Response } from "express";
import { getArtifact, listArtifacts } from "../lib/artifact-store.js";
import { sanitizeError } from "../lib/logger.js";
import logger from "../lib/logger.js";

const router = Router();

// ─── GET /api/admin/artifacts ─────────────────────────────────────────────────

router.get("/", (req: Request, res: Response) => {
  const { sessionKey, projectId, limit } = req.query as {
    sessionKey?: string;
    projectId?: string;
    limit?: string;
  };

  const limitNum = limit ? Math.min(Math.max(parseInt(limit, 10) || 50, 1), 200) : 50;

  try {
    const artifacts = listArtifacts({
      sessionKey: sessionKey || undefined,
      projectId: projectId || undefined,
      limit: limitNum,
    });
    // Strip content field from list view for performance
    const list = artifacts.map(({ content: _, ...rest }) => rest);
    res.json({ artifacts: list, count: list.length });
  } catch (err) {
    logger.error({ err }, "[admin/artifacts] listArtifacts error");
    res.status(500).json(sanitizeError(err));
  }
});

// ─── GET /api/admin/artifacts/:id ─────────────────────────────────────────────

router.get("/:id", (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  if (!Number.isFinite(id) || id <= 0) {
    return res.status(400).json({ error: "id must be a positive integer" });
  }

  try {
    const artifact = getArtifact(id);
    if (!artifact) {
      return res.status(404).json({ error: `Artifact #${id} not found` });
    }
    res.json(artifact);
  } catch (err) {
    logger.error({ err, id }, "[admin/artifacts] getArtifact error");
    res.status(500).json(sanitizeError(err));
  }
});

// ─── GET /api/admin/artifacts/:id/download ────────────────────────────────────

router.get("/:id/download", (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  if (!Number.isFinite(id) || id <= 0) {
    return res.status(400).json({ error: "id must be a positive integer" });
  }

  try {
    const artifact = getArtifact(id);
    if (!artifact) {
      return res.status(404).json({ error: `Artifact #${id} not found` });
    }

    // Sanitize filename: strip path separators, non-printable chars, and
    // quote characters that would break the Content-Disposition header format.
    const safeFilename = artifact.filename
      .replace(/[/\\]/g, "_")        // no path separators
      .replace(/"/g, "'")             // no double-quotes (would break the header)
      .replace(/[^\x20-\x7E]/g, "")  // printable ASCII only
      .slice(0, 200) || `artifact-${id}.md`;

    res.setHeader("Content-Type", "text/markdown; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${safeFilename}"`);
    res.send(artifact.content);
  } catch (err) {
    logger.error({ err, id }, "[admin/artifacts] download error");
    res.status(500).json(sanitizeError(err));
  }
});

export default router;
