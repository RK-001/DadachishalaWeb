/**
 * Builds Router — Phase 3
 *
 * REST API for the multi-stage build pipeline.
 * All routes require authentication (via app-level auth middleware in index.ts).
 *
 * Endpoints:
 *   GET    /api/builds/preview-work-item  — Preview ADO work item (before creating a build)
 *   POST   /api/builds                   — Create a build (brd_intake stage)
 *   GET    /api/builds                   — List builds for a project
 *   GET    /api/builds/:buildId          — Get build details + artifacts + approvals
 *   POST   /api/builds/:buildId/approve  — Approve current stage → advance
 *   POST   /api/builds/:buildId/reject   — Reject current stage → revert
 *   DELETE /api/builds/:buildId          — Soft-delete (archive)
 *
 * Phase 3 — Multi-stage Build Pipeline
 * Phase A (UX v2) — Added preview-work-item, adoWorkItemId in POST
 */

import { Router, type Request, type Response } from "express";
import {
  createBuild,
  getBuild,
  listBuilds,
  archiveBuild,
  getBuildArtifactLinks,
  getAllApprovals,
  type BuildStatus,
} from "../lib/build-store.js";
import { getArtifact } from "../lib/artifact-store.js";
import {
  canAdvanceBuild,
  advanceBuildStage,
  rejectBuildStage,
  ARTIFACT_REQUIRED_STAGES,
} from "../lib/build-lifecycle.js";
import { azureDevOps } from "../azureDevOps.js";
import logger from "../lib/logger.js";

const router = Router();

// ─── Helpers ───────────────────────────────────────────────────────────────────

function getUserId(req: Request): string {
  // userId is set by the authenticate middleware on req (typed as any in Express)
  return (req as any).userId as string ?? "anonymous";
}

/** Assemble a full build detail object including linked artifacts and approvals. */
async function buildDetail(buildId: string) {
  const build = getBuild(buildId);
  if (!build) return null;

  const links = getBuildArtifactLinks(buildId);
  const approvals = getAllApprovals(buildId);

  const artifacts = links.map((link) => {
    const artifact = getArtifact(link.artifactId);
    return {
      stage: link.stage,
      artifactId: link.artifactId,
      filename: artifact?.filename ?? null,
      artifactType: artifact?.artifact_type ?? null,
      version: artifact?.version ?? null,
      createdAt: link.createdAt,
    };
  });

  return { ...build, artifacts, approvals };
}

// ─── GET /api/builds/preview-work-item ────────────────────────────────────────
// IMPORTANT: Must be defined BEFORE /:buildId to avoid slug collision.

router.get("/preview-work-item", async (req: Request, res: Response) => {
  const idStr = req.query["id"];
  const rawProjectId = typeof req.query["projectId"] === "string" ? req.query["projectId"] : "";
  // "default" is the frontend fallback when NEXT_PUBLIC_PROJECT_ID is not set;
  // treat it (and empty) as "use ADO_PROJECT env var".
  const projectId = rawProjectId && rawProjectId !== "default" ? rawProjectId : undefined;

  const id = parseInt(String(idStr), 10);
  if (!id || id < 1 || id > 9_999_999) {
    res.status(400).json({ error: "Invalid work item ID" });
    return;
  }

  try {
    const wi = await azureDevOps.fetchWorkItem(id, projectId);
    res.json({
      workItem: {
        id: wi.id,
        title: wi.title,
        workItemType: wi.workItemType,
        state: wi.state,
        assignedTo: wi.assignedTo ?? null,
        description: wi.description,
        url: wi.url,
      },
    });
  } catch (err: any) {
    logger.warn({ err: err.message, workItemId: id }, "[builds] preview-work-item failed");
    res.status(404).json({ error: err.message ?? "Work item not found" });
  }
});

// ─── POST /api/builds ──────────────────────────────────────────────────────────

router.post("/", async (req: Request, res: Response) => {
  const { projectId, title, description, adoWorkItemId } = req.body as {
    projectId?: string;
    title?: string;
    description?: string;
    adoWorkItemId?: number | string;
  };

  if (!title || typeof title !== "string" || title.trim().length === 0) {
    res.status(400).json({ error: "title is required" });
    return;
  }

  // Validate adoWorkItemId if provided
  let parsedAdoId: number | null = null;
  if (adoWorkItemId !== undefined && adoWorkItemId !== null) {
    parsedAdoId = Number(adoWorkItemId);
    if (!Number.isInteger(parsedAdoId) || parsedAdoId < 1 || parsedAdoId > 9_999_999) {
      res.status(400).json({ error: "adoWorkItemId must be a positive integer" });
      return;
    }
  }

  const userId = getUserId(req);
  const effectiveProjectId = (typeof projectId === "string" && projectId.trim())
    ? projectId.trim()
    : "default";

  try {
    const build = createBuild({
      projectId: effectiveProjectId,
      title: title.trim(),
      description: typeof description === "string" ? description.trim() || null : null,
      adoWorkItemId: parsedAdoId,
      createdBy: userId,
    });

    logger.info({ buildId: build.id, userId, adoWorkItemId: parsedAdoId }, "[builds] Build created");
    res.status(201).json({ build });
  } catch (err: any) {
    logger.error({ err: err.message }, "[builds] Create build failed");
    res.status(500).json({ error: "Failed to create build" });
  }
});

// ─── GET /api/builds ───────────────────────────────────────────────────────────

router.get("/", (req: Request, res: Response) => {
  const { projectId, status, limit, offset } = req.query as {
    projectId?: string;
    status?: string;
    limit?: string;
    offset?: string;
  };

  const validStatuses: BuildStatus[] = ["active", "paused", "failed", "completed"];
  const safeStatus = validStatuses.includes(status as BuildStatus)
    ? (status as BuildStatus)
    : undefined;

  const builds = listBuilds({
    projectId: typeof projectId === "string" ? projectId : undefined,
    status: safeStatus,
    limit: Math.min(Number(limit) || 50, 200),
    offset: Number(offset) || 0,
  });

  res.json({ builds, count: builds.length });
});

// ─── GET /api/builds/:buildId ──────────────────────────────────────────────────

router.get("/:buildId", async (req: Request, res: Response) => {
  const { buildId } = req.params as { buildId: string };

  const detail = await buildDetail(buildId);
  if (!detail) {
    res.status(404).json({ error: "Build not found" });
    return;
  }

  res.json({ build: detail });
});

// ─── POST /api/builds/:buildId/approve ────────────────────────────────────────

router.post("/:buildId/approve", async (req: Request, res: Response) => {
  const { buildId } = req.params as { buildId: string };
  const { approvedBy, comments } = req.body as {
    approvedBy?: string;
    comments?: string;
  };

  const validation = canAdvanceBuild(buildId);
  if (!validation.canAdvance) {
    res.status(409).json({ error: validation.reason });
    return;
  }

  try {
    const buildBeforeAdvance = getBuild(buildId)!;
    const approvedStage = buildBeforeAdvance.currentStage;

    // approvedBy is free-text per design decision (Q8).
    // We also capture the authenticated userId for audit.
    const actor = approvedBy ?? getUserId(req);
    const updatedBuild = advanceBuildStage(buildId, actor, comments);
    logger.info({ buildId, actor, newStage: updatedBuild.currentStage }, "[builds] Stage approved");

    // Auto-attach artifact to ADO work item if applicable (non-fatal if it fails)
    let adoAttached = false;
    let adoAttachError: string | null = null;
    if (buildBeforeAdvance.adoWorkItemId && ARTIFACT_REQUIRED_STAGES.has(approvedStage)) {
      try {
        const links = getBuildArtifactLinks(buildId);
        const stageLink = links.find(l => l.stage === approvedStage);
        if (stageLink) {
          const artifact = getArtifact(stageLink.artifactId);
          if (artifact?.content) {
            await azureDevOps.attachUDToWorkItem(
              buildBeforeAdvance.adoWorkItemId,
              artifact.filename,
              artifact.content,
            );
            adoAttached = true;
            logger.info(
              { buildId, stage: approvedStage, workItemId: buildBeforeAdvance.adoWorkItemId },
              "[builds] Artifact auto-attached to ADO work item"
            );
          }
        }
      } catch (attachErr: any) {
        adoAttachError = attachErr.message ?? "Attachment failed";
        logger.warn(
          { err: attachErr.message, buildId, stage: approvedStage, workItemId: buildBeforeAdvance.adoWorkItemId },
          "[builds] ADO attachment failed (non-fatal, approval still succeeds)"
        );
      }
    }

    res.json({
      build: updatedBuild,
      adoAttached,
      adoAttachError,
      adoWorkItemId: buildBeforeAdvance.adoWorkItemId ?? null,
      approvedStage,
    });
  } catch (err: any) {
    logger.error({ err: err.message, buildId }, "[builds] Approve failed");
    res.status(500).json({ error: err.message ?? "Approval failed" });
  }
});

// ─── POST /api/builds/:buildId/reject ─────────────────────────────────────────

router.post("/:buildId/reject", (req: Request, res: Response) => {
  const { buildId } = req.params as { buildId: string };
  const { rejectedBy, comments } = req.body as {
    rejectedBy?: string;
    comments?: string;
  };

  if (!comments || typeof comments !== "string" || comments.trim().length === 0) {
    res.status(400).json({ error: "comments are required when rejecting a stage" });
    return;
  }

  const build = getBuild(buildId);
  if (!build) {
    res.status(404).json({ error: "Build not found" });
    return;
  }

  try {
    const actor = rejectedBy ?? getUserId(req);
    const updatedBuild = rejectBuildStage(buildId, actor, comments.trim());
    logger.info({ buildId, actor, revertedTo: updatedBuild.currentStage }, "[builds] Stage rejected");
    res.json({ build: updatedBuild });
  } catch (err: any) {
    logger.error({ err: err.message, buildId }, "[builds] Reject failed");
    res.status(500).json({ error: err.message ?? "Rejection failed" });
  }
});

// ─── DELETE /api/builds/:buildId ──────────────────────────────────────────────

router.delete("/:buildId", (req: Request, res: Response) => {
  const { buildId } = req.params as { buildId: string };

  const build = getBuild(buildId);
  if (!build) {
    res.status(404).json({ error: "Build not found" });
    return;
  }

  archiveBuild(buildId);
  logger.info({ buildId, userId: getUserId(req) }, "[builds] Build archived");
  res.json({ success: true });
});

export default router;
