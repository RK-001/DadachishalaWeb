/**
 * Chat routes
 *
 * POST /api/chat/stream — Main chat endpoint (SSE)
 *   Body: { sessionId: string, message: string, mode?: "chat" | "ud" }
 *   Response: SSE stream of ChatStreamEvent objects
 *
 * GET  /api/chat/status — KB status check
 *   Response: { ready, filesLoaded, errors, cacheSize }
 *
 * Security: requests are pre-authenticated by the auth middleware in index.ts.
 * Per-request SSE handlers are unsubscribed on res.close to prevent
 * event leaks across reused persistent sessions.
 *
 * Phase 2.2 — Refactored to emit via EventBus instead of direct SSE/metrics/persist calls.
 * The SSE writer, message persister, and metrics collector are separate handlers
 * that subscribe to the EventBus; this route only orchestrates session lifecycle.
 */

import { Router, Request, Response } from "express";
import {
  makeSessionKey,
  acquireSessionSlot,
  releaseSessionSlot,
  cancelSessionQueue,
  getSessionQueueDepth,
  destroySession,
  getOrCreateSession,
} from "../chatAgent.js";
import { MAX_QUEUE_DEPTH } from "../lib/session-queue.js";
import { orchestrator } from "../agents/orchestrator.js";
import { getBuild } from "../lib/build-store.js";
import { getModeForStage } from "../lib/build-lifecycle.js";
import { knowledgeBase } from "../knowledgeBase.js";
import { validateChatRequest, detectInjectionAttempt, streamLimiter, type AuthenticatedRequest } from "../middleware.js";
import { sanitizeError, AppError } from "../lib/logger.js";
import { auditLog, findMostRecentSessionKey } from "../lib/db.js";
import { saveMessage, getMessages } from "../lib/message-store.js";
import { metrics } from "../lib/health.js";
import { eventBus } from "../lib/event-bus.js";
import { createSSEWriter } from "../lib/event-handlers/sse-writer.js";
import { createMessagePersister } from "../lib/event-handlers/message-persister.js";
import { sessionRegistry } from "../lib/session-registry.js";
import logger from "../lib/logger.js";

const router = Router();

// ─── POST /api/chat/stream ─────────────────────────────────────────────────────

router.post("/stream", streamLimiter, async (req: Request, res: Response) => {
  const validation = validateChatRequest(req.body);
  if (!validation.valid) {
    return res.status(400).json({ error: validation.error });
  }

  const { sessionId, message, mode, projectId } = validation.data;
  const userId = (req as AuthenticatedRequest).userId;

  // Extract optional buildId for pipeline-mode routing
  const buildId = typeof req.body.buildId === "string" && req.body.buildId.trim()
    ? req.body.buildId.trim()
    : undefined;

  // Block prompt injection attempts before touching SSE
  if (detectInjectionAttempt(message)) {
    auditLog({
      action: "injection_blocked",
      userId,
      resource: "chat/stream",
      details: { sessionId, mode },
    });
    return res.status(400).json({ error: "Invalid request content" });
  }

  // Session key used for concurrency guard + EventBus routing
  const sessionKey = makeSessionKey(userId, sessionId, mode);

  // Per-session FIFO queue guard (Phase 0.5)
  if (getSessionQueueDepth(sessionKey) >= MAX_QUEUE_DEPTH) {
    return res.status(429).json({
      error: "Session queue full. Please wait for previous messages to complete.",
    });
  }

  // Set SSE headers
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  const logMsg = message.length > 80 ? message.slice(0, 80) + "..." : message;
  logger.info({ sessionKey, mode, userId }, `[chat/stream] message="${logMsg}"`);

  const requestId = (req as any).id as string | undefined;
  const requestStartedAt = Date.now();

  let finished = false;
  let slotAcquired = false;

  // ── Attach EventBus handlers for this request ────────────────────────────
  // createSSEWriter manages heartbeat + SSE formatting
  const cleanupSSE = createSSEWriter(res, sessionKey);
  // createMessagePersister accumulates chunks → saves on done
  const cleanupPersist = createMessagePersister(sessionKey, {
    userIdHash: userId,
    projectId: projectId ?? "default",
    mode,
  });

  // Correlate toolCallId → label + startTime for tool events
  const toolCallLabels = new Map<string, string>();
  const toolCallStartTimes = new Map<string, number>();
  // Track create_ud_file args so we can emit ud_file_ready on tool_complete
  const udFileArgs = new Map<string, { filename: string; content: string }>();
  // Track create_artifact_file args so we can emit artifact_saved + artifact_download_ready on tool_complete
  const artifactFileArgs = new Map<string, { filename: string; content: string }>();
  // Track the build's current stage for artifact_saved event context
  let currentBuildStage: string | undefined;

  // Track per-request unsubscribe functions (SDK session handlers)
  const unsubFns: Array<() => void> = [];

  function cleanup() {
    cleanupSSE();
    cleanupPersist();
    unsubFns.forEach((fn) => fn());
    unsubFns.length = 0;
  }

  function finish(type: "done" | "error", data = "") {
    if (finished) return;
    finished = true;
    if (slotAcquired) releaseSessionSlot(sessionKey);
    if (type === "done") {
      eventBus.emit("done", sessionKey, { latencyMs: Date.now() - requestStartedAt, mode }, requestId);
    } else {
      eventBus.emit("error", sessionKey, { message: data || "stream error" }, requestId);
    }
    cleanup();
  }

  try {
    // Log user turn to messages table
    saveMessage({ sessionKey, userIdHash: userId, projectId, role: "user", content: message, mode });
    metrics.recordRequest(mode);

    // Acquire FIFO slot — may wait if another message is in-flight
    if (getSessionQueueDepth(sessionKey) > 0) {
      eventBus.emit("status", sessionKey, { message: "Queued, waiting for previous message to complete..." }, requestId);
    }
    const granted = await acquireSessionSlot(sessionKey);
    slotAcquired = granted;
    if (!granted) {
      finish("error", "Session cancelled");
      return;
    }

    // Touch the session in the registry so TTL resets
    sessionRegistry.touch(sessionKey);

    // Route through OrchestratorAgent (validates skill, handles health + fallback routing)
    // OR through pipeline orchestrator when buildId is present (bypasses mode-gating)
    let session;
    if (buildId) {
      // Validate the build exists and is active
      const build = getBuild(buildId);
      if (!build) {
        finish("error", `Build '${buildId}' not found`);
        return;
      }
      if (build.status !== "active") {
        finish("error", `Build is ${build.status}, not active`);
        return;
      }

      const buildMode = getModeForStage(build.currentStage as any);
      currentBuildStage = build.currentStage;
      // Use getOrCreateSession so the SDK session is cached and reused across turns
      session = await getOrCreateSession(sessionId, buildMode, userId, projectId ?? "default", buildId);
      sessionRegistry.register(sessionKey, { mode: buildMode, projectId: projectId ?? "default" });
    } else {
      session = await orchestrator.getOrCreateSession(sessionId, mode, userId, projectId);
    }

    eventBus.emit("status", sessionKey, { message: "Processing..." }, requestId);

    // ── Register SDK event handlers ──────────────────────────────────────

    unsubFns.push(
      session.on("assistant.message_delta", (event: any) => {
        const raw: string = event.data.deltaContent;
        if (raw) {
          // L4 output sanitization: strip null bytes before streaming to client
          const delta = raw.replace(/\0/g, "");
          eventBus.emit("chunk", sessionKey, { content: delta }, requestId);
        }
      })
    );

    unsubFns.push(
      session.on("tool.execution_start", (event: any) => {
        const toolName = (event.data.toolName as string) || "";
        const args = event.data.arguments as Record<string, unknown> | undefined;
        const toolCallId = event.data.toolCallId as string;

        toolCallStartTimes.set(toolCallId, Date.now());
        saveMessage({ sessionKey, userIdHash: userId, projectId, role: "tool", mode, toolName, toolArgs: args ?? null });

        let label: string;
        if (toolName === "create_ud_file") {
          const filename = (args?.filename as string) || "UD_document.md";
          const content = (args?.content as string) || "";
          label = "create_ud_file";
          // Stash args so we can emit ud_file_ready on tool_complete (content may be empty at start)
          if (filename) {
            udFileArgs.set(toolCallId, { filename, content });
          }
        } else if (toolName === "create_artifact_file") {
          const filename = (args?.filename as string) || "artifact.md";
          const content = (args?.content as string) || "";
          label = "create_artifact_file";
          artifactFileArgs.set(toolCallId, { filename, content });
        } else if (toolName === "fetch_azure_work_item") {
          const workItemId = (args?.workItemId as number) ?? "";
          label = `fetch_azure_work_item:${workItemId}`;
        } else if (toolName === "attach_ud_to_work_item") {
          const workItemId = (args?.workItemId as number) ?? "";
          label = `attach_ud_to_work_item:${workItemId}`;
        } else {
          label = (args?.filePath as string) || toolName;
        }
        toolCallLabels.set(toolCallId, label);

        eventBus.emit("tool_start", sessionKey, { toolName, toolCallId, label: buildToolStartLabel(toolName, label, args) }, requestId);
      })
    );

    unsubFns.push(
      session.on("tool.execution_complete", (event: any) => {
        const { toolCallId, success, result } = event.data;
        const label = toolCallLabels.get(toolCallId) || "file";
        const latencyMs = toolCallStartTimes.has(toolCallId as string)
          ? Date.now() - toolCallStartTimes.get(toolCallId as string)!
          : undefined;
        toolCallLabels.delete(toolCallId);
        toolCallStartTimes.delete(toolCallId as string);

        // Emit ud_file_ready on successful completion of create_ud_file
        const stashedUd = udFileArgs.get(toolCallId);
        if (stashedUd && success) {
          // Prefer the content from execution_start args (full content)
          // Fall back to result.content if args were empty at start time
          const content = stashedUd.content || (result?.content as string) || "";
          if (content) {
            eventBus.emit("ud_file_ready", sessionKey, { filename: stashedUd.filename, content }, requestId);
          }
          // Also emit artifact_saved in a build context so the Approve Stage button appears
          if (buildId && currentBuildStage) {
            eventBus.emit(
              "artifact_saved",
              sessionKey,
              { buildId, stage: currentBuildStage, filename: stashedUd.filename },
              requestId
            );
          }
        }
        udFileArgs.delete(toolCallId);

        // Emit artifact_saved on successful completion of create_artifact_file
        const stashedArtifact = artifactFileArgs.get(toolCallId);
        if (stashedArtifact && success && buildId && currentBuildStage) {
          eventBus.emit(
            "artifact_saved",
            sessionKey,
            { buildId, stage: currentBuildStage, filename: stashedArtifact.filename },
            requestId
          );
          // Emit download event so frontend can offer an immediate download link
          if (stashedArtifact.content) {
            const artifactTypeMap: Record<string, string> = {
              brd_intake: "brd",
              impl_plan: "impl-plan",
              release_docs: "release-notes",
            };
            const artifactType = artifactTypeMap[currentBuildStage] ?? currentBuildStage;
            eventBus.emit(
              "artifact_download_ready",
              sessionKey,
              { filename: stashedArtifact.filename, content: stashedArtifact.content, artifactType },
              requestId
            );
          }
        }
        artifactFileArgs.delete(toolCallId);

        eventBus.emit(
          "tool_complete",
          sessionKey,
          {
            toolName: label.split(":")[0],
            toolCallId,
            label,
            success,
            latencyMs,
            result,
          },
          requestId
        );
      })
    );

    unsubFns.push(
      session.on("session.idle", () => {
        logger.debug({ sessionKey }, "[chat/stream] Session idle — done");
        finish("done");
      })
    );

    unsubFns.push(
      session.on("session.error", (event: any) => {
        const msg = event.data.message || "Unknown session error";
        logger.error({ sessionKey, msg }, "[chat/stream] Session error");
        finish("error", sanitizeError(new Error(msg)).message);
      })
    );

    // Unsubscribe on client disconnect (before done fires)
    res.on("close", () => {
      if (!finished) {
        finished = true;
        if (slotAcquired) releaseSessionSlot(sessionKey);
        logger.info({ sessionKey }, "[chat/stream] Client disconnected before done");
        cleanup();
      }
    });

    // Fire the message — non-blocking; events arrive via handlers above
    await session.send({ prompt: message });
  } catch (err: any) {
    logger.error({ err, sessionKey, mode, requestId }, "[chat/stream] Error");
    const safe = sanitizeError(err);
    if (err instanceof AppError && err.statusCode !== 500 && !res.headersSent) {
      if (slotAcquired && !finished) {
        finished = true;
        releaseSessionSlot(sessionKey);
        metrics.recordError(mode, safe.message, requestId);
      }
      cleanup();
      return res.status(err.statusCode).json({ error: safe.message, code: safe.code });
    }
    finish("error", safe.message);
  }
});

// ─── Helper: human-readable tool_start label ─────────────────────────────────

function buildToolStartLabel(
  toolName: string,
  label: string,
  args: Record<string, unknown> | undefined
): string {
  if (toolName === "create_ud_file") {
    const filename = (args?.filename as string) || "UD_document.md";
    return `Creating UD file "${filename}"...`;
  }
  if (toolName === "create_artifact_file") {
    const filename = (args?.filename as string) || "artifact.md";
    return `Saving artifact "${filename}"...`;
  }
  if (toolName === "fetch_azure_work_item") {
    const id = (args?.workItemId as number) ?? "";
    return `Fetching Work Item #${id}...`;
  }
  if (toolName === "attach_ud_to_work_item") {
    const id = (args?.workItemId as number) ?? "";
    return `Attaching UD to Work Item #${id}...`;
  }
  return `Fetching ${label}...`;
}

// ─── DELETE /api/chat/:sessionId/:mode — Cancel a session ─────────────────────
//
// Cancels all queued + in-flight requests for the given session, then destroys
// the session so it is removed from the in-memory Map.
//
// The session key is reconstructed server-side from the authenticated userId +
// the URL params — the client never provides the full composite key directly.

router.delete("/:sessionId/:mode", async (req: Request, res: Response) => {
  const userId = (req as AuthenticatedRequest).userId;
  const { sessionId, mode } = req.params;

  if (!sessionId || !mode) {
    return res.status(400).json({ error: "sessionId and mode are required" });
  }

  const sessionKey = makeSessionKey(userId, sessionId, mode);
  cancelSessionQueue(sessionKey); // unblock any queued waiters with cancelled=false
  await destroySession(sessionKey);

  logger.info({ sessionKey, userId }, "[chat/cancel] Session cancelled and destroyed");
  res.json({ cancelled: true, sessionKey: `${sessionId}:${mode}` });
});

// ─── GET /api/chat/history — Load previous conversation turns ─────────────────
//
// Returns the user/assistant message history for a given session so the client
// can re-hydrate its UI after a page refresh.
//
// Query params:
//   sessionId  — the client-generated UUID that was used when the session was created
//   mode       — "chat" | "ud" | "brd-analyst" | "impl-plan" | "coding" | "release"
//
// The server reconstructs the composite session key (userId:sessionId:mode)
// from the authenticated request, so the client never needs to know or supply
// the full key — it cannot request another user's history.

router.get("/history", async (req: Request, res: Response) => {
  const userId = (req as AuthenticatedRequest).userId;
  const { sessionId, mode } = req.query as { sessionId?: string; mode?: string };

  const VALID_MODES = ["chat", "ud", "brd-analyst", "impl-plan", "coding", "release"];
  if (!mode || !VALID_MODES.includes(mode)) {
    return res.status(400).json({ error: `mode is required and must be one of: ${VALID_MODES.join(", ")}` });
  }

  // Helper: load conversation history from messages table (Phase 2.2)
  const resolveHistory = (sessionKey: string): Array<{ role: string; content: string | null }> => {
    const richRows = getMessages(sessionKey, 100);
    return richRows.map((r) => ({ role: r.role, content: r.content }));
  };

  let effectiveSessionId = sessionId ?? null;
  let rawHistory = sessionId
    ? resolveHistory(makeSessionKey(userId, sessionId, mode))
    : [];

  // No turns for the provided ID → fall back to the most recently used session
  // for this user+mode. Recovers conversations from before localStorage persistence.
  if (rawHistory.length === 0) {
    const recentKey = findMostRecentSessionKey(userId, mode);
    if (recentKey) {
      rawHistory = resolveHistory(recentKey);
      // Extract sessionId from composite key format: "userId:sessionId:mode"
      const parts = recentKey.split(":");
      effectiveSessionId = parts.length >= 3 ? parts[1] : null;
    }
  }

  const messages = rawHistory
    .filter((t) => (t.role === "user" || t.role === "assistant") && t.content)
    .map((t) => ({ role: t.role as "user" | "assistant", content: t.content as string }));

  // Return effectiveSessionId so the client can sync its localStorage and
  // continue from the recovered session on the next message send.
  res.json({ messages, sessionId: effectiveSessionId });
});

// ─── GET /api/chat/status ──────────────────────────────────────────────────────

router.get("/status", (_req: Request, res: Response) => {
  const status = knowledgeBase.getStatus();
  res.json(status);
});

export default router;
