import { Router, type Request, type Response } from "express";
import { clearAllData } from "../lib/db.js";
import { destroyAllSessions } from "../chatAgent.js";
import { logger } from "../lib/logger.js";

const router = Router();

/** POST /api/admin/reset — Dev-only: wipe all SQLite data + in-memory sessions. */
router.post("/", async (_req: Request, res: Response) => {
  await destroyAllSessions();
  clearAllData();
  logger.info("dev reset: all data and sessions cleared");
  res.json({ cleared: true });
});

export default router;