/**
 * Observe routes — Phase 1.2 → Phase 4.1 / 4.4
 *
 * Read-only diagnostics endpoints for skill health, metrics, active sessions,
 * recent errors, circuit breaker status, and observer logs.
 *
 * GET /api/observe/health           — per-skill health from SkillRegistry
 * GET /api/observe/metrics          — MetricsService snapshot
 * GET /api/observe/sessions         — active in-memory sessions (hashed keys)
 * GET /api/observe/errors           — recent error ring buffer entries
 * GET /api/observe/circuit-breakers — Phase 4.4: circuit breaker states
 * GET /api/observe/observer-logs    — Phase 4.1: observer self-heal audit trail
 *
 * Auth guard: requireAdminKey middleware (mounted in index.ts) — Phase 4.2
 */

import { Router, Request, Response } from "express";
import { skillRegistry } from "../agents/registry.js";
import { metrics } from "../lib/health.js";
import { getActiveSessionInfo } from "../chatAgent.js";
import { sessionRegistry } from "../lib/session-registry.js";
import { getCircuitBreakerStatus } from "../lib/circuit-breaker.js";
import { getObserverLogs } from "../lib/observer-actions.js";

const router = Router();

// ─── GET /api/observe/health ───────────────────────────────────────────────────

router.get("/health", (_req: Request, res: Response) => {
  const skills = skillRegistry.list();
  res.json({
    skills,
    capturedAt: new Date().toISOString(),
  });
});

// ─── GET /api/observe/metrics ──────────────────────────────────────────────────

router.get("/metrics", (_req: Request, res: Response) => {
  res.json(metrics.getSnapshot());
});

// ─── GET /api/observe/sessions ─────────────────────────────────────────────────

router.get("/sessions", (_req: Request, res: Response) => {
  const sessions = getActiveSessionInfo();

  // Phase 2.1 — enrich with SessionRegistry metadata (mode, projectId, instanceId, lastSeenAt)
  const registryEntries = sessionRegistry.listActive();
  const registryMap = new Map(registryEntries.map((e) => [e.sessionKey, e]));

  const enriched = sessions.map((s) => {
    const regEntry = registryMap.get(s.sessionKeyHash) ?? null;
    return {
      ...s,
      // Registry metadata (null if the session predates Phase 2.1 startup)
      instanceId: regEntry?.instanceId ?? null,
      projectId: regEntry?.projectId ?? null,
      registeredAt: regEntry?.registeredAt ?? null,
      lastSeenAt: regEntry?.lastSeenAt ?? null,
    };
  });

  res.json({
    sessions: enriched,
    totalCount: enriched.length,
    capturedAt: new Date().toISOString(),
  });
});

// ─── GET /api/observe/errors ───────────────────────────────────────────────────

router.get("/errors", (_req: Request, res: Response) => {
  const errors = metrics.getErrors();
  res.json({
    errors,
    count: errors.length,
    capturedAt: new Date().toISOString(),
  });
});

// ─── GET /api/observe/circuit-breakers ────────────────────────────────────────

router.get("/circuit-breakers", (_req: Request, res: Response) => {
  const status = getCircuitBreakerStatus();
  res.json({
    circuitBreakers: status,
    count: Object.keys(status).length,
    capturedAt: new Date().toISOString(),
  });
});

// ─── GET /api/observe/observer-logs ───────────────────────────────────────────

router.get("/observer-logs", (req: Request, res: Response) => {
  const limit = Math.min(parseInt((req.query.limit as string) || "50", 10), 200);
  const logs = getObserverLogs(isFinite(limit) && limit > 0 ? limit : 50);
  res.json({
    logs,
    count: logs.length,
    capturedAt: new Date().toISOString(),
  });
});

export default router;
