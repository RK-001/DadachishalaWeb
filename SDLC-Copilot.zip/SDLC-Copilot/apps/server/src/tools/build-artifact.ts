/**
 * Build Artifact Tool — Phase 3
 *
 * Generic artifact creation tool for the build pipeline.
 * Saves to the `artifacts` table AND links to the current build
 * via `build_artifacts` (FK to the build).
 *
 * Used by: brd-analyst, impl-plan, release modes (Phase 3).
 *
 * Phase 3 — Multi-stage Build Pipeline
 */

import { defineTool } from "@github/copilot-sdk";
import { saveArtifact } from "../lib/artifact-store.js";
import { linkArtifactToBuild } from "../lib/build-store.js";
import logger from "../lib/logger.js";

export type BuildArtifactType = "brd" | "impl-plan" | "release-notes";

/**
 * Build a `create_artifact_file` tool scoped to a build stage.
 *
 * The LLM calls this tool (with filename + content) after user approval.
 * Side-effects:
 *   1. Saves to artifacts table
 *   2. Links artifact to the build_artifacts table for the given stage
 */
export function buildCreateBuildArtifactTool(
  artifactType: BuildArtifactType,
  buildId: string,
  stage: string,
  sessionKey: string,
  projectId: string
) {
  return defineTool("create_artifact_file", {
    description:
      `Save the completed ${artifactType.toUpperCase()} artifact after explicit user approval. ` +
      `Call ONLY after the user explicitly approves the draft (says 'approved', 'LGTM', 'finalize', etc.).`,
    parameters: {
      type: "object",
      properties: {
        filename: {
          type: "string",
          description:
            "Descriptive filename for the artifact, e.g. 'BRD_FeatureName.md' or 'ImplPlan_Auth.md'",
        },
        content: {
          type: "string",
          description: "Complete artifact content in Markdown format",
        },
      },
      required: ["filename", "content"],
    },
    handler: async (args: unknown) => {
      const { filename, content } = args as { filename: string; content: string };
      try {
        const artifactId = saveArtifact({
          sessionKey,
          projectId,
          filename,
          content,
          artifactType,
        });

        linkArtifactToBuild(buildId, stage, artifactId);

        logger.info(
          { artifactId, buildId, stage, artifactType, filename },
          "[build-artifact] Artifact saved and linked to build"
        );

        return `Artifact saved: ${filename} (id=${artifactId}, type=${artifactType}, stage=${stage})`;
      } catch (err: any) {
        logger.error(
          { err: err.message, buildId, stage },
          "[build-artifact] Failed to save artifact"
        );
        return `Error saving artifact: ${err.message}`;
      }
    },
  });
}

