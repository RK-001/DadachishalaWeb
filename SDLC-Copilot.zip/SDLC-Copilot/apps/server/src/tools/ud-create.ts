/**
 * Understanding Document Creation Tool
 *
 * Tool builder for creating and persisting Understanding Documents.
 * Used in "ud" mode.
 */

import { defineTool } from "@github/copilot-sdk";
import { saveArtifact } from "../lib/artifact-store.js";
import { linkArtifactToBuild } from "../lib/build-store.js";
import logger from "../lib/logger.js";

/**
 * Build the create_ud_file tool — used in "ud" mode.
 *
 * Persists the artifact to SQLite and returns a success message to the LLM.
 * The actual file content is captured by the route layer via tool.execution_start
 * event and emitted as a ud_file_ready SSE event for browser download.
 *
 * @param sessionKey - Composite session key for artifact scoping.
 * @param projectId  - Project scope for artifact storage.
 */
export function buildCreateUDFileTool(sessionKey: string, projectId: string, buildId?: string, stage?: string) {
  return defineTool("create_ud_file", {
    description:
      "Create the final Understanding Document (UD) file after the user has explicitly approved the draft. " +
      "ONLY call this tool after the user says 'approved', 'looks good', 'LGTM', 'finalize', or similar. " +
      "The file will be delivered to the user as a downloadable Markdown file.",
    parameters: {
      type: "object",
      properties: {
        filename: {
          type: "string",
          description:
            "Filename for the UD (e.g., 'UD_TICKET-123.md'). " +
            "Use the ticket ID from the requirement if available, otherwise use a descriptive name.",
        },
        content: {
          type: "string",
          description: "The complete, final UD content in Markdown format.",
        },
      },
      required: ["filename", "content"],
    },
    handler: async (args: unknown) => {
      const { filename, content } = args as { filename: string; content: string };
      console.log(`[tools/ud-create] create_ud_file("${filename}")`);

      // Persist artifact to SQLite for admin retrieval and download
      try {
        const artifactId = saveArtifact({ sessionKey, projectId, filename, content, artifactType: "ud" });
        // Link to build pipeline when running in build context
        if (buildId && stage) {
          linkArtifactToBuild(buildId, stage, artifactId);
          logger.debug({ sessionKey, filename, buildId, stage }, "[tools/ud-create] Artifact linked to build");
        }
        logger.debug({ sessionKey, filename }, "[tools/ud-create] Artifact persisted");
      } catch (err: any) {
        // Non-fatal — SSE delivery still proceeds even if persistence fails
        logger.error({ err, filename }, "[tools/ud-create] Failed to persist artifact");
      }

      // The route layer intercepts tool.execution_start and emits ud_file_ready.
      return `UD file "${filename}" has been created and sent to the user for download.`;
    },
  });
}
