/**
 * Knowledge Base Fetch Tool
 *
 * Tool builder for fetching content from the knowledge base repository.
 * Used in all modes (chat, ud, sdlc).
 */

import { defineTool } from "@github/copilot-sdk";
import { knowledgeBase } from "../knowledgeBase.js";

/**
 * Build the fetch_kb_file tool — shared by all modes.
 *
 * Fetches content from the knowledge base repository by file path.
 * Users should consult the INDEX file to map topics to file paths.
 */
export function buildFetchKBFileTool() {
  return defineTool("fetch_kb_file", {
    description:
      "Fetch the content of a file from the knowledge base repository. " +
      "Use the INDEX file to find which file path corresponds to a topic, " +
      "then call this tool to retrieve its full content.",
    parameters: {
      type: "object",
      properties: {
        filePath: {
          type: "string",
          description:
            "Relative path to the file within the KB repository " +
            "(e.g. 'auth-module.md', 'modules/payments.md'). " +
            "Do not include leading slashes.",
        },
      },
      required: ["filePath"],
    },
    handler: async (args: unknown) => {
      const { filePath } = args as { filePath: string };

      // L5: Validate file path to prevent path traversal
      if (typeof filePath !== "string" || filePath.length === 0 || filePath.length > 512) {
        return `Error: filePath must be a non-empty string (max 512 chars)`;
      }
      if (filePath.includes("..") || filePath.startsWith("/") || filePath.includes("\\")) {
        return `Error: filePath must be a relative path without directory traversal`;
      }

      console.log(`[tools/kb-fetch] fetch_kb_file("${filePath}")`);
      try {
        const content = await knowledgeBase.fetchKBFileContent(filePath);
        return content;
      } catch (err: any) {
        console.error(`[tools/kb-fetch] fetch_kb_file error: ${err.message}`);
        return `Error fetching "${filePath}": ${err.message}`;
      }
    },
  });
}
