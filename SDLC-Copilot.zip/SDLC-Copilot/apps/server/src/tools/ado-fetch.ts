/**
 * Azure DevOps Work Item Fetch Tool
 *
 * Tool builder for fetching work items from Azure DevOps.
 * Used in the BRD/UD pipeline when fetching Azure DevOps work items.
 */

import { defineTool } from "@github/copilot-sdk";
import { azureDevOps } from "../azureDevOps.js";
import { withCircuitBreaker } from "../lib/circuit-breaker.js";

const ADO_SERVICE = "azure-devops";

/** Validate that a work item ID is a positive integer (L5 tool validation) */
function isValidWorkItemId(id: unknown): id is number {
  return typeof id === "number" && Number.isInteger(id) && id > 0 && id < 10_000_000;
}

/**
 * Build the fetch_azure_work_item tool — used in the BRD/UD pipeline.
 *
 * Fetches a work item from Azure DevOps by its numeric ID.
 * Returns structured data including title, description, acceptance criteria,
 * state, work item type, and metadata.
 */
export function buildFetchAzureWorkItemTool() {
  return defineTool("fetch_azure_work_item", {
    description:
      "Fetch a work item from Azure DevOps by its numeric ID. " +
      "Returns structured data including title, description, acceptance criteria, state, " +
      "work item type, and metadata. Call this immediately when the user provides a Work Item ID.",
    parameters: {
      type: "object",
      properties: {
        workItemId: {
          type: "number",
          description: "The numeric Azure DevOps Work Item ID (e.g. 1234).",
        },
        project: {
          type: "string",
          description:
            "Optional Azure DevOps project name. Omit to use the default project (ADO_PROJECT env var).",
        },
      },
      required: ["workItemId"],
    },
    handler: async (args: unknown) => {
      const { workItemId, project } = args as { workItemId: number; project?: string };
      console.log(`[tools/ado-fetch] fetch_azure_work_item(${workItemId})`);
      try {
        const workItem = await azureDevOps.fetchWorkItem(workItemId, project);
        // Return JSON so the route layer can extract it for the work_item_loaded SSE event
        // and the LLM has the full structured data to populate the UD.
        return JSON.stringify(workItem);
      } catch (err: any) {
        console.error(`[tools/ado-fetch] fetch_azure_work_item error: ${err.message}`);
        return `Error fetching Work Item #${workItemId}: ${err.message}`;
      }
    },
  });
}
