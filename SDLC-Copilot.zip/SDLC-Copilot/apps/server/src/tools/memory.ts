/**
 * Memory tools — Phase 0.2
 *
 * buildRememberTool() — lets the LLM store a project-level memory entry
 * buildRecallTool()   — lets the LLM search project memory by category
 *
 * Both tools are available in all three modes: chat, ud, sdlc.
 *
 * Security:
 *   - Category validated against a fixed allowlist (no free-form injection)
 *   - Content capped at 1000 chars before storage
 *   - Recalled content wrapped in <project_memory> delimiters in prompt injection
 *
 * Phase 0.2 — Shared Project Memory
 */

import { defineTool } from "@github/copilot-sdk";
import {
  rememberEntry,
  recallEntries,
  MEMORY_CATEGORIES,
  DEFAULT_PROJECT_ID,
  type MemoryCategory,
} from "../lib/memory-store.js";

/**
 * Tool: remember — store a project-scoped memory entry.
 * LLM should call this whenever the user states a preference, decision,
 * project convention, term definition, or constraint that should persist
 * across sessions.
 */
export function buildRememberTool(projectId: string = DEFAULT_PROJECT_ID) {
  return defineTool("remember", {
    description:
      "Store a piece of project-level information in long-term memory so it is " +
      "available in future sessions. Use this when the user states a project " +
      "decision, naming convention, business term definition, or constraint that " +
      "should be remembered. Do NOT store sensitive data (passwords, tokens, PII).",
    parameters: {
      type: "object",
      properties: {
        category: {
          type: "string",
          enum: [...MEMORY_CATEGORIES],
          description:
            `Category for this memory. One of: ${MEMORY_CATEGORIES.join(", ")}\n` +
            "  decision   — a design or product decision made by the team\n" +
            "  convention — a naming or coding convention to follow\n" +
            "  term       — a project-specific term or acronym definition\n" +
            "  constraint — a business or technical constraint",
        },
        content: {
          type: "string",
          description:
            "The information to remember. Be concise and factual. Max 1000 characters. " +
            "Start with the subject: e.g. 'All API endpoints must return camelCase JSON.'",
        },
      },
      required: ["category", "content"],
    },
    handler: async (args: unknown) => {
      const { category, content } = args as { category: string; content: string };
      console.log(`[memory] remember — category=${category}, length=${content?.length ?? 0}`);

      const error = rememberEntry({ projectId, category, content, source: "llm-tool" });
      if (error) {
        return `Could not save memory: ${error}`;
      }
      return `Remembered (${category}): "${content.slice(0, 80)}${content.length > 80 ? "…" : ""}"`;
    },
  });
}

/**
 * Tool: recall — retrieve project memory entries by category.
 * LLM should call this at the start of a UD session or when it needs
 * to verify conventions, decisions, or term definitions.
 */
export function buildRecallTool(projectId: string = DEFAULT_PROJECT_ID) {
  return defineTool("recall", {
    description:
      "Retrieve stored project memory entries. Call this at the beginning of " +
      "UD creation or when you need to verify a project convention, term, or constraint. " +
      "Omit 'category' to retrieve all active memories.",
    parameters: {
      type: "object",
      properties: {
        category: {
          type: "string",
          enum: [...MEMORY_CATEGORIES],
          description: `Optional. Filter by category: ${MEMORY_CATEGORIES.join(", ")}`,
        },
      },
      required: [],
    },
    handler: async (args: unknown) => {
      const { category } = (args as { category?: MemoryCategory }) ?? {};
      console.log(`[memory] recall — category=${category ?? "all"}`);

      const entries = recallEntries({ projectId, category, limit: 20 });
      if (entries.length === 0) {
        return category
          ? `No memories found for category "${category}".`
          : "No project memories stored yet.";
      }

      const lines = entries.map(
        (e) => `[${e.category}] ${e.content}  (saved: ${e.created_at.slice(0, 10)})`
      );
      return `Project memory (${entries.length} entries):\n` + lines.join("\n");
    },
  });
}
