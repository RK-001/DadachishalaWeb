/**
 * Tool Builder — Phase 3
 *
 * Centralises mode-specific tool selection and system prompt loading.
 * Called by chatAgent.ts when creating a new session.
 *
 * Replaces the inline tool-wiring that was previously hardcoded for 'sdlc' mode.
 *
 * Phase 3 — Multi-stage Build Pipeline
 */

import { buildFetchKBFileTool } from "./kb-fetch.js";
import { buildCreateUDFileTool } from "./ud-create.js";
import { buildFetchAzureWorkItemTool } from "./ado-fetch.js";
import { buildAttachUDToWorkItemTool } from "./ado-attach.js";
import { buildRememberTool, buildRecallTool } from "./memory.js";
import {
  buildCreateBuildArtifactTool,
  type BuildArtifactType,
} from "./build-artifact.js";
import { buildTriggerCodingAgentTool, buildCheckCopilotAssigneeTool } from "./github-agent.js";
import {
  loadSystemPrompt,
  loadUDSystemPrompt,
  loadBRDSystemPrompt,
  loadImplPlanSystemPrompt,
  loadCodingSystemPrompt,
  loadReleaseSystemPrompt,
} from "../prompts/prompt-loader.js";
import { knowledgeBase } from "../knowledgeBase.js";
import { buildMemorySummary } from "../lib/memory-store.js";

// ─── Types ─────────────────────────────────────────────────────────────────────

export interface BuildToolsOptions {
  sessionKey: string;
  projectId: string;
  /** Build ID — required for build-pipeline modes (brd-analyst, impl-plan, coding, release) */
  buildId?: string;
  /** Current build stage — required for build-pipeline modes */
  stage?: string;
}

export interface BuildPromptOptions {
  projectId: string;
  /** Compact prior-stage context from buildPriorStageContext() */
  priorContext?: string;
}

// ─── Tool Selection ────────────────────────────────────────────────────────────

/**
 * Returns the correct tool set for the given chat mode.
 * Build modes require buildId + stage to be provided so the artifact tool
 * can link saves back to the build.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function buildToolsForMode(mode: string, opts: BuildToolsOptions): any[] {
  const { sessionKey, projectId, buildId, stage } = opts;

  const kbTool = buildFetchKBFileTool();
  const rememberTool = buildRememberTool(projectId);
  const recallTool = buildRecallTool(projectId);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const baseTools: any[] = [kbTool, rememberTool, recallTool];

  switch (mode) {
    case "chat":
      return baseTools;

    case "ud":
      return [...baseTools, buildCreateUDFileTool(sessionKey, projectId, buildId, stage)];

    case "brd-analyst":
      return [
        ...baseTools,
        buildCreateBuildArtifactTool(
          "brd",
          buildId ?? "unknown",
          stage ?? "brd_intake",
          sessionKey,
          projectId
        ),
      ];

    case "impl-plan":
      return [
        ...baseTools,
        buildCreateBuildArtifactTool(
          "impl-plan" as BuildArtifactType,
          buildId ?? "unknown",
          stage ?? "impl_plan",
          sessionKey,
          projectId
        ),
      ];

    case "coding":
      // Coding delegates to the GitHub Coding Agent via the trigger_coding_agent tool.
      // check_copilot_assignee is included so the LLM can diagnose assignment issues.
      return [...baseTools, buildTriggerCodingAgentTool(), buildCheckCopilotAssigneeTool()];

    case "release":
      return [
        ...baseTools,
        buildCreateBuildArtifactTool(
          "release-notes",
          buildId ?? "unknown",
          stage ?? "release_docs",
          sessionKey,
          projectId
        ),
      ];

    default:
      return baseTools;
  }
}

// ─── System Prompt Selection ───────────────────────────────────────────────────

/**
 * Load and assemble the system prompt for the given mode.
 * Injects KB context, memory summary, and optional prior-stage context.
 */
export function buildSystemPromptForMode(
  mode: string,
  opts: BuildPromptOptions
): string {
  const { projectId, priorContext } = opts;

  const projectName = knowledgeBase.getProjectName();
  const coreContext = knowledgeBase.getCoreContext();
  const memorySummary = buildMemorySummary(projectId);

  const common = { projectName, coreContext, memorySummary };

  switch (mode) {
    case "ud":
      return loadUDSystemPrompt({ ...common, priorContext });

    case "brd-analyst":
      return loadBRDSystemPrompt(common);

    case "impl-plan":
      return loadImplPlanSystemPrompt({ ...common, priorContext });

    case "coding":
      return loadCodingSystemPrompt({ ...common, priorContext });

    case "release":
      return loadReleaseSystemPrompt({ ...common, priorContext });

    case "chat":
    default:
      return loadSystemPrompt(common);
  }
}
