/**
 * GitHub Coding Agent Tool — Phase 3b
 *
 * Exposes a `trigger_coding_agent` tool for the coding-stage LLM coordinator.
 * After the user confirms in chat, the LLM calls this tool, which:
 *   1. Creates a GitHub Issue with the implementation plan body
 *   2. Assigns the issue to "copilot" to trigger the Copilot Coding Agent
 *   3. Returns the issue URL and monitoring instructions
 *
 * Only effective when GITHUB_CODING_AGENT_ENABLED=true and GITHUB_TOKEN,
 * GITHUB_REPO_OWNER, GITHUB_REPO_NAME are set.
 *
 * Phase 3b — Full Build Pipeline
 */

import { defineTool } from "@github/copilot-sdk";
import {
  createGitHubIssue,
  triggerCopilotAgent,
  checkCopilotAssignee,
  isCodingAgentEnabled,
  buildPRReviewUrl,
} from "../lib/github-service.js";
import logger from "../lib/logger.js";

/**
 * Build the `trigger_coding_agent` tool.
 * Call this once per coding session and include in the tool list.
 */
export function buildTriggerCodingAgentTool() {
  return defineTool("trigger_coding_agent", {
    description:
      "Create a GitHub Issue from the approved implementation plan and trigger the " +
      "GitHub Copilot Coding Agent to implement it. Call ONLY after the user explicitly " +
      "confirms (says 'yes', 'proceed', 'go ahead', etc.).",
    parameters: {
      type: "object",
      properties: {
        title: {
          type: "string",
          description: "Short descriptive title for the GitHub Issue, e.g. 'Implement user auth feature'",
        },
        body: {
          type: "string",
          description:
            "Full issue body in Markdown — should contain the complete implementation plan " +
            "so the Copilot agent has everything it needs to execute the work.",
        },
        labels: {
          type: "array",
          items: { type: "string" },
          description: "Optional labels to apply to the issue (default: ['copilot-task'])",
        },
      },
      required: ["title", "body"],
    },
    handler: async (args: unknown) => {
      const { title, body, labels } = args as {
        title: string;
        body: string;
        labels?: string[];
      };

      if (!isCodingAgentEnabled()) {
        // Graceful fallback: provide manual instructions
        return (
          "⚠️ GitHub Coding Agent is disabled (GITHUB_CODING_AGENT_ENABLED is not 'true').\n\n" +
          "**Manual steps to trigger the agent:**\n" +
          "1. Go to your repository on GitHub\n" +
          "2. Create a new Issue with the title and body above\n" +
          "3. Assign the issue to `@copilot`\n" +
          "4. The Copilot Coding Agent will pick it up automatically\n\n" +
          "Once the PR is created, approve this stage to advance to Release Documentation."
        );
      }

      try {
        const issue = await createGitHubIssue({ title, body, labels });
        await triggerCopilotAgent(issue.number);

        const prListUrl = buildPRReviewUrl(0).replace("/pull/0", "/pulls");

        logger.info(
          { issueNumber: issue.number, issueUrl: issue.html_url },
          "[github-agent] Issue created and Copilot agent triggered"
        );

        return (
          `✅ GitHub Issue #${issue.number} created and Copilot Coding Agent triggered.\n\n` +
          `**Issue URL:** ${issue.html_url}\n` +
          `**Monitor PRs here:** ${prListUrl}\n\n` +
          `The agent will create a Pull Request referencing issue #${issue.number}. ` +
          `Once the PR is ready for review, you can request changes via \`@copilot\` comments in the PR.\n\n` +
          `When the PR is merged, approve this stage to advance to Release Documentation.`
        );
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : String(err);
        logger.error({ err: message }, "[github-agent] Failed to trigger coding agent");
        return `❌ Failed to trigger GitHub Coding Agent: ${message}`;
      }
    },
  });
}

/**
 * Build the `check_copilot_assignee` diagnostic tool.
 * Lets the LLM verify that "copilot" is a valid assignee before triggering.
 */
export function buildCheckCopilotAssigneeTool() {
  return defineTool("check_copilot_assignee", {
    description:
      "Check whether the GitHub Copilot coding agent is available as a valid assignee " +
      "for the configured repository. Call this as a diagnostic when assignment appears " +
      "to have silently failed. Returns a plain-text status message.",
    parameters: { type: "object", properties: {}, required: [] },
    handler: async (_args: unknown) => {
      if (!isCodingAgentEnabled()) {
        return "⚠️ GITHUB_CODING_AGENT_ENABLED is not true — integration is disabled.";
      }
      try {
        const valid = await checkCopilotAssignee();
        if (valid) {
          return (
            "✅ copilot IS a valid assignee for this repo.\n" +
            "If assignment still doesn't trigger the agent, verify that:\n" +
            "  • 'Copilot coding agent' is enabled in repo Settings → Code and Automation → Copilot\n" +
            "  • The GITHUB_TOKEN has 'repo' (or 'issues') write scope"
          );
        }
        return (
          "❌ copilot is NOT a valid assignee for this repo (GitHub returned 404).\n" +
          "This usually means:\n" +
          "  • The Copilot Coding Agent is not enabled for this repository\n" +
          "  • Enable it at: Settings → Code and Automation → Copilot → Coding agent\n" +
          "  • Or the token lacks 'repo' scope to read assignees\n\n" +
          "Fallback: a @copilot comment will be posted on the issue automatically."
        );
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : String(err);
        logger.error({ err: message }, "[github-agent] checkCopilotAssignee diagnostic failed");
        return `❌ Diagnostic failed: ${message}`;
      }
    },
  });
}
