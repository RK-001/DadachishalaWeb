/**
 * Azure DevOps Work Item Attachment Tool
 *
 * Tool builder for attaching Understanding Documents to Azure DevOps work items.
 * Used in the BRD/UD pipeline for attaching finalized UDs.
 */

import { defineTool } from "@github/copilot-sdk";
import { azureDevOps } from "../azureDevOps.js";
import { withCircuitBreaker } from "../lib/circuit-breaker.js";

const ADO_SERVICE = "azure-devops";

/** Max allowed content length for UD attachments (L5 guard) */
const MAX_CONTENT_BYTES = 5 * 1024 * 1024; // 5 MB

/**
 * Build the attach_ud_to_work_item tool — used in the BRD/UD pipeline.
 *
 * Uploads the Understanding Document to Azure DevOps and links it to the work item.
 * Called ONLY after explicit user approval and AFTER create_ud_file has been called.
 */
export function buildAttachUDToWorkItemTool() {
  return defineTool("attach_ud_to_work_item", {
    description:
      "Upload the Understanding Document to Azure DevOps and link it to the work item. " +
      "ONLY call this tool after: (1) the user explicitly approves the UD, and " +
      "(2) create_ud_file has already been called. Never call this before create_ud_file.",
    parameters: {
      type: "object",
      properties: {
        workItemId: {
          type: "number",
          description: "The numeric Azure DevOps Work Item ID to attach the UD to.",
        },
        filename: {
          type: "string",
          description:
            "The UD filename (e.g. 'UD_WI-1234.md'). Must match the filename used in create_ud_file.",
        },
        content: {
          type: "string",
          description: "The complete UD content in Markdown format.",
        },
        project: {
          type: "string",
          description:
            "Optional Azure DevOps project name. Omit to use the default project (ADO_PROJECT).",
        },
      },
      required: ["workItemId", "filename", "content"],
    },
    handler: async (args: unknown) => {
      const { workItemId, filename, content, project } = args as {
        workItemId: number;
        filename: string;
        content: string;
        project?: string;
      };

      // L5: Validate tool arguments independently
      if (typeof workItemId !== "number" || !Number.isInteger(workItemId) || workItemId <= 0) {
        return `Error: workItemId must be a positive integer`;
      }
      if (typeof filename !== "string" || filename.length === 0 || filename.length > 255
          || /[<>:"/\|?*]/.test(filename)) {
        return `Error: filename must be a valid filename (1-255 chars, no special chars)`;
      }
      if (typeof content !== "string" || content.length === 0) {
        return `Error: content must be a non-empty string`;
      }
      if (Buffer.byteLength(content, "utf8") > MAX_CONTENT_BYTES) {
        return `Error: content exceeds maximum size (5 MB)`;
      }

      console.log(`[tools/ado-attach] attach_ud_to_work_item(${workItemId}, "${filename}")`);
      try {
        const { attachmentUrl } = await withCircuitBreaker(ADO_SERVICE, () =>
          azureDevOps.attachUDToWorkItem(workItemId, filename, content, project)
        );
        const org = process.env.ADO_ORG || "";
        const proj = project || process.env.ADO_PROJECT || "";
        const webUrl =
          `https://dev.azure.com/${encodeURIComponent(org)}` +
          `/${encodeURIComponent(proj)}/_workitems/edit/${workItemId}`;
        return JSON.stringify({ workItemId, attachmentUrl, webUrl });
      } catch (err: any) {
        console.error(`[tools/ado-attach] attach_ud_to_work_item error: ${err.message}`);
        return `Error attaching UD to Work Item #${workItemId}: ${err.message}`;
      }
    },
  });
}
