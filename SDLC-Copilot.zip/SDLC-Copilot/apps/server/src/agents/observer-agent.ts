/**
 * Observer Agent — Phase 4.1
 *
 * Internal Copilot SDK session (not user-facing) that activates when the
 * HealthMonitor detects a degraded skill. Runs a structured self-diagnosis
 * using LLM reasoning and returns a SelfHealPlan with confidence score.
 *
 * Flow:
 *   SKILL_DEGRADED signal
 *     → fetch last 10 errors + MetricsSnapshot
 *     → create ephemeral Copilot session with observer model
 *     → LLM returns JSON SelfHealPlan { diagnosis, action, confidence }
 *     → confidence ≥ 0.85  → executeObserverAction() (autonomous)
 *     → confidence < 0.85  → log for human review
 *     → persist to observer_log table
 *
 * Safe autonomous actions (no human approval):
 *   flush_kb_cache, evict_skill_session, reload_prompt, circuit_open, reset_circuit
 *
 * OBSERVER_MODEL env var (default: claude-haiku-4.5)
 * OBSERVER_CONFIDENCE_THRESHOLD env var (default: 0.85)
 */

import { approveAll } from "@github/copilot-sdk";
import { getCopilotClient } from "../copilot.js";
import { metrics, type ErrorEntry } from "../lib/health.js";
import logger from "../lib/logger.js";
import type { ObserverAction } from "../lib/observer-actions.js";
import { executeObserverAction, persistObserverLog } from "../lib/observer-actions.js";

// ─── Types ─────────────────────────────────────────────────────────────────────

export interface SelfHealPlan {
  diagnosis: string;
  action: ObserverAction;
  confidence: number;
}

// ─── Config ────────────────────────────────────────────────────────────────────

const OBSERVER_MODEL =
  (process.env.OBSERVER_MODEL || "claude-haiku-4.5").trim();

const CONFIDENCE_THRESHOLD =
  Number(process.env.OBSERVER_CONFIDENCE_THRESHOLD) || 0.85;

const OBSERVER_TIMEOUT_MS = 60_000;

// Avoid parallel observer invocations for the same skill simultaneously
const activeObservers = new Set<string>();

// ─── System prompt ─────────────────────────────────────────────────────────────

const OBSERVER_SYSTEM_PROMPT = `You are an internal health-monitoring agent for an AI-powered SDLC assistant.
Your job is to diagnose degraded skills and recommend a safe recovery action.

You will receive:
- The degraded skill name
- The last 10 error log entries
- Current metrics snapshot

Respond ONLY with a valid JSON object in this exact format (no markdown, no explanation):
{
  "diagnosis": "<1-2 sentence root cause explanation>",
  "action": "<one of: flush_kb_cache | evict_skill_session | reload_prompt | circuit_open | reset_circuit | no_action>",
  "confidence": <number between 0.0 and 1.0>
}

Action guidelines:
- flush_kb_cache: if errors mention stale/corrupt knowledge base content
- evict_skill_session: if errors mention session state, token limits, or SDK session issues
- reload_prompt: if errors mention prompt template or system prompt issues
- circuit_open: if errors are caused by external API failures (ADO, GitHub) needing a cooldown
- reset_circuit: if circuit breaker is stuck open but service appears recovered
- no_action: if errors are transient/network or you have low confidence in root cause

Set confidence based on how clearly the errors point to a specific root cause.`;

// ─── Observer Agent ────────────────────────────────────────────────────────────

/**
 * Trigger the observer agent for a degraded skill.
 * Non-blocking — errors are caught and logged, never rethrown.
 */
export async function triggerObserver(skill: string): Promise<void> {
  if (activeObservers.has(skill)) {
    logger.debug(
      { skill },
      "[observer-agent] already running for this skill — skipping"
    );
    return;
  }

  activeObservers.add(skill);

  try {
    await runObserver(skill);
  } catch (err) {
    logger.error({ err, skill }, "[observer-agent] unhandled error");
  } finally {
    activeObservers.delete(skill);
  }
}

async function runObserver(skill: string): Promise<void> {
  logger.info({ skill, model: OBSERVER_MODEL }, "[observer-agent] starting");

  // Gather diagnostics
  const snapshot = metrics.getSnapshot();
  const allErrors = metrics.getErrors();
  const recentErrors = allErrors
    .filter((e: ErrorEntry) => e.skill === skill)
    .slice(-10);

  const skillMetrics = snapshot.skills[skill];

  const userPrompt = `
Degraded skill: "${skill}"

Skill metrics:
${JSON.stringify(skillMetrics ?? { requestCount: 0, errorCount: 0 }, null, 2)}

Recent error log (last ${recentErrors.length} entries):
${recentErrors.length > 0
    ? recentErrors
        .map((e: ErrorEntry) => `[${e.timestamp}] ${e.message}${e.requestId ? ` (reqId: ${e.requestId})` : ""}`)
        .join("\n")
    : "(no recent errors recorded for this skill)"}
`.trim();

  let plan: SelfHealPlan | null = null;
  let session: Awaited<ReturnType<Awaited<ReturnType<typeof getCopilotClient>>["createSession"]>> | null = null;

  try {
    const client = await getCopilotClient();
    session = await client.createSession({
      model: OBSERVER_MODEL,
      streaming: false,
      systemMessage: { mode: "replace", content: OBSERVER_SYSTEM_PROMPT },
      onPermissionRequest: approveAll,
      onUserInputRequest: async () => ({ answer: "", wasFreeform: true }),
    });

    const response = await session.sendAndWait(
      { prompt: userPrompt },
      OBSERVER_TIMEOUT_MS
    );

    const raw = response?.data?.content ?? "";
    plan = parseSelfHealPlan(raw);
  } catch (err: any) {
    logger.error(
      { err, skill },
      "[observer-agent] LLM session failed — falling back to no_action"
    );
    plan = {
      diagnosis: `Observer LLM session failed: ${err?.message ?? String(err)}`,
      action: "no_action",
      confidence: 0,
    };
  } finally {
    if (session) {
      try {
        await session.destroy();
      } catch {
        // ignore destroy errors
      }
    }
  }

  if (!plan) {
    plan = {
      diagnosis: "Could not parse observer response",
      action: "no_action",
      confidence: 0,
    };
  }

  logger.info(
    { skill, ...plan },
    "[observer-agent] SelfHealPlan received"
  );

  // Execute if confidence is sufficient
  let outcome: string;
  if (plan.confidence >= CONFIDENCE_THRESHOLD) {
    const result = await executeObserverAction(plan.action, skill);
    outcome = `autonomous: ${result.detail}`;
    logger.info(
      { skill, action: plan.action, result },
      "[observer-agent] autonomous action executed"
    );
  } else {
    outcome = `escalated: confidence ${plan.confidence.toFixed(2)} below threshold ${CONFIDENCE_THRESHOLD}`;
    logger.warn(
      { skill, plan },
      "[observer-agent] confidence below threshold — escalating for human review"
    );
  }

  persistObserverLog({
    skill,
    diagnosis: plan.diagnosis,
    action: plan.action,
    confidence: plan.confidence,
    outcome,
  });
}

function parseSelfHealPlan(raw: string): SelfHealPlan | null {
  // Strip markdown code fences if present
  const cleaned = raw
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/```\s*$/, "")
    .trim();

  try {
    const parsed = JSON.parse(cleaned) as Record<string, unknown>;
    const diagnosis = typeof parsed.diagnosis === "string" ? parsed.diagnosis : "Unknown";
    const action = (parsed.action as ObserverAction) ?? "no_action";
    const confidence = typeof parsed.confidence === "number"
      ? Math.max(0, Math.min(1, parsed.confidence))
      : 0;
    return { diagnosis, action, confidence };
  } catch {
    logger.warn({ raw }, "[observer-agent] failed to parse SelfHealPlan JSON");
    return null;
  }
}
