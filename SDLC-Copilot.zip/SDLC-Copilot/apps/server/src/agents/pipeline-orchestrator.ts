/**
 * Pipeline Orchestrator — Phase 3
 *
 * Routes incoming build pipeline sessions to the correct skill based on the
 * build's current_stage. Loads prior-stage context (token-minimal) and
 * delegates session creation to the appropriate skill module.
 *
 * This sits alongside OrchestratorAgent (which handles non-build modes).
 *
 * Phase 3 — Multi-stage Build Pipeline
 */

import type { CopilotSession } from "@github/copilot-sdk";
import { getBuild } from "../lib/build-store.js";
import {
  getModeForStage,
  loadPriorStageContext,
  type BuildStage,
} from "../lib/build-lifecycle.js";
import { createBRDSession } from "./skills/brd-analyst.skill.js";
import { createUDSession } from "./skills/ud.skill.js";
import { createImplPlanSession } from "./skills/impl-plan.skill.js";
import { createCodingSession } from "./skills/coding.skill.js";
import { createReleaseSession } from "./skills/release.skill.js";
import logger from "../lib/logger.js";

// ─── Build-mode Sessions ───────────────────────────────────────────────────────

/**
 * Dependency injection placeholder for session recovery context.
 * chatAgent.ts injects the `recoveredContext` string before calling this.
 */
export interface PipelineSessionParams {
  sessionKey: string;
  userId: string;
  projectId: string;
  buildId: string;
  /** Optional override for the stage (defaults to build.currentStage) */
  stage?: string;
  /** Conversation recovery context from SQLite (on server restart) */
  recoveredContext?: string;
}

/**
 * Create a session for the appropriate pipeline stage.
 * Automatically loads prior-stage context if needed (token-capped at 3000 chars).
 */
export async function createPipelineSession(
  params: PipelineSessionParams
): Promise<CopilotSession> {
  const { sessionKey, projectId, buildId, stage: stageOverride, recoveredContext } = params;

  const build = getBuild(buildId);
  if (!build) {
    throw new Error(`Build '${buildId}' not found`);
  }

  const stage = (stageOverride ?? build.currentStage) as BuildStage;
  const mode = getModeForStage(stage);

  // Load prior-stage artifact context (compressed, ≤3000 chars)
  const priorContext = loadPriorStageContext(buildId, stage);
  if (priorContext) {
    logger.info({ buildId, stage }, "[pipeline] Prior context loaded");
  }

  logger.info({ buildId, stage, mode }, "[pipeline] Creating pipeline session");

  switch (mode) {
    case "brd-analyst":
      return createBRDSession({ sessionKey, projectId, buildId, recoveredContext });

    case "ud":
      return createUDSession({
        sessionKey,
        projectId,
        buildId,
        priorContext,
        recoveredContext,
      });

    case "impl-plan":
      return createImplPlanSession({
        sessionKey,
        projectId,
        buildId,
        priorContext,
        recoveredContext,
      });

    case "coding":
      return createCodingSession({
        sessionKey,
        projectId,
        buildId,
        priorContext,
        recoveredContext,
      });

    case "release":
      return createReleaseSession({
        sessionKey,
        projectId,
        buildId,
        priorContext,
        recoveredContext,
      });

    default:
      throw new Error(
        `Pipeline mode '${mode}' for stage '${stage}' is not handled by pipeline orchestrator`
      );
  }
}

/**
 * Resolve the chat mode string for a given build ID + stage.
 * Used by chatAgent.ts to register the session under the correct mode key.
 */
export function resolvePipelineMode(buildId: string, stage?: string): string {
  const build = getBuild(buildId);
  if (!build) return "brd-analyst";

  const effectiveStage = (stage ?? build.currentStage) as BuildStage;
  return getModeForStage(effectiveStage);
}
