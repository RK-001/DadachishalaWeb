/**
 * Implementation Plan Skill — Phase 3b
 *
 * Handles the `impl-plan` mode: reads the approved UD + KB to produce
 * a step-by-step implementation plan artifact.
 *
 * Phase 3b — Full Build Pipeline
 */

import { approveAll, type CopilotSession } from "@github/copilot-sdk";
import { getConfiguredModel, getCopilotClient } from "../../copilot.js";
import { buildToolsForMode, buildSystemPromptForMode } from "../../tools/builder.js";
import logger from "../../lib/logger.js";

export interface ImplPlanSessionParams {
  sessionKey: string;
  projectId: string;
  buildId: string;
  /** Prior stage context (approved UD) — injected into system prompt */
  priorContext?: string;
  recoveredContext?: string;
}

/**
 * Create a Copilot SDK session wired for the Implementation Planner workflow.
 * Called by chatAgent.getOrCreateSession when mode = 'impl-plan'.
 */
export async function createImplPlanSession(
  params: ImplPlanSessionParams
): Promise<CopilotSession> {
  const {
    sessionKey,
    projectId,
    buildId,
    priorContext = "",
    recoveredContext = "",
  } = params;

  const client = await getCopilotClient();
  const model = getConfiguredModel();

  const tools = buildToolsForMode("impl-plan", {
    sessionKey,
    projectId,
    buildId,
    stage: "impl_plan",
  });

  const systemPrompt = buildSystemPromptForMode("impl-plan", {
    projectId,
    priorContext,
  });

  const session = await client.createSession({
    model,
    streaming: true,
    systemMessage: {
      mode: "replace",
      content: systemPrompt + recoveredContext,
    },
    tools,
    infiniteSessions: { enabled: true },
    onPermissionRequest: approveAll,
    onUserInputRequest: async (req: { question: string }) => {
      logger.warn({ question: req.question }, "[impl-plan] User input requested (auto-skip)");
      return { answer: "", wasFreeform: true };
    },
  });

  logger.info({ sessionKey, buildId }, "[impl-plan] Session created");
  return session;
}
