/**
 * UD (User Document) Analyst Skill — Pipeline Mode
 *
 * Handles the `ud` mode within the build pipeline: drafts a User Document
 * from the approved BRD, using prior-stage context injected into the system prompt.
 * Sessions use the ud-system-prompt.md template.
 *
 * Phase A (UX v2) — Extracted from chatAgent.ts for pipeline integration
 */

import { approveAll, type CopilotSession } from "@github/copilot-sdk";
import { getConfiguredModel, getCopilotClient } from "../../copilot.js";
import { buildToolsForMode, buildSystemPromptForMode } from "../../tools/builder.js";
import logger from "../../lib/logger.js";

export interface UDSessionParams {
  sessionKey: string;
  projectId: string;
  buildId?: string;
  /** Prior-stage context (BRD artifact content, compressed) */
  priorContext?: string;
  recoveredContext?: string;
}

/**
 * Create a Copilot SDK session wired for the UD Analyst workflow.
 * Accepts optional buildId for pipeline-scoped artifact creation.
 */
export async function createUDSession(params: UDSessionParams): Promise<CopilotSession> {
  const { sessionKey, projectId, buildId, priorContext, recoveredContext = "" } = params;

  const client = await getCopilotClient();
  const model = getConfiguredModel();

  const tools = buildToolsForMode("ud", {
    sessionKey,
    projectId,
    buildId,
    stage: "ud_draft",
  });

  const systemPrompt = buildSystemPromptForMode("ud", { projectId, priorContext });

  const session = await client.createSession({
    model,
    streaming: true,
    systemMessage: {
      mode: "replace",
      content: systemPrompt + recoveredContext,
    },
    tools,
    infiniteSessions: { enabled: true },
    onPermissionRequest: approveAll,
    onUserInputRequest: async (req: { question: string }) => {
      logger.warn({ question: req.question }, "[ud-skill] User input requested (auto-skip)");
      return { answer: "", wasFreeform: true };
    },
  });

  logger.info({ sessionKey, buildId }, "[ud-skill] Session created");
  return session;
}
