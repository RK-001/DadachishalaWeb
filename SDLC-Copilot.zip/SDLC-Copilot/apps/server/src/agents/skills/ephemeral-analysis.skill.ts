/**
 * EphemeralAnalysisSkill — Phase 0.3
 *
 * A generalized, one-shot content analysis skill backed by an ephemeral
 * Copilot SDK session (no conversation history, destroyed after each call).
 *
 * Designed for re-use across:
 *   Phase 0.3  — file / text summarization (replaces copilot.summarizeFileContent)
 *   Phase 3    — PR diff review, test case generation, release note drafting
 *
 * The caller provides:
 *   systemPrompt — defines the analyst role and output format
 *   userPrompt   — the content + task for this specific request
 *   onChunk      — optional SSE streaming callback
 *
 * Retry: 3× via wrapHandler() at 1 s / 2 s / 4 s backoff.
 * Fallback: none (ephemeral analysis has no cheaper fallback mode).
 *
 * Phase 0.3 — Generalized Skill Foundation
 */

import { approveAll } from "@github/copilot-sdk";
import type { SkillDescriptor } from "../registry.js";
import { skillRegistry } from "../registry.js";
import { getCopilotClient, getConfiguredModel } from "../../copilot.js";

// ─── BaseSkill (merged from base.skill.ts) ─────────────────────────────────────

abstract class BaseSkill implements SkillDescriptor {
  abstract readonly mode: string;
  abstract readonly displayName: string;
  readonly fallbackMode: string | null = null;

  /**
   * Wrap an async operation with 3× retry and exponential backoff.
   * Backoff delays: 1 000 ms → 2 000 ms → 4 000 ms.
   */
  protected async wrapHandler<T>(
    operationName: string,
    fn: () => Promise<T>
  ): Promise<T> {
    const delays = [1_000, 2_000, 4_000];
    let lastErr: unknown;

    for (let attempt = 0; attempt < delays.length; attempt++) {
      try {
        const result = await fn();
        skillRegistry.markHealthy(this.mode);
        return result;
      } catch (err) {
        lastErr = err;
        const isLast = attempt === delays.length - 1;
        console.warn(
          `[${this.mode}] "${operationName}" attempt ${attempt + 1}/${delays.length} failed:`,
          (err as Error)?.message ?? err
        );

        if (!isLast) {
          await new Promise<void>((r) => setTimeout(r, delays[attempt]));
        }
      }
    }

    skillRegistry.markDegraded(this.mode);
    throw lastErr;
  }
}

// ─── EphemeralAnalysisSkill ────────────────────────────────────────────────────

/** Maximum input chars before truncation (prevents runaway LLM cost). */
const DEFAULT_MAX_CHARS = 30_000;

/** Timeout for sendAndWait in ms. */
const ANALYSIS_TIMEOUT_MS = 180_000;

export interface EphemeralAnalysisParams {
  /** Role + output format instructions for the LLM. */
  systemPrompt: string;
  /** Content + task description. */
  userPrompt: string;
  /** Override configured model for this request. */
  model?: string;
  /** Truncate userPrompt content at this many chars. Default 30 000. */
  maxContentChars?: number;
  /** If provided, text chunks are streamed here as they are generated. */
  onChunk?: (chunk: string) => void;
}

export class EphemeralAnalysisSkill extends BaseSkill {
  readonly mode = "ephemeral-analysis";
  readonly displayName = "Content Analyzer";
  readonly fallbackMode = null; // no cheaper fallback for one-shot analysis

  /**
   * Run a one-shot analysis and return the full response text.
   * Creates an ephemeral Copilot session, sends the prompt, waits for
   * completion, then destroys the session immediately.
   */
  async analyze(params: EphemeralAnalysisParams): Promise<string> {
    return this.wrapHandler("analyze", async () => {
      const {
        systemPrompt,
        userPrompt,
        model: overrideModel,
        maxContentChars = DEFAULT_MAX_CHARS,
        onChunk,
      } = params;

      // Truncate content to prevent exceeding context window / cost limits
      let prompt = userPrompt;
      if (prompt.length > maxContentChars) {
        prompt = prompt.slice(0, maxContentChars);
        console.log(
          `[ephemeral-analysis] userPrompt truncated to ${maxContentChars} chars`
        );
      }

      const client = await getCopilotClient();
      const model = overrideModel ?? getConfiguredModel();
      const useStreaming = !!onChunk;

      const session = await client.createSession({
        model,
        streaming: useStreaming,
        systemMessage: { mode: "replace", content: systemPrompt },
        onPermissionRequest: approveAll,
        onUserInputRequest: async () => ({ answer: "", wasFreeform: true }),
      });

      // Stream handler — must be registered before sendAndWait
      let fullResponse = "";
      if (onChunk) {
        session.on("assistant.message_delta", (event: any) => {
          const delta: string = event.data?.deltaContent ?? "";
          if (delta) {
            fullResponse += delta;
            onChunk(delta);
          }
        });
      }

      try {
        const response = await session.sendAndWait(
          { prompt },
          ANALYSIS_TIMEOUT_MS
        );
        if (!onChunk && response?.data?.content) {
          fullResponse = response.data.content;
        }
        return fullResponse;
      } finally {
        await session.destroy();
      }
    });
  }
}

/** Singleton — one skill instance registers itself in the registry at startup. */
export const ephemeralAnalysisSkill = new EphemeralAnalysisSkill();
