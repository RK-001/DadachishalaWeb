/**
 * Release Skill — Phase 3b
 *
 * Handles the `release` mode: generates release notes and KB update
 * suggestions based on the completed coding work.
 *
 * Phase 3b — Full Build Pipeline
 */

import { approveAll, type CopilotSession } from "@github/copilot-sdk";
import { getConfiguredModel, getCopilotClient } from "../../copilot.js";
import { buildToolsForMode, buildSystemPromptForMode } from "../../tools/builder.js";
import logger from "../../lib/logger.js";

export interface ReleaseSessionParams {
  sessionKey: string;
  projectId: string;
  buildId: string;
  /** Prior stage context (implementation plan or PR details) */
  priorContext?: string;
  recoveredContext?: string;
}

/**
 * Create a Copilot SDK session wired for the Release Documentation workflow.
 * Called by chatAgent.getOrCreateSession when mode = 'release'.
 */
export async function createReleaseSession(
  params: ReleaseSessionParams
): Promise<CopilotSession> {
  const {
    sessionKey,
    projectId,
    buildId,
    priorContext = "",
    recoveredContext = "",
  } = params;

  const client = await getCopilotClient();
  const model = getConfiguredModel();

  const tools = buildToolsForMode("release", {
    sessionKey,
    projectId,
    buildId,
    stage: "release_docs",
  });

  const systemPrompt = buildSystemPromptForMode("release", {
    projectId,
    priorContext,
  });

  const session = await client.createSession({
    model,
    streaming: true,
    systemMessage: {
      mode: "replace",
      content: systemPrompt + recoveredContext,
    },
    tools,
    infiniteSessions: { enabled: true },
    onPermissionRequest: approveAll,
    onUserInputRequest: async (req: { question: string }) => {
      logger.warn({ question: req.question }, "[release] User input requested (auto-skip)");
      return { answer: "", wasFreeform: true };
    },
  });

  logger.info({ sessionKey, buildId }, "[release] Session created");
  return session;
}
