/**
 * Coding Skill — Phase 3b
 *
 * Handles the `coding` mode: coordinator between the approved Implementation Plan
 * and the GitHub Copilot Coding Agent.
 *
 * The LLM guides the user through confirming the GitHub issue creation and
 * agent trigger. Actual GitHub API calls are handled by github-service.ts.
 *
 * Phase 3b — Full Build Pipeline
 */

import { approveAll, type CopilotSession } from "@github/copilot-sdk";
import { getConfiguredModel, getCopilotClient } from "../../copilot.js";
import { buildToolsForMode, buildSystemPromptForMode } from "../../tools/builder.js";
import logger from "../../lib/logger.js";

export interface CodingSessionParams {
  sessionKey: string;
  projectId: string;
  buildId: string;
  /** Prior stage context (approved ImplPlan) — injected into system prompt */
  priorContext?: string;
  recoveredContext?: string;
}

/**
 * Create a Copilot SDK session wired for the Coding Agent Coordinator workflow.
 * Called by chatAgent.getOrCreateSession when mode = 'coding'.
 */
export async function createCodingSession(
  params: CodingSessionParams
): Promise<CopilotSession> {
  const {
    sessionKey,
    projectId,
    buildId,
    priorContext = "",
    recoveredContext = "",
  } = params;

  const client = await getCopilotClient();
  const model = getConfiguredModel();

  const tools = buildToolsForMode("coding", {
    sessionKey,
    projectId,
    buildId,
    stage: "coding",
  });

  const systemPrompt = buildSystemPromptForMode("coding", {
    projectId,
    priorContext,
  });

  const session = await client.createSession({
    model,
    streaming: true,
    systemMessage: {
      mode: "replace",
      content: systemPrompt + recoveredContext,
    },
    tools,
    infiniteSessions: { enabled: true },
    onPermissionRequest: approveAll,
    onUserInputRequest: async (req: { question: string }) => {
      logger.warn({ question: req.question }, "[coding] User input requested (auto-skip)");
      return { answer: "", wasFreeform: true };
    },
  });

  logger.info({ sessionKey, buildId }, "[coding] Session created");
  return session;
}
