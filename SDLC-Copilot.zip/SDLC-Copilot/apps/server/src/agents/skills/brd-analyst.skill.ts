/**
 * BRD Analyst Skill — Phase 3a
 *
 * Handles the `brd-analyst` mode: guided Q&A to produce a BRD artifact.
 * Sessions use the brd-system-prompt.md template.
 *
 * Phase 3a — BRD → UD → Approval
 */

import { approveAll, type CopilotSession } from "@github/copilot-sdk";
import { getConfiguredModel, getCopilotClient } from "../../copilot.js";
import { buildToolsForMode, buildSystemPromptForMode } from "../../tools/builder.js";
import logger from "../../lib/logger.js";

export interface BRDSessionParams {
  sessionKey: string;
  projectId: string;
  buildId: string;
  recoveredContext?: string;
}

/**
 * Create a Copilot SDK session wired for the BRD Analyst workflow.
 * Called by chatAgent.getOrCreateSession when mode = 'brd-analyst'.
 */
export async function createBRDSession(params: BRDSessionParams): Promise<CopilotSession> {
  const { sessionKey, projectId, buildId, recoveredContext = "" } = params;

  const client = await getCopilotClient();
  const model = getConfiguredModel();

  const tools = buildToolsForMode("brd-analyst", {
    sessionKey,
    projectId,
    buildId,
    stage: "brd_intake",
  });

  const systemPrompt = buildSystemPromptForMode("brd-analyst", { projectId });

  const session = await client.createSession({
    model,
    streaming: true,
    systemMessage: {
      mode: "replace",
      content: systemPrompt + recoveredContext,
    },
    tools,
    infiniteSessions: { enabled: true },
    onPermissionRequest: approveAll,
    onUserInputRequest: async (req: { question: string }) => {
      logger.warn({ question: req.question }, "[brd-analyst] User input requested (auto-skip)");
      return { answer: "", wasFreeform: true };
    },
  });

  logger.info({ sessionKey, buildId }, "[brd-analyst] Session created");
  return session;
}
