/**
 * SkillRegistry — Phase 0.3
 *
 * Singleton registry for all skills. Tracks health state and resolves
 * fallback chains. Used by OrchestratorAgent and HealthMonitor.
 *
 * Security — S9 (cross-skill tool elevation):
 *   resolveFallback() validates the proposed fallback is in APPROVED_FALLBACKS
 *   at registration time. An unknown or reversed fallback is rejected.
 *
 * Phase 0.3 — Skill System Foundation
 */

// ─── Types (merged from types.ts) ─────────────────────────────────────────────
import logger from "../lib/logger.js";
export type SkillHealth = "healthy" | "degraded" | "unknown";

export type SelfHealAction = "retry" | "fallback" | "abort" | "evict_session";

export interface SkillDescriptor {
  readonly mode: string;
  readonly displayName: string;
  readonly fallbackMode: string | null;
}

export interface AgentContext {
  sessionId: string;
  userId: string;
  mode: string;
  projectId?: string;
  requestId?: string;
}

export interface SkillRegistryEntry {
  descriptor: SkillDescriptor;
  health: SkillHealth;
}

export const APPROVED_FALLBACKS: Record<string, string | null> = {
  "ephemeral-analysis": null,
  // Phase 3 — Build Pipeline modes (all standalone, no cross-skill elevation)
  "brd-analyst":      null,
  "impl-plan":        null,
  "coding":           null,
  "release":          null,
  "chat":             null,
  "ud":               null,
};

class SkillRegistry {
  private entries = new Map<string, SkillRegistryEntry>();

  /**
   * Register a skill.
   * Validates that its declared fallbackMode is in the approved fallback map.
   * Throws if the fallback would grant elevated tool access.
   */
  register(descriptor: SkillDescriptor): void {
    const { mode, fallbackMode } = descriptor;

    // Validate fallback is approved (S9 — no cross-skill tool elevation)
    if (fallbackMode !== undefined && fallbackMode !== null) {
      const approved = APPROVED_FALLBACKS[mode];
      if (approved !== fallbackMode) {
        throw new Error(
          `[registry] Skill "${mode}" declares fallback "${fallbackMode}" ` +
            `but approved fallback is "${approved ?? "null"}". ` +
            `Blocked to prevent tool-set elevation.`
        );
      }
    }

    this.entries.set(mode, { descriptor, health: "healthy" });
    logger.info({ mode, fallback: fallbackMode ?? "none" }, `[registry] Registered skill: ${mode}`);
  }

  /**
   * Resolve a skill by mode.
   * Throws AppError-style error for unknown modes (caller converts to 400).
   */
  resolve(mode: string): SkillDescriptor {
    const entry = this.entries.get(mode);
    if (!entry) {
      throw new Error(`Unknown skill mode: "${mode}". Registered: [${[...this.entries.keys()].join(", ")}]`);
    }
    return entry.descriptor;
  }

  /**
   * Resolve the fallback skill for a given mode.
   * Returns null if the mode has no fallback or the fallback is not registered.
   */
  resolveFallback(mode: string): SkillDescriptor | null {
    const entry = this.entries.get(mode);
    if (!entry?.descriptor.fallbackMode) return null;

    const fallback = this.entries.get(entry.descriptor.fallbackMode);
    return fallback?.descriptor ?? null;
  }

  /** Mark a skill as degraded (health monitoring and failure counting). */
  markDegraded(mode: string): void {
    const entry = this.entries.get(mode);
    if (entry && entry.health !== "degraded") {
      entry.health = "degraded";
      logger.warn({ mode }, `[registry] Skill "${mode}" marked DEGRADED`);
    }
  }

  /** Mark a skill as healthy after successful recovery. */
  markHealthy(mode: string): void {
    const entry = this.entries.get(mode);
    if (entry && entry.health !== "healthy") {
      entry.health = "healthy";
      logger.info({ mode }, `[registry] Skill "${mode}" marked HEALTHY`);
    }
  }

  getHealth(mode: string): SkillHealth {
    return this.entries.get(mode)?.health ?? "unknown";
  }

  isRegistered(mode: string): boolean {
    return this.entries.has(mode);
  }

  /** Returns a snapshot of all registered skills and their health. */
  list(): Array<{ mode: string; displayName: string; health: SkillHealth; fallbackMode: string | null }> {
    return [...this.entries.values()].map(({ descriptor, health }) => ({
      mode: descriptor.mode,
      displayName: descriptor.displayName,
      health,
      fallbackMode: descriptor.fallbackMode,
    }));
  }
}

// Singleton export
export const skillRegistry = new SkillRegistry();
