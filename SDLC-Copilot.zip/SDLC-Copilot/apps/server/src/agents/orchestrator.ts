/**
 * OrchestratorAgent — Phase 0.3
 *
 * Thin routing layer that sits in front of chatAgent.ts.
 * Responsibilities:
 *   1. Validate mode is registered in SkillRegistry
 *   2. If skill is degraded, route to fallback mode
 *   3. Acquire the session via chatAgent.getOrCreateSession()
 *   4. On session-creation failure: retry once on same mode → try fallback → throw
 *
 * chatAgent.ts is kept intact (wrap strategy — lower risk).
 * The session creation, tool wiring, and SDK lifecycle all live in chatAgent.ts.
 *
 * Fallback validation: fallbacks are declared per-skill and checked against
 * APPROVED_FALLBACKS at registration time (S9 — no tool elevation).
 *
 * Phase 0.3 — OrchestratorAgent (wrap strategy)
 */

import type { CopilotSession } from "@github/copilot-sdk";
import { skillRegistry } from "./registry.js";
import { getOrCreateSession, makeSessionKey } from "../chatAgent.js";
import { ephemeralAnalysisSkill, type EphemeralAnalysisParams } from "./skills/ephemeral-analysis.skill.js";
import { AppError, logger } from "../lib/logger.js";
import { getProject } from "../lib/project-store.js";
import { sessionRegistry } from "../lib/session-registry.js";

class OrchestratorAgent {

  // ─── Chat-mode routing ───────────────────────────────────────────────────────

  /**
   * Get or create a persistent Copilot session for a chat-mode request.
   *
   * Routing logic:
   *   1. Resolve skill from registry (400 on unknown mode)
   *   2. If skill health is "degraded", route to fallback mode immediately
   *   3. Attempt chatAgent.getOrCreateSession() for the resolved mode
   *   4. On failure: retry once → try fallback → throw 503
   */
  async getOrCreateSession(
    sessionId: string,
    mode: string,
    userId: string,
    projectId: string = "default"
  ): Promise<CopilotSession> {
    // Step 0 — Load project config and enforce enabled_modes (Phase 0.4)
    const project = getProject(projectId);
    if (!project) {
      throw new AppError(`Unknown project: "${projectId}"`, "UNKNOWN_PROJECT", 400);
    }
    if (!project.enabledModes.includes(mode)) {
      throw new AppError(
        `Mode "${mode}" is not enabled for project "${projectId}"`,
        "MODE_NOT_ENABLED",
        403
      );
    }

    // Step 1 — Resolve and validate mode
    let resolvedMode = mode;
    try {
      const skill = skillRegistry.resolve(mode);

      // Step 2 — If degraded, try fallback immediately (save the user one doomed attempt)
      if (skillRegistry.getHealth(skill.mode) === "degraded") {
        const fallback = skillRegistry.resolveFallback(skill.mode);
        if (fallback) {
          logger.warn(
            { from: skill.mode, to: fallback.mode },
            `[orchestrator] Skill degraded — routing to fallback`
          );
          resolvedMode = fallback.mode;
        }
      }
    } catch {
      throw new AppError(`Unknown mode: "${mode}"`, "UNKNOWN_MODE", 400);
    }

    // Step 3 — Multi-instance routing check (Phase 2.1)
    // Allows a different instance to have already claimed this session.
    // In single-instance deployments, isOwnedByThisInstance() always returns
    // true (or false for new sessions that haven't been registered yet).
    const existing = sessionRegistry.lookup(makeSessionKey(userId, sessionId, resolvedMode));
    if (existing && !sessionRegistry.isOwnedByThisInstance(makeSessionKey(userId, sessionId, resolvedMode))) {
      throw new AppError(
        "Session is owned by another server instance. Use sticky routing or wait for session expiry.",
        "SESSION_OWNED_BY_OTHER_INSTANCE",
        409
      );
    }

    // Step 4 — Attempt session acquisition (retry once on failure)
    const attemptSession = async (m: string): Promise<CopilotSession> => {
      try {
        return await getOrCreateSession(sessionId, m, userId, projectId);
      } catch (err) {
        logger.warn({ mode: m, err: (err as Error).message }, "[orchestrator] Session creation failed (attempt 1)");
        // Retry once
        try {
          return await getOrCreateSession(sessionId, m, userId, projectId);
        } catch (retryErr) {
          logger.error({ mode: m, err: (retryErr as Error).message }, "[orchestrator] Session creation failed (attempt 2)");
          skillRegistry.markDegraded(m);
          throw retryErr;
        }
      }
    };

    // Step 5 — Try resolved mode; on failure, try fallback; then throw 503
    const sessionKey = makeSessionKey(userId, sessionId, resolvedMode);
    try {
      const session = await attemptSession(resolvedMode);
      // Register / refresh session in registry on successful acquisition
      sessionRegistry.register(sessionKey, { mode: resolvedMode, projectId });
      return session;
    } catch {
      const fallback = skillRegistry.resolveFallback(resolvedMode);
      if (fallback && fallback.mode !== resolvedMode) {
        logger.warn(
          { from: resolvedMode, to: fallback.mode },
          "[orchestrator] Falling back after primary mode failure"
        );
        try {
          const fallbackSession = await attemptSession(fallback.mode);
          const fallbackKey = makeSessionKey(userId, sessionId, fallback.mode);
          sessionRegistry.register(fallbackKey, { mode: fallback.mode, projectId });
          return fallbackSession;
        } catch (fallbackErr) {
          skillRegistry.markDegraded(fallback.mode);
          throw new AppError(
            "The assistant is temporarily unavailable. Please try again in a moment.",
            "SKILL_UNAVAILABLE",
            503
          );
        }
      }
      throw new AppError(
        "The assistant is temporarily unavailable. Please try again in a moment.",
        "SKILL_UNAVAILABLE",
        503
      );
    }
  }

  // ─── Ephemeral analysis routing ──────────────────────────────────────────────

  /**
   * Route a one-shot analysis request to EphemeralAnalysisSkill.
   * This is used by the summarize route and future PR review / test-gen routes.
   */
  async analyze(params: EphemeralAnalysisParams): Promise<string> {
    return ephemeralAnalysisSkill.analyze(params);
  }
}

/** Singleton OrchestratorAgent */
export const orchestrator = new OrchestratorAgent();

// ─── Skill registration (called from index.ts at startup) ─────────────────────

/**
 * Register all skills. Must be called after initDb() and before any route traffic.
 * Chat-mode skills are thin descriptors; session management stays in chatAgent.ts.
 */
/**
 * Register all Phase 3 build pipeline skills in the SkillRegistry.
 * Called once at server startup before any sessions are created.
 */
function registerPhase3Skills(): void {
  // BRD Analyst — Phase 3a
  skillRegistry.register({ mode: "brd-analyst", displayName: "BRD Analyst", fallbackMode: null });
  // UD mode — Phase 1 (if not already registered)
  if (!skillRegistry.isRegistered("ud")) {
    skillRegistry.register({ mode: "ud", displayName: "UD Analyst", fallbackMode: null });
  }
  // Chat mode
  if (!skillRegistry.isRegistered("chat")) {
    skillRegistry.register({ mode: "chat", displayName: "KB Chat", fallbackMode: null });
  }
  // Phase 3b skills
  skillRegistry.register({ mode: "impl-plan", displayName: "Implementation Planner", fallbackMode: null });
  skillRegistry.register({ mode: "coding", displayName: "Coding Coordinator", fallbackMode: null });
  skillRegistry.register({ mode: "release", displayName: "Release Documenter", fallbackMode: null });
}

export function registerSkills(): void {
  // Standalone ephemeral skill
  skillRegistry.register(ephemeralAnalysisSkill);

  // Phase 3 build pipeline skills
  registerPhase3Skills();
}
