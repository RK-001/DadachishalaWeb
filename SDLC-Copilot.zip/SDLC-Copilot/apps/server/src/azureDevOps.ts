/**
 * Azure DevOps REST API service
 *
 * Provides work item fetch and UD attachment operations for SDLC Agent mode.
 * Follows the same patterns as github.ts: retry-with-backoff, PAT auth,
 * environment-variable-based configuration, and descriptive error messages.
 *
 * Required env vars:
 *   ADO_ORG     — Azure DevOps organization name (e.g. "myorg" in dev.azure.com/myorg)
 *   ADO_PROJECT — Default project for work item lookups
 *   ADO_PAT     — Personal Access Token with Work Items (Read, Write) scope
 *
 * Optional env vars:
 *   ADO_API_VERSION — ADO REST API version (default: "7.1")
 */

const ADO_BASE = "https://dev.azure.com";
const MAX_RETRIES = 2;

// ─── Config ────────────────────────────────────────────────────────────────────

function getConfig() {
  return {
    org: process.env.ADO_ORG,
    project: process.env.ADO_PROJECT,
    pat: process.env.ADO_PAT,
    apiVersion: process.env.ADO_API_VERSION || "7.1",
  };
}

// ─── Auth ──────────────────────────────────────────────────────────────────────

/** Azure DevOps Basic auth: base64(":{PAT}") */
function buildAuthHeader(pat: string): string {
  return `Basic ${Buffer.from(`:${pat}`).toString("base64")}`;
}

// ─── HTML sanitization ─────────────────────────────────────────────────────────

/**
 * Strip HTML tags and decode common entities from ADO rich-text fields
 * (Description, Acceptance Criteria) so the LLM receives clean plain text.
 */
function stripHtml(html: string): string {
  return (html || "")
    .replace(/<[^>]*>/g, " ")      // Replace tags with spaces
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;|&#160;/g, " ")
    .replace(/\s{2,}/g, " ")       // Collapse whitespace runs
    .trim();
}

// ─── Error types ───────────────────────────────────────────────────────────────

/** Custom error carrying the HTTP status for retry-vs-no-retry decisions. */
class AdoError extends Error {
  constructor(message: string, public readonly status: number) {
    super(message);
    this.name = "AdoError";
  }
}

function mapAdoError(status: number, context: string): string {
  switch (status) {
    case 401:
    case 403:
      return (
        `Azure DevOps access denied. Verify ADO_PAT has "Work Items (Read, Write)" scope. ` +
        `(HTTP ${status})`
      );
    case 404:
      return `Not found: ${context}. Verify the Work Item ID and ADO_PROJECT.`;
    case 429:
      return "Azure DevOps rate limit exceeded. Try again shortly.";
    default:
      return `Azure DevOps API error HTTP ${status}: ${context}`;
  }
}

// ─── Retry wrapper ─────────────────────────────────────────────────────────────

/** Retry up to MAX_RETRIES times, with exponential backoff, for 5xx + network errors. */
async function withRetry<T>(label: string, fn: () => Promise<T>): Promise<T> {
  let lastError: Error = new Error(`Failed: ${label}`);

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    if (attempt > 0) {
      const delay = 1000 * attempt; // 1 s, then 2 s
      console.log(`[azureDevOps] Retry ${attempt}/${MAX_RETRIES} for "${label}" after ${delay}ms`);
      await new Promise((r) => setTimeout(r, delay));
    }

    try {
      return await fn();
    } catch (err: any) {
      // No retry for 4xx — these are definitive client/auth errors
      if (err instanceof AdoError && err.status < 500) throw err;
      lastError = err;
      if (attempt >= MAX_RETRIES) throw err;
    }
  }

  throw lastError;
}

// ─── Work Item type (mirrors ADOWorkItem in @sdlc-copilot/shared) ──────────────

export interface WorkItemResult {
  id: number;
  title: string;
  description: string;
  acceptanceCriteria: string;
  state: string;
  assignedTo?: string;
  areaPath: string;
  iterationPath?: string;
  tags: string[];
  workItemType: string;
  url: string;
}

// ─── fetchWorkItem ─────────────────────────────────────────────────────────────

/**
 * Fetch a single work item from Azure DevOps by numeric ID.
 * Strips HTML from rich-text fields so the LLM receives plain text.
 */
async function fetchWorkItem(
  workItemId: number,
  overrideProject?: string,
): Promise<WorkItemResult> {
  const { org, project: defaultProject, pat, apiVersion } = getConfig();
  const project = overrideProject || defaultProject;

  if (!org || !project || !pat) {
    throw new Error(
      "Azure DevOps is not configured. Set ADO_ORG, ADO_PROJECT, and ADO_PAT in your .env file.",
    );
  }

  const url =
    `${ADO_BASE}/${encodeURIComponent(org)}/${encodeURIComponent(project)}` +
    `/_apis/wit/workitems/${workItemId}?$expand=all&api-version=${apiVersion}`;

  return withRetry(`fetchWorkItem(#${workItemId})`, async () => {
    const res = await fetch(url, {
      headers: {
        Authorization: buildAuthHeader(pat),
        Accept: "application/json",
        "User-Agent": "SDLC-Copilot",
      },
    });

    if (!res.ok) {
      throw new AdoError(
        mapAdoError(res.status, `Work Item #${workItemId} in ${org}/${project}`),
        res.status,
      );
    }

    const data = (await res.json()) as { id: number; fields: Record<string, unknown> };
    const f = data.fields;

    // AssignedTo can be an object { displayName } or a plain string
    const assignedTo = f["System.AssignedTo"] as
      | { displayName?: string }
      | string
      | undefined;
    const assignedToName =
      typeof assignedTo === "object" && assignedTo !== null
        ? assignedTo.displayName
        : (assignedTo as string | undefined);

    const rawTags = f["System.Tags"] as string | undefined;
    const tags = rawTags
      ? rawTags
          .split(";")
          .map((t) => t.trim())
          .filter(Boolean)
      : [];

    return {
      id: f["System.Id"] as number,
      title: f["System.Title"] as string,
      description: stripHtml((f["System.Description"] as string) || ""),
      acceptanceCriteria: stripHtml(
        (f["Microsoft.VSTS.Common.AcceptanceCriteria"] as string) || "",
      ),
      state: f["System.State"] as string,
      assignedTo: assignedToName,
      areaPath: f["System.AreaPath"] as string,
      iterationPath: f["System.IterationPath"] as string | undefined,
      tags,
      workItemType: f["System.WorkItemType"] as string,
      url:
        `${ADO_BASE}/${encodeURIComponent(org)}/${encodeURIComponent(project)}` +
        `/_workitems/edit/${workItemId}`,
    };
  });
}

// ─── uploadAttachment ──────────────────────────────────────────────────────────

/**
 * Upload file content to Azure DevOps as an attachment.
 * Returns the attachment ID and URL needed to link it to a work item.
 */
async function uploadAttachment(
  filename: string,
  content: string,
  overrideProject?: string,
): Promise<{ id: string; url: string }> {
  const { org, project: defaultProject, pat, apiVersion } = getConfig();
  const project = overrideProject || defaultProject;

  if (!org || !project || !pat) {
    throw new Error(
      "Azure DevOps is not configured. Set ADO_ORG, ADO_PROJECT, and ADO_PAT in your .env file.",
    );
  }

  const url =
    `${ADO_BASE}/${encodeURIComponent(org)}/${encodeURIComponent(project)}` +
    `/_apis/wit/attachments?fileName=${encodeURIComponent(filename)}&api-version=${apiVersion}`;

  return withRetry(`uploadAttachment("${filename}")`, async () => {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: buildAuthHeader(pat),
        "Content-Type": "application/octet-stream",
        "User-Agent": "SDLC-Copilot",
      },
      body: Buffer.from(content, "utf-8"),
    });

    if (!res.ok) {
      throw new AdoError(
        mapAdoError(res.status, `upload attachment "${filename}"`),
        res.status,
      );
    }

    const data = (await res.json()) as { id: string; url: string };
    return { id: data.id, url: data.url };
  });
}

// ─── linkAttachmentToWorkItem ──────────────────────────────────────────────────

/**
 * Add an uploaded attachment to a work item's relations via JSON Patch.
 */
async function linkAttachmentToWorkItem(
  workItemId: number,
  attachmentUrl: string,
  filename: string,
  overrideProject?: string,
): Promise<void> {
  const { org, project: defaultProject, pat, apiVersion } = getConfig();
  const project = overrideProject || defaultProject;

  if (!org || !project || !pat) {
    throw new Error(
      "Azure DevOps is not configured. Set ADO_ORG, ADO_PROJECT, and ADO_PAT in your .env file.",
    );
  }

  const url =
    `${ADO_BASE}/${encodeURIComponent(org)}/${encodeURIComponent(project)}` +
    `/_apis/wit/workitems/${workItemId}?api-version=${apiVersion}`;

  const patchBody = JSON.stringify([
    {
      op: "add",
      path: "/relations/-",
      value: {
        rel: "AttachedFile",
        url: attachmentUrl,
        attributes: {
          comment: "Understanding Document attached by SDLC Copilot",
          name: filename,
        },
      },
    },
  ]);

  await withRetry(`linkAttachment(#${workItemId})`, async () => {
    const res = await fetch(url, {
      method: "PATCH",
      headers: {
        Authorization: buildAuthHeader(pat),
        "Content-Type": "application/json-patch+json",
        "User-Agent": "SDLC-Copilot",
      },
      body: patchBody,
    });

    if (!res.ok) {
      throw new AdoError(
        mapAdoError(res.status, `link attachment to Work Item #${workItemId}`),
        res.status,
      );
    }
  });
}

// ─── Public service object ─────────────────────────────────────────────────────

export const azureDevOps = {
  /**
   * Check that all required ADO environment variables are set.
   * Called at startup — returns false and logs a warning if misconfigured.
   */
  validateConfig(): boolean {
    const { org, project, pat, apiVersion } = getConfig();
    const missing = [
      !org && "ADO_ORG",
      !project && "ADO_PROJECT",
      !pat && "ADO_PAT",
    ].filter(Boolean);

    if (missing.length > 0) {
      console.warn(
        `[azureDevOps] ⚠️  SDLC Agent mode is disabled — missing env vars: ${missing.join(", ")}. ` +
          "Set them in .env to enable Azure DevOps integration.",
      );
      return false;
    }

    console.log(
      `[azureDevOps] Configured: org=${org}, project=${project}, api-version=${apiVersion}`,
    );
    return true;
  },

  /** Fetch a work item by numeric ID. */
  fetchWorkItem,

  /**
   * Upload a UD file as an attachment and link it to the given work item.
   * Orchestrates uploadAttachment → linkAttachmentToWorkItem.
   * Returns the ADO attachment URL for display in the frontend.
   *
   * NOTE: If upload succeeds but linking fails, the orphaned attachment URL
   * is included in the thrown error message for manual recovery.
   */
  async attachUDToWorkItem(
    workItemId: number,
    filename: string,
    content: string,
    overrideProject?: string,
  ): Promise<{ attachmentUrl: string }> {
    console.log(
      `[azureDevOps] Uploading "${filename}" for Work Item #${workItemId}...`,
    );
    const { url: attachmentUrl } = await uploadAttachment(filename, content, overrideProject);
    console.log(`[azureDevOps] Attachment uploaded: ${attachmentUrl}`);

    try {
      await linkAttachmentToWorkItem(workItemId, attachmentUrl, filename, overrideProject);
    } catch (err: any) {
      // Rethrow with the attachment URL so callers can log/recover the orphaned upload
      throw new Error(
        `${err.message} (orphaned attachment URL: ${attachmentUrl})`,
      );
    }

    console.log(`[azureDevOps] Linked attachment to Work Item #${workItemId}`);
    return { attachmentUrl };
  },
};
