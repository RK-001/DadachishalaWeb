"use client";

import type { BuildDetail, BuildStage, STAGE_LABELS } from "@sdlc-copilot/shared";

const STAGE_ORDER: BuildStage[] = [
  "brd_intake",
  "brd_approved",
  "ud_draft",
  "ud_approved",
  "impl_plan",
  "plan_approved",
  "coding",
  "pr_created",
  "release_docs",
  "completed",
];

const STAGE_DISPLAY: Record<BuildStage, string> = {
  brd_intake: "BRD",
  brd_approved: "BRD ✓",
  ud_draft: "UD",
  ud_approved: "UD ✓",
  impl_plan: "Plan",
  plan_approved: "Plan ✓",
  coding: "Coding",
  pr_created: "PR",
  release_docs: "Release",
  completed: "Done ✅",
};

interface PipelineViewProps {
  build: BuildDetail;
  onApprove?: (buildId: string) => void;
  onReject?: (buildId: string) => void;
}

export function PipelineView({ build, onApprove, onReject }: PipelineViewProps) {
  const currentIdx = STAGE_ORDER.indexOf(build.currentStage);

  return (
    <div className="pipeline-view">
      {/* Header */}
      <div className="pipeline-header">
        <div className="pipeline-meta">
          <span className="pipeline-title">{build.title}</span>
          <span className={`pipeline-status pipeline-status--${build.status}`}>
            {build.status}
          </span>
        </div>
        {build.description && (
          <p className="pipeline-description">{build.description}</p>
        )}
      </div>

      {/* Stage bar */}
      <div className="pipeline-stages" role="list" aria-label="Pipeline stages">
        {STAGE_ORDER.map((stage, idx) => {
          const isCompleted = idx < currentIdx;
          const isCurrent = idx === currentIdx;
          const isPending = idx > currentIdx;

          return (
            <div
              key={stage}
              role="listitem"
              className={[
                "pipeline-stage",
                isCompleted ? "pipeline-stage--completed" : "",
                isCurrent ? "pipeline-stage--current" : "",
                isPending ? "pipeline-stage--pending" : "",
              ]
                .filter(Boolean)
                .join(" ")}
              title={stage}
            >
              <div className="pipeline-stage-dot">
                {isCompleted ? "✓" : isCurrent ? "●" : "○"}
              </div>
              <span className="pipeline-stage-label">
                {STAGE_DISPLAY[stage]}
              </span>
            </div>
          );
        })}
      </div>

      {/* Artifact list */}
      {(build.artifacts ?? []).length > 0 && (
        <div className="pipeline-artifacts">
          <p className="pipeline-artifacts-title">Artifacts</p>
          <ul className="pipeline-artifacts-list">
            {(build.artifacts ?? []).map((a) => (
              <li key={a.artifactId} className="pipeline-artifact-item">
                <span className="pipeline-artifact-stage">[{a.stage}]</span>
                <span className="pipeline-artifact-name">
                  {a.filename ?? `artifact-${a.artifactId}`}
                </span>
                {a.version && a.version > 1 && (
                  <span className="pipeline-artifact-version">v{a.version}</span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Approval actions — only show for active builds at actionable stages */}
      {build.status === "active" &&
        build.currentStage !== "completed" &&
        (onApprove || onReject) && (
          <div className="pipeline-actions">
            {onApprove && (
              <button
                className="pipeline-btn pipeline-btn--approve"
                onClick={() => onApprove(build.id)}
                title="Approve current stage and advance to next"
              >
                ✓ Approve &amp; Advance
              </button>
            )}
            {onReject && (
              <button
                className="pipeline-btn pipeline-btn--reject"
                onClick={() => onReject(build.id)}
                title="Reject and revert to prior draft stage"
              >
                ✗ Reject
              </button>
            )}
          </div>
        )}
    </div>
  );
}
