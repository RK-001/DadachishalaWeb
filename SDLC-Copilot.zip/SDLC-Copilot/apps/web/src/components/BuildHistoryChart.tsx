"use client";

import type { BuildDetail, BuildStage } from "@sdlc-copilot/shared";
import { STAGE_LABELS } from "@sdlc-copilot/shared";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";

interface Props {
  builds: BuildDetail[];
}

const STAGE_ORDER: BuildStage[] = [
  "brd_intake",
  "brd_approved",
  "ud_draft",
  "ud_approved",
  "impl_plan",
  "plan_approved",
  "coding",
  "pr_created",
  "release_docs",
  "completed",
];

const STATUS_COLORS: Record<string, string> = {
  active: "#3b82f6",
  paused: "#f59e0b",
  failed: "#ef4444",
  completed: "#22c55e",
};

interface ChartEntry {
  name: string;
  stageIndex: number;
  status: string;
  id: string;
}

/** Map a BuildDetail → chart entry */
function toBuildEntry(b: BuildDetail): ChartEntry {
  const idx = STAGE_ORDER.indexOf(b.currentStage);
  return {
    name: b.title.length > 20 ? b.title.slice(0, 18) + "…" : b.title,
    stageIndex: idx >= 0 ? idx + 1 : 0,
    status: b.status,
    id: b.id,
  };
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number; payload: ChartEntry }>;
  builds: BuildDetail[];
}

function CustomTooltip({ active, payload, builds }: CustomTooltipProps) {
  if (!active || !payload?.length) return null;
  const entry = payload[0].payload;
  const build = builds.find((b) => b.id === entry.id);
  if (!build) return null;

  return (
    <div className="build-chart-tooltip">
      <strong>{build.title}</strong>
      <div>Stage: {STAGE_LABELS[build.currentStage]}</div>
      <div>Status: {build.status}</div>
      <div>Approvals: {build.approvals.length}</div>
      <div>Created: {new Date(build.createdAt).toLocaleDateString()}</div>
    </div>
  );
}

export default function BuildHistoryChart({ builds }: Props) {
  if (builds.length === 0) {
    return (
      <div className="admin-empty-state admin-empty-state--padded">
        No builds to display in timeline.
      </div>
    );
  }

  const data = builds.slice(0, 20).map(toBuildEntry); // cap at 20 for readability

  const stageTickFormatter = (value: number) => {
    const stage = STAGE_ORDER[value - 1];
    return stage ? (STAGE_LABELS[stage] ?? stage) : "";
  };

  return (
    <div className="build-chart-container">
      <h2 className="admin-section-title">Build Stage Progress</h2>
      <p className="admin-page-subtitle">
        Bar height = pipeline progress (stages completed). Color = current status.
      </p>
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={data} margin={{ top: 10, right: 20, left: 10, bottom: 80 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="name"
            angle={-40}
            textAnchor="end"
            interval={0}
            tick={{ fontSize: 11 }}
          />
          <YAxis
            tickFormatter={stageTickFormatter}
            domain={[0, STAGE_ORDER.length]}
            ticks={STAGE_ORDER.map((_, i) => i + 1)}
            tick={{ fontSize: 10 }}
            width={110}
          />
          <Tooltip content={<CustomTooltip builds={builds} />} />
          <Legend verticalAlign="top" />
          <Bar dataKey="stageIndex" name="Pipeline Progress" radius={[4, 4, 0, 0]}>
            {data.map((entry) => (
              <Cell
                key={entry.id}
                fill={STATUS_COLORS[entry.status] ?? "#6366f1"}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>

      {/* Legend */}
      <div className="build-chart-legend">
        {Object.entries(STATUS_COLORS).map(([status, color]) => (
          <div key={status} className="build-chart-legend-item">
            <span className="build-chart-legend-dot" style={{ background: color }} />
            <span>{status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
