"use client";

/**
 * ObservabilityPanel — Phase 2.3
 *
 * Shows a live dashboard of per-skill health, metrics, tool call counts,
 * recent errors, and server uptime. Polls every 10 s using native fetch.
 *
 * No charting library needed — moderate detail level:
 *   • Health badges (green / yellow / gray dot + metadata)
 *   • Metrics table (request count, error count, avg latency, error rate %)
 *   • Tool call count list
 *   • Recent error list (last 50)
 *   • Server uptime
 *
 * Styling follows globals.css conventions — CSS variables, BEM naming.
 */

import { useEffect, useReducer, useCallback } from "react";
import type {
  ObserveHealthResponse,
  ObserveMetricsResponse,
  ObserveErrorsResponse,
  SkillHealthEntry,
} from "@sdlc-copilot/shared";

// ─── State ────────────────────────────────────────────────────────────────────

interface DashboardState {
  health: ObserveHealthResponse | null;
  metrics: ObserveMetricsResponse | null;
  errors: ObserveErrorsResponse | null;
  fetchError: string | null;
  lastRefreshed: string | null;
}

type DashboardAction =
  | { type: "SET_DATA"; health: ObserveHealthResponse; metrics: ObserveMetricsResponse; errors: ObserveErrorsResponse }
  | { type: "SET_ERROR"; error: string };

function reducer(state: DashboardState, action: DashboardAction): DashboardState {
  switch (action.type) {
    case "SET_DATA":
      return {
        health: action.health,
        metrics: action.metrics,
        errors: action.errors,
        fetchError: null,
        lastRefreshed: new Date().toLocaleTimeString(),
      };
    case "SET_ERROR":
      return { ...state, fetchError: action.error };
    default:
      return state;
  }
}

const INITIAL_STATE: DashboardState = {
  health: null,
  metrics: null,
  errors: null,
  fetchError: null,
  lastRefreshed: null,
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatUptime(secs: number): string {
  if (secs < 60) return `${secs}s`;
  if (secs < 3600) return `${Math.floor(secs / 60)}m ${secs % 60}s`;
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  return `${h}h ${m}m`;
}

function errorRate(errorCount: number, requestCount: number): string {
  if (requestCount === 0) return "—";
  return ((errorCount / requestCount) * 100).toFixed(1) + "%";
}

function formatLatency(ms: number): string {
  if (ms === 0) return "—";
  return ms < 1000 ? `${Math.round(ms)}ms` : `${(ms / 1000).toFixed(1)}s`;
}

function healthDot(health: SkillHealthEntry["health"]): string {
  switch (health) {
    case "healthy":  return "●";
    case "degraded": return "●";
    default:         return "●";
  }
}

function healthClass(health: SkillHealthEntry["health"]): string {
  switch (health) {
    case "healthy":  return "health-dot--healthy";
    case "degraded": return "health-dot--degraded";
    default:         return "health-dot--unknown";
  }
}

// ─── Component ────────────────────────────────────────────────────────────────

export function ObservabilityPanel() {
  const [state, dispatch] = useReducer(reducer, INITIAL_STATE);

  const fetchAll = useCallback(async () => {
    try {
      const [healthRes, metricsRes, errorsRes] = await Promise.all([
        fetch("/api/proxy/observe/health"),
        fetch("/api/proxy/observe/metrics"),
        fetch("/api/proxy/observe/errors"),
      ]);

      if (!healthRes.ok || !metricsRes.ok || !errorsRes.ok) {
        const failed = [healthRes, metricsRes, errorsRes].find((r) => !r.ok);
        dispatch({ type: "SET_ERROR", error: `API error: ${failed?.status} ${failed?.statusText}` });
        return;
      }

      const [health, metrics, errors] = await Promise.all([
        healthRes.json() as Promise<ObserveHealthResponse>,
        metricsRes.json() as Promise<ObserveMetricsResponse>,
        errorsRes.json() as Promise<ObserveErrorsResponse>,
      ]);

      dispatch({ type: "SET_DATA", health, metrics, errors });
    } catch (err) {
      dispatch({ type: "SET_ERROR", error: err instanceof Error ? err.message : "Fetch failed" });
    }
  }, []);

  useEffect(() => {
    fetchAll();
    const interval = setInterval(fetchAll, 10_000);
    return () => clearInterval(interval);
  }, [fetchAll]);

  if (state.fetchError && !state.health) {
    return (
      <div className="observe-container">
        <div className="observe-header">
          <h1 className="observe-title">Observability</h1>
        </div>
        <div className="observe-error-banner">
          ⚠ Could not reach observe API: {state.fetchError}
        </div>
      </div>
    );
  }

  const { health, metrics, errors } = state;

  return (
    <div className="observe-container">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="observe-header">
        <div className="observe-header-left">
          <h1 className="observe-title">🔭 Observability</h1>
          {metrics && (
            <span className="observe-uptime">
              Uptime: <strong>{formatUptime(metrics.uptimeSecs)}</strong>
            </span>
          )}
        </div>
        <div className="observe-header-right">
          {state.lastRefreshed && (
            <span className="observe-refresh-time">
              Last refreshed: {state.lastRefreshed}
            </span>
          )}
          {state.fetchError && (
            <span className="observe-fetch-warn">⚠ {state.fetchError}</span>
          )}
        </div>
      </div>

      {/* ── Skill Health Badges ─────────────────────────────── */}
      <section className="observe-section">
        <h2 className="observe-section-title">Skill Health</h2>
        {!health ? (
          <p className="observe-loading">Loading…</p>
        ) : (
          <div className="health-grid">
            {health.skills.map((skill) => (
              <div key={skill.mode} className={`health-card health-card--${skill.health}`}>
                <div className="health-card-top">
                  <span className={`health-dot ${healthClass(skill.health)}`}>
                    {healthDot(skill.health)}
                  </span>
                  <span className="health-mode">{skill.displayName}</span>
                  <span className={`health-badge health-badge--${skill.health}`}>
                    {skill.health}
                  </span>
                </div>
                <div className="health-card-meta">
                  <span className="health-meta-item">
                    Mode: <code>{skill.mode}</code>
                  </span>
                  {skill.fallbackMode && (
                    <span className="health-meta-item">
                      Fallback: <code>{skill.fallbackMode}</code>
                    </span>
                  )}
                  {metrics?.skills[skill.mode]?.lastErrorAt && (
                    <span className="health-meta-item health-meta-error">
                      Last error: {new Date(metrics.skills[skill.mode].lastErrorAt!).toLocaleTimeString()}
                    </span>
                  )}
                </div>
              </div>
            ))}
            {health.skills.length === 0 && (
              <p className="observe-empty">No skills registered yet.</p>
            )}
          </div>
        )}
      </section>

      {/* ── Metrics Table ─────────────────────────────────────── */}
      <section className="observe-section">
        <h2 className="observe-section-title">Request Metrics</h2>
        {!metrics ? (
          <p className="observe-loading">Loading…</p>
        ) : Object.keys(metrics.skills).length === 0 ? (
          <p className="observe-empty">No requests recorded yet.</p>
        ) : (
          <div className="metrics-table-wrapper">
            <table className="metrics-table">
              <thead>
                <tr>
                  <th>Skill</th>
                  <th>Requests</th>
                  <th>Errors</th>
                  <th>Avg Latency</th>
                  <th>Error Rate</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(metrics.skills).map(([mode, s]) => (
                  <tr key={mode}>
                    <td><code>{mode}</code></td>
                    <td>{s.requestCount}</td>
                    <td className={s.errorCount > 0 ? "metrics-cell--error" : ""}>{s.errorCount}</td>
                    <td>{formatLatency(s.avgLatencyMs)}</td>
                    <td className={parseFloat(errorRate(s.errorCount, s.requestCount)) > 10 ? "metrics-cell--warn" : ""}>
                      {errorRate(s.errorCount, s.requestCount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* ── Tool Call Counts ───────────────────────────────────── */}
      {metrics && Object.keys(metrics.toolCallCount).length > 0 && (
        <section className="observe-section">
          <h2 className="observe-section-title">Tool Call Counts</h2>
          <div className="tool-count-grid">
            {Object.entries(metrics.toolCallCount)
              .sort(([, a], [, b]) => b - a)
              .map(([tool, count]) => (
                <div key={tool} className="tool-count-item">
                  <span className="tool-count-name">{tool}</span>
                  <span className="tool-count-value">{count}</span>
                </div>
              ))}
          </div>
        </section>
      )}

      {/* ── Recent Errors ─────────────────────────────────────── */}
      <section className="observe-section">
        <h2 className="observe-section-title">
          Recent Errors{" "}
          {errors && errors.count > 0 && (
            <span className="observe-error-count">{errors.count}</span>
          )}
        </h2>
        {!errors ? (
          <p className="observe-loading">Loading…</p>
        ) : errors.errors.length === 0 ? (
          <p className="observe-empty observe-empty--success">✓ No recent errors</p>
        ) : (
          <div className="error-list">
            {errors.errors.map((entry, idx) => (
              <div key={idx} className="error-list-item">
                <div className="error-list-meta">
                  <span className="error-skill-badge">{entry.skill}</span>
                  <span className="error-timestamp">
                    {new Date(entry.timestamp).toLocaleTimeString()}
                  </span>
                  {entry.requestId && (
                    <span className="error-request-id" title={entry.requestId}>
                      req: {entry.requestId.slice(0, 8)}…
                    </span>
                  )}
                </div>
                <p className="error-message">{entry.message}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
