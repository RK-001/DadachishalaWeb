"use client";

import { useEffect, useState } from "react";
import type { ObserveHealthResponse, ObserveMetricsResponse, ObserveCircuitBreakersResponse } from "@sdlc-copilot/shared";

interface QuickStat {
  label: string;
  value: string | number;
  status?: "ok" | "warn" | "error";
}

const PROXY = "/api/proxy";

export default function AdminDashboard() {
  const [health, setHealth] = useState<ObserveHealthResponse | null>(null);
  const [metrics, setMetrics] = useState<ObserveMetricsResponse | null>(null);
  const [circuits, setCircuits] = useState<ObserveCircuitBreakersResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const [h, m, c] = await Promise.all([
          fetch(`${PROXY}/observe/health`).then((r) => r.json()),
          fetch(`${PROXY}/observe/metrics`).then((r) => r.json()),
          fetch(`${PROXY}/observe/circuit-breakers`).then((r) => r.json()),
        ]);
        setHealth(h as ObserveHealthResponse);
        setMetrics(m as ObserveMetricsResponse);
        setCircuits(c as ObserveCircuitBreakersResponse);
      } catch (e: any) {
        setError(e.message);
      }
    };
    load();
    const interval = setInterval(load, 15_000);
    return () => clearInterval(interval);
  }, []);

  const totalRequests = metrics
    ? Object.values(metrics.skills).reduce((s, v) => s + v.requestCount, 0)
    : 0;
  const totalErrors = metrics
    ? Object.values(metrics.skills).reduce((s, v) => s + v.errorCount, 0)
    : 0;
  const degradedSkills = health ? health.skills.filter((s) => s.health === "degraded").length : 0;
  const openCircuits = circuits
    ? Object.values(circuits.circuitBreakers).filter((c) => c.state === "open").length
    : 0;

  const stats: QuickStat[] = [
    { label: "Uptime", value: metrics ? formatUptime(metrics.uptimeSecs) : "—" },
    { label: "Total Requests", value: totalRequests },
    { label: "Total Errors", value: totalErrors, status: totalErrors > 0 ? "warn" : "ok" },
    { label: "Degraded Skills", value: degradedSkills, status: degradedSkills > 0 ? "error" : "ok" },
    { label: "Open Circuits", value: openCircuits, status: openCircuits > 0 ? "error" : "ok" },
    {
      label: "Skills Online",
      value: health ? `${health.skills.filter((s) => s.health === "healthy").length} / ${health.skills.length}` : "—",
    },
  ];

  return (
    <div className="admin-page">
      <div className="admin-page-header">
        <h1 className="admin-page-title">Admin Dashboard</h1>
        <p className="admin-page-subtitle">System health overview — auto-refreshes every 15s</p>
      </div>

      {error && <div className="admin-error-banner">⚠ Could not load data: {error}</div>}

      {/* Quick stats */}
      <div className="admin-stats-grid">
        {stats.map((s) => (
          <div key={s.label} className={`admin-stat-card ${s.status ? `admin-stat-card--${s.status}` : ""}`}>
            <span className="admin-stat-label">{s.label}</span>
            <span className="admin-stat-value">{s.value}</span>
          </div>
        ))}
      </div>

      {/* Skill health grid */}
      {health && (
        <section className="admin-section">
          <h2 className="admin-section-title">Skill Health</h2>
          <div className="admin-health-grid">
            {health.skills.map((skill) => (
              <div key={skill.mode} className={`admin-health-card admin-health-card--${skill.health}`}>
                <div className="admin-health-card-top">
                  <span className={`admin-health-dot admin-health-dot--${skill.health}`}>●</span>
                  <span className="admin-health-mode">{skill.displayName}</span>
                  <span className={`admin-health-badge admin-health-badge--${skill.health}`}>
                    {skill.health}
                  </span>
                </div>
                {metrics?.skills[skill.mode] && (
                  <div className="admin-health-meta">
                    <span>{metrics.skills[skill.mode].requestCount} reqs</span>
                    <span>{metrics.skills[skill.mode].errorCount} err</span>
                    <span>{metrics.skills[skill.mode].avgLatencyMs}ms avg</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Circuit breakers */}
      {circuits && Object.keys(circuits.circuitBreakers).length > 0 && (
        <section className="admin-section">
          <h2 className="admin-section-title">Circuit Breakers</h2>
          <div className="admin-circuit-grid">
            {Object.entries(circuits.circuitBreakers).map(([svc, state]) => (
              <div key={svc} className={`admin-circuit-card admin-circuit-card--${state.state}`}>
                <strong>{svc}</strong>
                <span className={`admin-circuit-state admin-circuit-state--${state.state}`}>
                  {state.state.toUpperCase()}
                </span>
                <span>{state.failures} failures</span>
                {state.lastFailureAt && (
                  <span className="admin-circuit-last">
                    Last: {new Date(state.lastFailureAt).toLocaleTimeString()}
                  </span>
                )}
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function formatUptime(secs: number): string {
  if (secs < 60) return `${secs}s`;
  if (secs < 3600) return `${Math.floor(secs / 60)}m`;
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  return `${h}h ${m}m`;
}
