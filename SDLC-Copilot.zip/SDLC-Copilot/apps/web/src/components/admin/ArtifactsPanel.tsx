"use client";

import { useCallback, useEffect, useState } from "react";
import type { Artifact } from "@sdlc-copilot/shared";

const PROXY = "/api/proxy";

export default function ArtifactsPanel() {
  const [artifacts, setArtifacts] = useState<Omit<Artifact, "content">[]>([]);
  const [selected, setSelected] = useState<Artifact | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filterType, setFilterType] = useState("");
  const [editing, setEditing] = useState(false);
  const [editContent, setEditContent] = useState("");
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const url = filterType
        ? `${PROXY}/admin/artifacts?limit=100&type=${encodeURIComponent(filterType)}`
        : `${PROXY}/admin/artifacts?limit=100`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Failed (${res.status})`);
      const data = await res.json() as { artifacts: Omit<Artifact, "content">[] };
      setArtifacts(data.artifacts);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [filterType]);

  useEffect(() => { load(); }, [load]);

  const loadDetail = async (id: number) => {
    try {
      const res = await fetch(`${PROXY}/admin/artifacts/${id}`);
      if (!res.ok) throw new Error(`Failed (${res.status})`);
      const data = await res.json() as { artifact: Artifact };
      setSelected(data.artifact);
      setEditContent(data.artifact.content);
      setEditing(false);
    } catch (e: any) {
      setError(e.message);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback for older browsers
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const exportPDF = async (artifact: Artifact) => {
    // Dynamic import to avoid SSR issues
    const { jsPDF } = await import("jspdf");
    const doc = new jsPDF({ orientation: "p", unit: "mm", format: "a4" });

    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 15;
    const maxWidth = pageWidth - margin * 2;

    // Title
    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text(artifact.filename, margin, 20);

    // Metadata
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100);
    doc.text(
      `Type: ${artifact.artifactType}  |  Version: ${artifact.version}  |  Created: ${new Date(artifact.createdAt).toLocaleDateString()}`,
      margin,
      28
    );

    doc.setTextColor(0);
    doc.setFontSize(11);

    // Content — split into lines to handle word wrap + pagination
    const lines = doc.splitTextToSize(artifact.content, maxWidth) as string[];
    let y = 38;
    const lineHeight = 5.5;
    const pageHeight = doc.internal.pageSize.getHeight() - margin;

    for (const line of lines) {
      if (y + lineHeight > pageHeight) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += lineHeight;
    }

    doc.save(`${artifact.filename.replace(/\.md$/, "")}.pdf`);
  };

  const TYPES = ["ud", "hld", "test", "release-notes", "brd", "impl-plan"];

  return (
    <div className="admin-page">
      <div className="admin-page-header">
        <h1 className="admin-page-title">📦 Artifacts</h1>
      </div>

      <div className="admin-toolbar">
        <label className="admin-toolbar-label">
          Type:
          <select
            className="admin-select"
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
          >
            <option value="">All types</option>
            {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </label>
        <button className="admin-btn admin-btn--secondary" onClick={load}>🔄 Refresh</button>
      </div>

      {error && <div className="admin-error-banner">⚠ {error}</div>}

      <div className="admin-artifacts-layout">
        {/* Artifact list */}
        <div className="admin-artifacts-list">
          {loading ? (
            <div className="admin-loading">Loading…</div>
          ) : artifacts.length === 0 ? (
            <div className="admin-empty-state">No artifacts found.</div>
          ) : (
            artifacts.map((a) => (
              <div
                key={a.id}
                className={`admin-artifact-item ${selected?.id === a.id ? "admin-artifact-item--selected" : ""}`}
                onClick={() => loadDetail(a.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === "Enter" && loadDetail(a.id)}
              >
                <span className="admin-artifact-name">{a.filename}</span>
                <span className={`admin-artifact-type admin-artifact-type--${a.artifactType}`}>
                  {a.artifactType}
                </span>
                <span className="admin-artifact-meta">v{a.version}</span>
              </div>
            ))
          )}
        </div>

        {/* Artifact detail + editor */}
        {selected && (
          <div className="admin-artifact-detail">
            <div className="admin-artifact-detail-header">
              <div>
                <h2 className="admin-artifact-detail-name">{selected.filename}</h2>
                <span className="admin-artifact-detail-meta">
                  v{selected.version} · {selected.artifactType} ·{" "}
                  {new Date(selected.createdAt).toLocaleDateString()}
                </span>
              </div>
              <div className="admin-artifact-detail-actions">
                <button
                  className="admin-btn admin-btn--sm admin-btn--secondary"
                  onClick={() => copyToClipboard(selected.content)}
                >
                  {copied ? "✓ Copied!" : "📋 Copy"}
                </button>
                <button
                  className="admin-btn admin-btn--sm admin-btn--secondary"
                  onClick={() => exportPDF(selected)}
                >
                  🖨 PDF
                </button>
                <a
                  className="admin-btn admin-btn--sm admin-btn--secondary"
                  href={`${PROXY}/admin/artifacts/${selected.id}/download`}
                  download={selected.filename}
                >
                  ⬇ Download
                </a>
                <button
                  className={`admin-btn admin-btn--sm ${editing ? "admin-btn--warning" : "admin-btn--secondary"}`}
                  onClick={() => setEditing((v) => !v)}
                >
                  {editing ? "👁 Preview" : "✏️ Edit"}
                </button>
              </div>
            </div>

            {editing ? (
              <textarea
                className="admin-template-textarea"
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                rows={30}
              />
            ) : (
              <pre className="admin-artifact-content">{selected.content}</pre>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
