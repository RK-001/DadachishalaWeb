"use client";

import { useCallback, useEffect, useState } from "react";
import dynamic from "next/dynamic";
import type { BuildDetail } from "@sdlc-copilot/shared";
import { STAGE_LABELS } from "@sdlc-copilot/shared";

// Lazy-load recharts-based chart to keep the initial bundle lean (ssr: false
// prevents recharts from being included in the server-side HTML render).
const BuildHistoryChart = dynamic(() => import("../BuildHistoryChart"), {
  ssr: false,
  loading: () => <div style={{ height: 260, display: "flex", alignItems: "center", justifyContent: "center", color: "#999" }}>Loading chart…</div>,
});

const PROXY = "/api/proxy";
const PROJECT_ID = typeof window !== "undefined"
  ? (process.env.NEXT_PUBLIC_PROJECT_ID || "default")
  : "default";

export default function BuildsManager() {
  const [builds, setBuilds] = useState<BuildDetail[]>([]);
  const [selected, setSelected] = useState<BuildDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<"list" | "chart">("list");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`${PROXY}/builds?projectId=${encodeURIComponent(PROJECT_ID)}`);
      if (!res.ok) throw new Error(`Failed (${res.status})`);
      const data = await res.json() as { builds: BuildDetail[] };
      setBuilds(data.builds);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const loadDetail = async (buildId: string) => {
    try {
      const res = await fetch(`${PROXY}/builds/${encodeURIComponent(buildId)}`);
      if (!res.ok) throw new Error(`Failed (${res.status})`);
      const data = await res.json() as { build: BuildDetail };
      setSelected(data.build);
    } catch (e: any) {
      setError(e.message);
    }
  };

  const archive = async (buildId: string) => {
    if (!confirm("Archive this build?")) return;
    try {
      const res = await fetch(`${PROXY}/builds/${buildId}`, { method: "DELETE" });
      if (!res.ok) throw new Error(`Failed (${res.status})`);
      setSelected(null);
      load();
    } catch (e: any) {
      setError(e.message);
    }
  };

  return (
    <div className="admin-page">
      <div className="admin-page-header">
        <h1 className="admin-page-title">🏗️ Builds</h1>
        <div className="admin-toolbar-right">
          <button
            className={`admin-btn ${view === "list" ? "admin-btn--primary" : "admin-btn--secondary"}`}
            onClick={() => setView("list")}
          >
            List
          </button>
          <button
            className={`admin-btn ${view === "chart" ? "admin-btn--primary" : "admin-btn--secondary"}`}
            onClick={() => setView("chart")}
          >
            Timeline
          </button>
          <button className="admin-btn admin-btn--secondary" onClick={load}>🔄</button>
        </div>
      </div>

      {error && <div className="admin-error-banner">⚠ {error}</div>}

      {loading ? (
        <div className="admin-loading">Loading builds…</div>
      ) : view === "chart" ? (
        <BuildHistoryChart builds={builds} />
      ) : (
        <div className="admin-builds-layout">
          {/* Build list */}
          <div className="admin-builds-list">
            {builds.length === 0 ? (
              <div className="admin-empty-state">No builds yet.</div>
            ) : (
              builds.map((b) => (
                <div
                  key={b.id}
                  className={`admin-build-item ${selected?.id === b.id ? "admin-build-item--selected" : ""}`}
                  onClick={() => loadDetail(b.id)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === "Enter" && loadDetail(b.id)}
                >
                  <div className="admin-build-item-header">
                    <span className="admin-build-title">{b.title}</span>
                    <span className={`admin-build-status admin-build-status--${b.status}`}>
                      {b.status}
                    </span>
                  </div>
                  <div className="admin-build-stage">
                    {STAGE_LABELS[b.currentStage]}
                  </div>
                  <div className="admin-build-date">
                    {new Date(b.createdAt).toLocaleDateString()}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Build detail */}
          {selected && (
            <div className="admin-build-detail">
              <div className="admin-build-detail-header">
                <h2>{selected.title}</h2>
                <button
                  className="admin-btn admin-btn--sm admin-btn--danger"
                  onClick={() => archive(selected.id)}
                >
                  Archive
                </button>
              </div>
              {selected.description && (
                <p className="admin-build-desc">{selected.description}</p>
              )}

              {/* Stage progress */}
              <div className="admin-stage-progress">
                {Object.entries(STAGE_LABELS).map(([stage, label]) => (
                  <div
                    key={stage}
                    className={`admin-stage-step ${
                      stage === selected.currentStage
                        ? "admin-stage-step--current"
                        : selected.approvals.some((a) => a.stage === stage && a.decision === "approved")
                        ? "admin-stage-step--done"
                        : ""
                    }`}
                  >
                    <span className="admin-stage-dot" />
                    <span className="admin-stage-label">{label}</span>
                  </div>
                ))}
              </div>

              {/* Approvals */}
              {selected.approvals.length > 0 && (
                <div className="admin-approvals">
                  <h3>Approvals</h3>
                  <table className="admin-table">
                    <thead>
                      <tr><th>Stage</th><th>Decision</th><th>By</th><th>Date</th></tr>
                    </thead>
                    <tbody>
                      {selected.approvals.map((a) => (
                        <tr key={a.id}>
                          <td>{STAGE_LABELS[a.stage as keyof typeof STAGE_LABELS] ?? a.stage}</td>
                          <td>
                            <span className={`admin-decision-badge admin-decision-badge--${a.decision}`}>
                              {a.decision}
                            </span>
                          </td>
                          <td>{a.approvedBy}</td>
                          <td>{new Date(a.approvedAt).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Artifacts */}
              {selected.artifacts.length > 0 && (
                <div className="admin-build-artifacts">
                  <h3>Artifacts</h3>
                  {selected.artifacts.map((a) => (
                    <div key={a.artifactId} className="admin-artifact-link">
                      <span className="admin-artifact-stage">{a.stage}</span>
                      {a.filename && (
                        <a
                          href={`${PROXY}/admin/artifacts/${a.artifactId}/download`}
                          className="admin-link"
                          download={a.filename}
                        >
                          {a.filename}
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
