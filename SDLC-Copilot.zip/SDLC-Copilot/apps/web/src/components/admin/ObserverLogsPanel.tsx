"use client";

import { useCallback, useEffect, useState } from "react";
import type { ObserverLogEntry } from "@sdlc-copilot/shared";

const PROXY = "/api/proxy";

const CONFIDENCE_COLOR = (c: number) => {
  if (c >= 0.85) return "#22c55e";
  if (c >= 0.5) return "#f59e0b";
  return "#ef4444";
};

export default function ObserverLogsPanel() {
  const [logs, setLogs] = useState<ObserverLogEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [limit, setLimit] = useState(50);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${PROXY}/observe/observer-logs?limit=${limit}`);
      if (!res.ok) throw new Error(`Failed to load (${res.status})`);
      const data = await res.json() as { logs: ObserverLogEntry[] };
      setLogs(data.logs);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [limit]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="admin-page">
      <div className="admin-page-header">
        <h1 className="admin-page-title">🔭 Observer Logs</h1>
        <p className="admin-page-subtitle">
          Self-heal audit trail. The Observer Agent runs when a skill degrades and attempts
          autonomous recovery. Confidence ≥ 0.85 triggers automatic action.
        </p>
      </div>

      <div className="admin-toolbar">
        <label className="admin-toolbar-label">
          Show last:
          <select
            className="admin-select"
            value={limit}
            onChange={(e) => setLimit(Number(e.target.value))}
          >
            {[25, 50, 100, 200].map((n) => (
              <option key={n} value={n}>{n} entries</option>
            ))}
          </select>
        </label>
        <button className="admin-btn admin-btn--secondary" onClick={load}>
          🔄 Refresh
        </button>
      </div>

      {error && <div className="admin-error-banner">⚠ {error}</div>}

      {loading ? (
        <div className="admin-loading">Loading observer logs…</div>
      ) : logs.length === 0 ? (
        <div className="admin-empty-state admin-empty-state--padded">
          <p>No observer events yet.</p>
          <p className="admin-empty-hint">
            Observer triggers when a skill's error rate exceeds 50% with ≥3 errors.
            Configure OBSERVER_MODEL in .env to use a specific LLM model.
          </p>
        </div>
      ) : (
        <div className="admin-log-list">
          {logs.map((log) => (
            <div
              key={log.id}
              className="admin-log-item"
              onClick={() => setExpandedId(expandedId === log.id ? null : log.id)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === "Enter" && setExpandedId(expandedId === log.id ? null : log.id)}
            >
              <div className="admin-log-item-header">
                <span className="admin-log-skill">{log.skill}</span>
                <span className="admin-log-action">{log.action}</span>
                <span
                  className="admin-log-confidence"
                  style={{ color: CONFIDENCE_COLOR(log.confidence) }}
                >
                  {(log.confidence * 100).toFixed(0)}% conf.
                </span>
                <span className="admin-log-time">
                  {new Date(log.created_at).toLocaleString()}
                </span>
                <span className="admin-log-expand">{expandedId === log.id ? "▲" : "▼"}</span>
              </div>

              {expandedId === log.id && (
                <div className="admin-log-item-detail">
                  <div className="admin-log-detail-row">
                    <span className="admin-log-detail-label">Diagnosis:</span>
                    <span>{log.diagnosis}</span>
                  </div>
                  <div className="admin-log-detail-row">
                    <span className="admin-log-detail-label">Outcome:</span>
                    <span>{log.outcome}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
