"use client";

import { useCallback, useEffect, useState } from "react";
import type { ProjectConfig } from "@sdlc-copilot/shared";

const PROXY = "/api/proxy";

const EMPTY_FORM: Omit<ProjectConfig, "id" | "enabledModes"> & { id: string; enabledModes: string } = {
  id: "",
  name: "",
  enabledModes: "chat,ud,sdlc",
  kbRepoOwner: "",
  kbRepoName: "",
  adoOrg: "",
  adoProject: "",
};

export default function ProjectsManager() {
  const [projects, setProjects] = useState<ProjectConfig[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editing, setEditing] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`${PROXY}/admin/projects`);
      if (!res.ok) throw new Error(`Failed (${res.status})`);
      const data = await res.json() as { projects: ProjectConfig[] };
      setProjects(data.projects);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openNew = () => {
    setForm(EMPTY_FORM);
    setEditing(null);
    setShowForm(true);
  };

  const openEdit = (p: ProjectConfig) => {
    setForm({
      id: p.id,
      name: p.name,
      enabledModes: p.enabledModes.join(","),
      kbRepoOwner: p.kbRepoOwner ?? "",
      kbRepoName: p.kbRepoName ?? "",
      adoOrg: p.adoOrg ?? "",
      adoProject: p.adoProject ?? "",
    });
    setEditing(p.id);
    setShowForm(true);
  };

  const save = async () => {
    setError(null);
    try {
      const body = {
        ...form,
        enabledModes: form.enabledModes.split(",").map((m) => m.trim()).filter(Boolean),
        kbRepoOwner: form.kbRepoOwner || null,
        kbRepoName: form.kbRepoName || null,
        adoOrg: form.adoOrg || null,
        adoProject: form.adoProject || null,
      };

      const res = editing
        ? await fetch(`${PROXY}/admin/projects/${editing}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          })
        : await fetch(`${PROXY}/admin/projects`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          });

      if (!res.ok) {
        const d = await res.json() as { error?: string };
        throw new Error(d.error ?? "Save failed");
      }
      setSuccess(editing ? "Project updated!" : "Project created!");
      setShowForm(false);
      load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setTimeout(() => setSuccess(null), 3000);
    }
  };

  const del = async (id: string) => {
    if (!confirm(`Delete project "${id}"? This cannot be undone.`)) return;
    try {
      const res = await fetch(`${PROXY}/admin/projects/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const d = await res.json() as { error?: string };
        throw new Error(d.error ?? "Delete failed");
      }
      setSuccess("Deleted.");
      load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setTimeout(() => setSuccess(null), 3000);
    }
  };

  const field = (key: keyof typeof form) => ({
    value: form[key] as string,
    onChange: (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value })),
  });

  return (
    <div className="admin-page">
      <div className="admin-page-header">
        <h1 className="admin-page-title">📁 Projects</h1>
        <button className="admin-btn admin-btn--primary" onClick={openNew}>
          + New Project
        </button>
      </div>

      {error && <div className="admin-error-banner">⚠ {error}</div>}
      {success && <div className="admin-success-banner">✓ {success}</div>}

      {showForm && (
        <div className="admin-form-panel">
          <h2 className="admin-form-title">{editing ? `Edit: ${editing}` : "New Project"}</h2>
          <div className="admin-form-grid">
            {!editing && (
              <div className="admin-form-field">
                <label>Project ID *</label>
                <input className="admin-input" placeholder="e.g. my-project" {...field("id")} />
              </div>
            )}
            <div className="admin-form-field">
              <label>Name *</label>
              <input className="admin-input" placeholder="Display name" {...field("name")} />
            </div>
            <div className="admin-form-field">
              <label>Enabled Modes (comma-separated)</label>
              <input className="admin-input" placeholder="chat,ud,sdlc" {...field("enabledModes")} />
            </div>
            <div className="admin-form-field">
              <label>KB Repo Owner</label>
              <input className="admin-input" placeholder="github-org" {...field("kbRepoOwner")} />
            </div>
            <div className="admin-form-field">
              <label>KB Repo Name</label>
              <input className="admin-input" placeholder="knowledge-base" {...field("kbRepoName")} />
            </div>
            <div className="admin-form-field">
              <label>ADO Organization</label>
              <input className="admin-input" placeholder="my-org" {...field("adoOrg")} />
            </div>
            <div className="admin-form-field">
              <label>ADO Project</label>
              <input className="admin-input" placeholder="MyProject" {...field("adoProject")} />
            </div>
          </div>
          <div className="admin-form-actions">
            <button className="admin-btn admin-btn--primary" onClick={save}>
              💾 Save
            </button>
            <button className="admin-btn admin-btn--secondary" onClick={() => setShowForm(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="admin-loading">Loading projects…</div>
      ) : (
        <div className="admin-project-list">
          {projects.map((p) => (
            <div key={p.id} className="admin-project-card">
              <div className="admin-project-card-header">
                <span className="admin-project-id">{p.id}</span>
                <span className="admin-project-name">{p.name}</span>
                {p.id === "default" && (
                  <span className="admin-default-badge">default</span>
                )}
              </div>
              <div className="admin-project-meta">
                <span>Modes: {p.enabledModes.join(", ")}</span>
                {p.kbRepoOwner && <span>KB: {p.kbRepoOwner}/{p.kbRepoName}</span>}
                {p.adoOrg && <span>ADO: {p.adoOrg}/{p.adoProject}</span>}
              </div>
              <div className="admin-project-actions">
                <button className="admin-btn admin-btn--sm" onClick={() => openEdit(p)}>
                  Edit
                </button>
                {p.id !== "default" && (
                  <button
                    className="admin-btn admin-btn--sm admin-btn--danger"
                    onClick={() => del(p.id)}
                  >
                    Delete
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
