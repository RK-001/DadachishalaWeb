"use client";

import { useCallback, useEffect, useState } from "react";
import type { PromptTemplate, PromptMode } from "@sdlc-copilot/shared";

const PROXY = "/api/proxy";
const MODES: PromptMode[] = ["chat", "ud", "sdlc", "brd-analyst", "impl-plan", "coding", "release"];

export default function PromptTemplatesEditor() {
  const [projectId, setProjectId] = useState("default");
  const [templates, setTemplates] = useState<PromptTemplate[]>([]);
  const [selected, setSelected] = useState<PromptTemplate | null>(null);
  const [editContent, setEditContent] = useState("");
  const [editMode, setEditMode] = useState<PromptMode>("sdlc");
  const [showEditor, setShowEditor] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${PROXY}/admin/prompt-templates?projectId=${encodeURIComponent(projectId)}`);
      if (!res.ok) throw new Error(`Failed to load (${res.status})`);
      const data = await res.json() as { templates: PromptTemplate[] };
      setTemplates(data.templates);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => { load(); }, [load]);

  const openNew = (mode: PromptMode) => {
    setEditMode(mode);
    setEditContent("");
    setSelected(null);
    setShowEditor(true);
    setPreviewMode(false);
  };

  const openEdit = (t: PromptTemplate) => {
    setEditMode(t.mode as PromptMode);
    setEditContent(t.content);
    setSelected(t);
    setShowEditor(true);
    setPreviewMode(false);
  };

  const save = async () => {
    if (!editContent.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`${PROXY}/admin/prompt-templates`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId, mode: editMode, content: editContent }),
      });
      if (!res.ok) {
        const d = await res.json() as { error?: string };
        throw new Error(d.error ?? `Save failed (${res.status})`);
      }
      setSuccess("Template saved and activated!");
      setShowEditor(false);
      setSelected(null);
      load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
      setTimeout(() => setSuccess(null), 3000);
    }
  };

  const activate = async (id: number) => {
    try {
      const res = await fetch(`${PROXY}/admin/prompt-templates/${id}/activate`, { method: "PUT" });
      if (!res.ok) throw new Error(`Activate failed (${res.status})`);
      setSuccess("Template activated!");
      load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setTimeout(() => setSuccess(null), 3000);
    }
  };

  const remove = async (id: number) => {
    if (!confirm("Delete this template version?")) return;
    try {
      const res = await fetch(`${PROXY}/admin/prompt-templates/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const d = await res.json() as { error?: string };
        throw new Error(d.error ?? "Delete failed");
      }
      setSuccess("Deleted.");
      load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setTimeout(() => setSuccess(null), 3000);
    }
  };

  // Group templates by mode
  const grouped = MODES.reduce<Record<string, PromptTemplate[]>>((acc, mode) => {
    acc[mode] = templates.filter((t) => t.mode === mode);
    return acc;
  }, {});

  return (
    <div className="admin-page">
      <div className="admin-page-header">
        <h1 className="admin-page-title">📝 Prompt Templates</h1>
        <p className="admin-page-subtitle">
          Override default system prompts per project and mode. Active template is used at runtime;
          others are version history.
        </p>
      </div>

      <div className="admin-toolbar">
        <label className="admin-toolbar-label">
          Project:
          <input
            className="admin-input admin-input--sm"
            value={projectId}
            onChange={(e) => setProjectId(e.target.value)}
            placeholder="Project ID"
          />
        </label>
        <button className="admin-btn admin-btn--secondary" onClick={load}>
          🔄 Refresh
        </button>
      </div>

      {error && <div className="admin-error-banner">⚠ {error}</div>}
      {success && <div className="admin-success-banner">✓ {success}</div>}

      {/* Template editor panel */}
      {showEditor && (
        <div className="admin-editor-panel">
          <div className="admin-editor-header">
            <span className="admin-editor-title">
              {selected ? `Editing v${selected.version} — ${editMode}` : `New template — ${editMode}`}
            </span>
            <div className="admin-editor-actions">
              <button
                className={`admin-btn admin-btn--ghost ${previewMode ? "admin-btn--active" : ""}`}
                onClick={() => setPreviewMode((v) => !v)}
              >
                {previewMode ? "✏️ Edit" : "👁 Preview"}
              </button>
              <button className="admin-btn admin-btn--ghost" onClick={() => setShowEditor(false)}>
                ✕ Close
              </button>
            </div>
          </div>

          <div className="admin-mode-selector">
            <label>Mode:&nbsp;</label>
            {MODES.map((m) => (
              <button
                key={m}
                className={`admin-mode-pill ${editMode === m ? "admin-mode-pill--active" : ""}`}
                onClick={() => setEditMode(m)}
                disabled={!!selected}
              >
                {m}
              </button>
            ))}
          </div>

          {previewMode ? (
            <pre className="admin-template-preview">{editContent}</pre>
          ) : (
            <textarea
              className="admin-template-textarea"
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              placeholder={`Enter system prompt for "${editMode}" mode...\n\nUse {{KB_PROJECT_NAME}}, {{CORE_CONTEXT}}, {{MEMORY_SUMMARY}} placeholders.`}
              rows={20}
            />
          )}

          <div className="admin-editor-footer">
            <span className="admin-char-count">{editContent.length} / 50 000 chars</span>
            <button
              className="admin-btn admin-btn--primary"
              onClick={save}
              disabled={saving || !editContent.trim()}
            >
              {saving ? "Saving…" : "💾 Save & Activate"}
            </button>
          </div>
        </div>
      )}

      {/* Template list by mode */}
      {loading ? (
        <div className="admin-loading">Loading templates…</div>
      ) : (
        <div className="admin-template-modes">
          {MODES.map((mode) => (
            <div key={mode} className="admin-template-mode-group">
              <div className="admin-template-mode-header">
                <span className="admin-mode-badge">{mode}</span>
                <button
                  className="admin-btn admin-btn--sm admin-btn--secondary"
                  onClick={() => openNew(mode)}
                >
                  + New
                </button>
              </div>

              {grouped[mode].length === 0 ? (
                <p className="admin-empty-state">
                  Using file default — click "+ New" to create a DB override.
                </p>
              ) : (
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Version</th>
                      <th>Status</th>
                      <th>Created By</th>
                      <th>Created</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {grouped[mode].map((t) => (
                      <tr key={t.id} className={t.is_active ? "admin-table-row--active" : ""}>
                        <td>v{t.version}</td>
                        <td>
                          <span className={`admin-status-badge ${t.is_active ? "admin-status-badge--active" : "admin-status-badge--inactive"}`}>
                            {t.is_active ? "Active" : "Inactive"}
                          </span>
                        </td>
                        <td>{t.created_by}</td>
                        <td>{new Date(t.created_at).toLocaleDateString()}</td>
                        <td className="admin-table-actions">
                          <button className="admin-btn admin-btn--sm" onClick={() => openEdit(t)}>
                            View
                          </button>
                          {!t.is_active && (
                            <button
                              className="admin-btn admin-btn--sm admin-btn--primary"
                              onClick={() => activate(t.id)}
                            >
                              Activate
                            </button>
                          )}
                          {!t.is_active && (
                            <button
                              className="admin-btn admin-btn--sm admin-btn--danger"
                              onClick={() => remove(t.id)}
                            >
                              Delete
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
