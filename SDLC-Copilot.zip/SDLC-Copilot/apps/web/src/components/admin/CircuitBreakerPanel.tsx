"use client";

import { useCallback, useEffect, useState } from "react";
import type { ObserveCircuitBreakersResponse } from "@sdlc-copilot/shared";

const PROXY = "/api/proxy";

const STATE_COLORS: Record<string, string> = {
  closed: "#22c55e",
  open: "#ef4444",
  half_open: "#f59e0b",
};

export default function CircuitBreakerPanel() {
  const [data, setData] = useState<ObserveCircuitBreakersResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resetting, setResetting] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${PROXY}/observe/circuit-breakers`);
      if (!res.ok) throw new Error(`Failed to load (${res.status})`);
      setData(await res.json() as ObserveCircuitBreakersResponse);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const interval = setInterval(load, 10_000);
    return () => clearInterval(interval);
  }, [load]);

  const resetBreaker = async (service: string) => {
    if (!confirm(`Reset circuit breaker for "${service}"? This will allow calls to resume.`)) return;
    setResetting(service);
    try {
      // Use a simulate-reset by calling a health check — in production you'd have a dedicated endpoint
      await fetch(`${PROXY}/observe/circuit-breakers`);
      setError("Note: Manual reset requires the server admin reset endpoint (coming in Phase 4.3 RBAC).");
      load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setResetting(null);
      setTimeout(() => setError(null), 5000);
    }
  };

  return (
    <div className="admin-page">
      <div className="admin-page-header">
        <h1 className="admin-page-title">⚡ Circuit Breakers</h1>
        <p className="admin-page-subtitle">
          Protection for external APIs (Azure DevOps, GitHub). Opens after{" "}
          <code>CB_FAILURE_THRESHOLD</code> failures (default: 5), resets after{" "}
          <code>CB_OPEN_DURATION_MS</code> ms (default: 60s). Auto-refreshes every 10s.
        </p>
      </div>

      <div className="admin-toolbar">
        <button className="admin-btn admin-btn--secondary" onClick={load}>
          🔄 Refresh
        </button>
        {data?.capturedAt && (
          <span className="admin-toolbar-label">
            Last refreshed: {new Date(data.capturedAt).toLocaleTimeString()}
          </span>
        )}
      </div>

      {error && <div className="admin-error-banner">⚠ {error}</div>}

      {loading && !data ? (
        <div className="admin-loading">Loading circuit breaker states…</div>
      ) : !data || Object.keys(data.circuitBreakers).length === 0 ? (
        <div className="admin-empty-state admin-empty-state--padded">
          <p>No circuit breakers active yet.</p>
          <p className="admin-empty-hint">
            Circuit breakers initialize when external API calls are made
            (Azure DevOps fetch, GitHub API).
          </p>
        </div>
      ) : (
        <div className="admin-circuit-cards">
          {Object.entries(data.circuitBreakers).map(([service, state]) => (
            <div key={service} className={`admin-circuit-detail-card admin-circuit-detail-card--${state.state}`}>
              <div className="admin-circuit-detail-header">
                <span className="admin-circuit-service">{service}</span>
                <span
                  className="admin-circuit-state-badge"
                  style={{ background: STATE_COLORS[state.state], color: "#fff" }}
                >
                  {state.state.replace("_", " ").toUpperCase()}
                </span>
              </div>
              <div className="admin-circuit-detail-body">
                <div className="admin-circuit-stat">
                  <span className="admin-circuit-stat-label">Failures</span>
                  <span className="admin-circuit-stat-value">{state.failures}</span>
                </div>
                <div className="admin-circuit-stat">
                  <span className="admin-circuit-stat-label">Last Failure</span>
                  <span className="admin-circuit-stat-value">
                    {state.lastFailureAt
                      ? new Date(state.lastFailureAt).toLocaleTimeString()
                      : "—"}
                  </span>
                </div>
              </div>
              {state.state !== "closed" && (
                <button
                  className="admin-btn admin-btn--sm admin-btn--warning"
                  onClick={() => resetBreaker(service)}
                  disabled={resetting === service}
                >
                  {resetting === service ? "Resetting…" : "Force Reset"}
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
