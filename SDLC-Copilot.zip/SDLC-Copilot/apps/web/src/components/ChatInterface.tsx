﻿"use client";

import { useState, useRef, useEffect, useCallback, FormEvent } from "react";
import ReactMarkdown from "react-markdown";
import remarkBreaks from "remark-breaks";
import remarkGfm from "remark-gfm";
import type {
  ChatMessage,
  ChatStreamEvent,
  UDFilePayload,
  ArtifactDownloadPayload,
  ArtifactSavedPayload,
  BuildDetail,
  BuildStage,
} from "@sdlc-copilot/shared";
import { STAGE_LABELS } from "@sdlc-copilot/shared";

// All API calls go through the Next.js proxy route (/api/proxy/*) which
// injects the API key server-side. No secrets in the client bundle.
const PROXY_BASE = "/api/proxy";

// Project ID for this deployment. Defaults to 'default' until Phase 1 adds
// project selection UI. Configure via NEXT_PUBLIC_PROJECT_ID env var.
const PROJECT_ID = process.env.NEXT_PUBLIC_PROJECT_ID || "default";

// â”€â”€ Work Item Card (returned by preview-work-item endpoint) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
interface WorkItemCard {
  id: number;
  title: string;
  workItemType: string;
  state: string;
  assignedTo?: string | null;
  description: string;
  url: string;
}

// â”€â”€ Stage constants â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

// 5-tab pipeline UI: BRD → UD → Coding (impl_plan..pr_created) → Release → Completed
// endStage defines the last stage covered by a multi-stage tab.
const ACTIVE_STAGE_TABS: { stage: BuildStage; label: string; endStage?: BuildStage }[] = [
  { stage: "brd_intake",   label: "BRD" },
  { stage: "ud_draft",     label: "UD" },
  { stage: "impl_plan",    label: "Coding", endStage: "pr_created" },
  { stage: "release_docs", label: "Release" },
  { stage: "completed",    label: "Completed" },
];

// Map approval/gate stages → their parent draft stage (for navigation)
const STAGE_TO_ACTIVE: Partial<Record<BuildStage, BuildStage>> = {
  brd_approved:  "brd_intake",
  ud_approved:   "ud_draft",
  plan_approved: "impl_plan",
  pr_created:    "coding",
  completed:     "release_docs",
};

const STAGE_TO_MODE: Record<BuildStage, string> = {
  brd_intake:    "brd-analyst",
  brd_approved:  "brd-analyst",
  ud_draft:      "ud",
  ud_approved:   "ud",
  impl_plan:     "impl-plan",
  plan_approved: "impl-plan",
  coding:        "coding",
  pr_created:    "coding",
  release_docs:  "release",
  completed:     "release",
};

const STAGE_ORDER: BuildStage[] = [
  "brd_intake", "brd_approved", "ud_draft", "ud_approved",
  "impl_plan", "plan_approved", "coding", "pr_created",
  "release_docs", "completed",
];

function getActiveDraftStage(currentStage: BuildStage): BuildStage {
  return STAGE_TO_ACTIVE[currentStage] ?? currentStage;
}

/**
 * Compute the conversation stage to navigate to when a tab is clicked.
 * For compound tabs (impl_plan..pr_created), navigate to the current active
 * sub-stage. If build is past the tab, navigate to the tab start.
 */
function getTabClickStage(tabStart: BuildStage, tabEnd: BuildStage | undefined, build: BuildDetail): BuildStage {
  if (!tabEnd) return tabStart;
  const currentIdx = STAGE_ORDER.indexOf(build.currentStage);
  const startIdx = STAGE_ORDER.indexOf(tabStart);
  const endIdx = STAGE_ORDER.indexOf(tabEnd);
  if (currentIdx >= startIdx && currentIdx <= endIdx) {
    // Navigate to the active draft stage within this tab's range
    return getActiveDraftStage(build.currentStage);
  }
  // Build is past this tab, navigate to start for history
  return tabStart;
}

/**
 * Returns the representative tab stage for a given stage
 * (used to determine which tab is "current").
 */
function getTabForStage(stage: BuildStage): BuildStage | null {
  for (const tab of ACTIVE_STAGE_TABS) {
    const startIdx = STAGE_ORDER.indexOf(tab.stage);
    const endIdx = tab.endStage ? STAGE_ORDER.indexOf(tab.endStage) : startIdx;
    const idx = STAGE_ORDER.indexOf(stage);
    if (idx >= startIdx && idx <= endIdx) return tab.stage;
  }
  return null;
}

/** Build the BRD kickoff message including full Work Item details. */
function buildBRDKickoffMessage(wi: WorkItemCard | null): string {
  if (!wi) return "Work Item is ready for BRD intake. Please introduce yourself and begin requirements gathering.";
  const lines: string[] = [
    `Work Item **#${wi.id}** is ready for BRD intake.`,
    ``,
    `**Work Item Details:**`,
    `- **Type:** ${wi.workItemType}`,
    `- **Title:** ${wi.title}`,
    `- **State:** ${wi.state}`,
  ];
  if (wi.assignedTo) lines.push(`- **Assigned To:** ${wi.assignedTo}`);
  if (wi.description?.trim()) lines.push(`- **Description:** ${wi.description.trim()}`);
  lines.push(`- **URL:** ${wi.url}`);
  lines.push(``, `Please introduce yourself as the BRD Analyst, confirm these work item details, and begin requirements gathering.`);
  return lines.join("\n");
}

function isActiveStage(stage: BuildStage): boolean {
  return ["brd_intake", "ud_draft", "impl_plan", "coding", "release_docs"].includes(stage);
}

function getStageHint(stage: BuildStage): string {
  const hints: Partial<Record<BuildStage, string>> = {
    brd_intake:   "Implementation Plan",
    impl_plan:    "Implementation Plan",
    coding:       "Coding Agent",
  };
  return hints[stage] ?? "";
}

function getSessionId(buildId: string, stage: BuildStage): string {
  return `${buildId}-${stage}`;
}

// â”€â”€ localStorage helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

const LS_KEY_BUILD_ORDER = "sdlc_build_order";

function persistBuildOrder(buildIds: string[]): void {
  try { localStorage.setItem(LS_KEY_BUILD_ORDER, JSON.stringify(buildIds.slice(0, 50))); }
  catch { /* ignore */ }
}

function loadBuildOrder(): string[] {
  try { return JSON.parse(localStorage.getItem(LS_KEY_BUILD_ORDER) ?? "[]") as string[]; }
  catch { return []; }
}

// â”€â”€ Hint helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

function getStageEmptyHint(stage: BuildStage, build: BuildDetail): string {
  const hints: Partial<Record<string, string>> = {
    brd_intake:   `BRD Intake for Work Item #${build.adoWorkItemId ?? "?"} — Type a message to begin, or send the kickoff to start automatically.`,
    ud_draft:     "UD Draft stage — the agent will use the approved BRD to draft the User Document.",
    impl_plan:    "Implementation Plan stage — the agent will break down the approved UD into tasks.",
    coding:       "Coding stage — the agent will create GitHub issues and coordinate implementation.",
    release_docs: "Release Documentation stage — the agent will generate release notes from the completed work.",
    completed:    "🎉 Build complete! All stages have been approved. View the Release tab for the final release notes.",
  };
  return hints[stage] ?? "Start the conversation.";
}

function getInputPlaceholder(stage: BuildStage): string {
  const labels: Partial<Record<string, string>> = {
    brd_intake:   "Answer BRD questions, or type 'approved' to finalize...",
    ud_draft:     "Review and refine the UD draft...",
    impl_plan:    "Review and refine the implementation plan...",
    coding:       "Track coding progress, update status...",
    release_docs: "Review and refine the release notes...",
  };
  return labels[stage] ?? "Type a message... (Enter to send)";
}

// â”€â”€ Component â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

export function ChatInterface() {
  // â”€â”€ Build session list â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const [builds, setBuilds] = useState<BuildDetail[]>([]);
  const [activeBuild, setActiveBuild] = useState<BuildDetail | null>(null);
  const [activeStage, setActiveStage] = useState<BuildStage | null>(null);
  const [buildsLoading, setBuildsLoading] = useState(false);

  // â”€â”€ Per-stage message map (keyed by "{buildId}:{stage}") â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const [stageMessages, setStageMessages] = useState<Record<string, ChatMessage[]>>({});

  // â”€â”€ New session flow â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const [newSessionMode, setNewSessionMode] = useState(false);
  // Chat-wizard messages shown in the main pane while a new session is being created
  const [newSessionMessages, setNewSessionMessages] = useState<ChatMessage[]>([]);
  const [adoFetching, setAdoFetching] = useState(false);

  // â”€â”€ UI state â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [toolActivity, setToolActivity] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  // â”€â”€ UD download (latest approved UD file) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const udDownloadUrlRef = useRef<string | null>(null);
  const [udDownload, setUdDownload] = useState<{ filename: string; url: string; stage: BuildStage } | null>(null);

  // ── Artifact download (BRD, impl-plan, release-notes) ────────────────────────────
  const artifactDownloadUrlRef = useRef<string | null>(null);
  const [artifactDownload, setArtifactDownload] = useState<{ filename: string; url: string; label: string; stage: BuildStage } | null>(null);

  // ── Move to release state ─────────────────────────────────────────────────────────
  const [movingToRelease, setMovingToRelease] = useState(false);

  // ── Pending approval (artifact saved by agent, awaiting user click to advance stage) ──
  const [pendingApproval, setPendingApproval] = useState<{
    buildId: string;
    stage: string;
    filename: string;
    approving: boolean;
  } | null>(null);

  // Track which "{buildId}:{stage}" keys already received an auto-kickoff (no re-sends)
  const autoKickoffDoneRef = useRef<Set<string>>(new Set());  // Queued kickoff for newly created sessions (set by handleCreateSession, read by useEffect)
  const pendingKickoffRef = useRef<{ build: BuildDetail; stage: BuildStage; workItem: WorkItemCard | null; customMessage?: string } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Derived: messages for the current stage
  const stageKey = activeBuild && activeStage ? `${activeBuild.id}:${activeStage}` : null;
  const activeStageMessages: ChatMessage[] = stageKey ? (stageMessages[stageKey] ?? []) : [];

  // â”€â”€ Auto-scroll â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeStageMessages, newSessionMessages, toolActivity]);

  // â”€â”€ Cleanup blob URLs on unmount â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  useEffect(() => {
    return () => {
      if (udDownloadUrlRef.current) URL.revokeObjectURL(udDownloadUrlRef.current);
      if (artifactDownloadUrlRef.current) URL.revokeObjectURL(artifactDownloadUrlRef.current);
    };
  }, []);

  // â”€â”€ Load builds on mount â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  useEffect(() => {
    const loadBuilds = async () => {
      setBuildsLoading(true);
      try {
        const res = await fetch(`${PROXY_BASE}/builds?projectId=${encodeURIComponent(PROJECT_ID)}`);
        if (!res.ok) return;
        const data = await res.json() as { builds: BuildDetail[] };
        const order = loadBuildOrder();
        const sorted = [...data.builds].sort((a, b) => {
          const ai = order.indexOf(a.id);
          const bi = order.indexOf(b.id);
          if (ai === -1 && bi === -1) return 0;
          if (ai === -1) return 1;
          if (bi === -1) return -1;
          return ai - bi;
        });
        setBuilds(sorted);
      } catch { /* non-fatal */ }
      finally { setBuildsLoading(false); }
    };
    loadBuilds();
  }, []);

  // â”€â”€ Activate a build at a specific stage (load history) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const activateBuildAtStage = useCallback(async (build: BuildDetail, stage: BuildStage) => {
    setActiveBuild(build);
    setActiveStage(stage);
    setError(null);
    setToolActivity(null);
    setUdDownload(null);
    setArtifactDownload(null);
    setPendingApproval(null);

    const key = `${build.id}:${stage}`;
    // Only load history if we don't already have it cached
    if (!stageMessages[key]) {
      const sessionId = getSessionId(build.id, stage);
      const mode = STAGE_TO_MODE[stage];
      try {
        const res = await fetch(
          `${PROXY_BASE}/chat/history?sessionId=${encodeURIComponent(sessionId)}&mode=${encodeURIComponent(mode)}&projectId=${encodeURIComponent(PROJECT_ID)}`
        );
        if (res.ok) {
          const data = await res.json() as { messages: ChatMessage[] };
          setStageMessages(prev => ({ ...prev, [key]: data.messages ?? [] }));
        } else {
          setStageMessages(prev => ({ ...prev, [key]: [] }));
        }
      } catch {
        setStageMessages(prev => ({ ...prev, [key]: [] }));
      }
    }
  }, [stageMessages]);

  // â”€â”€ Fetch Work Item preview â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  // ── New session wizard: user types Work Item ID directly in chat ────────────────
  const handleNewSessionInput = useCallback(async (e?: FormEvent) => {
    e?.preventDefault();
    const text = input.trim();
    if (!text || adoFetching || isLoading) return;
    setInput("");

    // Show user message in wizard chat
    setNewSessionMessages(prev => [...prev, { role: "user", content: text }]);

    const wiId = parseInt(text, 10);
    if (!wiId || wiId < 1 || wiId > 9_999_999) {
      setNewSessionMessages(prev => [...prev, {
        role: "assistant",
        content: "❌ That doesn't look like a valid Work Item ID. Please enter a number (e.g. `4521`).",
      }]);
      return;
    }

    // Typing indicator while fetching
    setAdoFetching(true);
    setNewSessionMessages(prev => [...prev, { role: "assistant", content: "" }]);

    try {
      const res = await fetch(
        `${PROXY_BASE}/builds/preview-work-item?id=${wiId}&projectId=${encodeURIComponent(PROJECT_ID)}`
      );
      if (!res.ok) {
        const d = await res.json().catch(() => ({})) as { error?: string };
        throw new Error(d.error ?? `Work item not found (${res.status})`);
      }
      const { workItem: wi } = await res.json() as { workItem: WorkItemCard };

      // Replace typing indicator with work item summary
      setNewSessionMessages(prev => {
        const msgs = [...prev];
        const last = msgs[msgs.length - 1];
        if (last?.role === "assistant" && last.content === "") {
          msgs[msgs.length - 1] = {
            role: "assistant",
            content: `Found **${wi.workItemType} #${wi.id}**: ${wi.title}\n\n**State:** ${wi.state}${wi.assignedTo ? `  \n**Assigned to:** ${wi.assignedTo}` : ""}\n\nCreating your BRD session…`,
          };
        }
        return msgs;
      });

      // Create the build session
      const createRes = await fetch(`${PROXY_BASE}/builds`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectId: PROJECT_ID,
          title: wi.title,
          adoWorkItemId: wi.id,
          description: null,
        }),
      });
      if (!createRes.ok) {
        const d = await createRes.json().catch(() => ({})) as { error?: string };
        throw new Error(d.error ?? "Failed to create session");
      }
      const { build: newBuild } = await createRes.json() as { build: BuildDetail };

      // Persist order and update list
      const newOrder = [newBuild.id, ...builds.map(b => b.id)];
      setBuilds(prev => [newBuild, ...prev]);
      persistBuildOrder(newOrder);

      // Transition to live BRD chat
      setNewSessionMode(false);
      setNewSessionMessages([]);
      const brdKey = `${newBuild.id}:brd_intake`;
      setStageMessages(prev => ({ ...prev, [brdKey]: [] }));

      // Queue auto-kickoff BEFORE activateBuildAtStage so it's set when the
      // useEffect runs (which fires on the activeBuild?.id dep change).
      pendingKickoffRef.current = {
        build: newBuild,
        stage: "brd_intake",
        workItem: wi,
      };

      await activateBuildAtStage(newBuild, "brd_intake");
    } catch (err: any) {
      setNewSessionMessages(prev => {
        const msgs = [...prev];
        const last = msgs[msgs.length - 1];
        const errMsg = `❌ ${err.message ?? "Something went wrong"}. Please try a different Work Item ID.`;
        if (last?.role === "assistant" && last.content === "") {
          msgs[msgs.length - 1] = { role: "assistant", content: errMsg };
        } else {
          msgs.push({ role: "assistant", content: errMsg });
        }
        return msgs;
      });
    } finally {
      setAdoFetching(false);
      inputRef.current?.focus();
    }
  }, [input, adoFetching, isLoading, builds, activateBuildAtStage]);


  // â”€â”€ Select existing build from list â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const handleSelectBuild = useCallback(async (build: BuildDetail) => {
    // Re-fetch to get the freshest detail
    try {
      const res = await fetch(`${PROXY_BASE}/builds/${encodeURIComponent(build.id)}`);
      if (res.ok) {
        const data = await res.json() as { build: BuildDetail };
        build = data.build;
        setBuilds(prev => prev.map(b => b.id === build.id ? build : b));
      }
    } catch { /* use the list-loaded build */ }

    const stage = getActiveDraftStage(build.currentStage);
    await activateBuildAtStage(build, stage);
  }, [activateBuildAtStage]);

  // â”€â”€ Switch stage tab â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const handleSwitchStage = useCallback(async (stage: BuildStage) => {
    if (!activeBuild) return;

    // Auto-kickoff for UD and impl-plan stages when there is no existing history
    const stageKey = `${activeBuild.id}:${stage}`;
    const hasMessages = (stageMessages[stageKey]?.length ?? 0) > 0;
    const alreadyKickedOff = autoKickoffDoneRef.current.has(stageKey);
    if (!hasMessages && !alreadyKickedOff && (stage === "ud_draft" || stage === "impl_plan")) {
      pendingKickoffRef.current = { build: activeBuild, stage, workItem: null };
    }

    await activateBuildAtStage(activeBuild, stage);
  }, [activeBuild, activateBuildAtStage, stageMessages]);

  // â”€â”€ SSE message stream parser â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const processSSEStream = useCallback(async (
    reader: ReadableStreamDefaultReader<Uint8Array>,
    key: string,
    buildId: string
  ) => {
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        let event: ChatStreamEvent;
        try { event = JSON.parse(line.slice(6)) as ChatStreamEvent; }
        catch { continue; }

        switch (event.type) {
          case "chunk":
            setStageMessages(prev => {
              const msgs = [...(prev[key] ?? [])];
              const last = msgs[msgs.length - 1];
              if (last?.role === "assistant") {
                msgs[msgs.length - 1] = { ...last, content: last.content + event.data };
              }
              return { ...prev, [key]: msgs };
            });
            break;

          case "tool_start":
            setToolActivity(event.data);
            break;

          case "tool_complete":
            setToolActivity(null);
            break;

          case "ud_file_ready": {
            const payload = JSON.parse(event.data) as UDFilePayload;
            if (udDownloadUrlRef.current) URL.revokeObjectURL(udDownloadUrlRef.current);
            const blob = new Blob([payload.content], { type: "text/markdown" });
            const url = URL.createObjectURL(blob);
            udDownloadUrlRef.current = url;
            // Derive the stage from the stream key (format: "{buildId}:{stage}")
            const udStage = key.split(":").slice(1).join(":") as BuildStage;
            setUdDownload({ filename: payload.filename, url, stage: udStage });
            break;
          }

          case "artifact_download_ready": {
            const payload = JSON.parse(event.data) as ArtifactDownloadPayload;
            if (artifactDownloadUrlRef.current) URL.revokeObjectURL(artifactDownloadUrlRef.current);
            const blob = new Blob([payload.content], { type: "text/markdown" });
            const url = URL.createObjectURL(blob);
            artifactDownloadUrlRef.current = url;
            const typeLabels: Record<string, string> = { brd: "BRD", "impl-plan": "Implementation Plan", "release-notes": "Release Notes" };
            const artifactStage = key.split(":").slice(1).join(":") as BuildStage;
            setArtifactDownload({ filename: payload.filename, url, label: typeLabels[payload.artifactType] ?? "Document", stage: artifactStage });
            break;
          }

          case "artifact_saved": {
            // Agent saved a build artifact — show Approve button so user can advance stage
            try {
              const payload = JSON.parse(event.data) as ArtifactSavedPayload;
              setPendingApproval({
                buildId: payload.buildId,
                stage: payload.stage,
                filename: payload.filename,
                approving: false,
              });
            } catch { /* non-fatal */ }
            break;
          }

          case "build_stage_advanced": {
            try {
              const { buildId: advBuildId } = JSON.parse(event.data) as { buildId: string; newStage: string };
              if (advBuildId === buildId) {
                const r = await fetch(`${PROXY_BASE}/builds/${encodeURIComponent(buildId)}`);
                if (r.ok) {
                  const d = await r.json() as { build: BuildDetail };
                  setActiveBuild(d.build);
                  setBuilds(prev => prev.map(b => b.id === buildId ? d.build : b));
                }
              }
            } catch { /* non-fatal */ }
            break;
          }

          case "done":
            setToolActivity(null);
            break;

          case "error":
            throw new Error(event.data);
        }
      }
    }
  }, []);

  // â”€â”€ Send message (build-aware) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const sendMessage = useCallback(async (e?: FormEvent, overrideText?: string) => {
    e?.preventDefault();
    const text = (overrideText ?? input).trim();
    if (!text || isLoading || !activeBuild || !activeStage) return;

    const buildId = activeBuild.id;
    const stage = activeStage;
    const sessionId = getSessionId(buildId, stage);
    const mode = STAGE_TO_MODE[stage];
    const key = `${buildId}:${stage}`;

    if (!overrideText) setInput("");
    setError(null);
    setToolActivity(null);

    // Optimistic add user + assistant placeholder
    setStageMessages(prev => ({
      ...prev,
      [key]: [...(prev[key] ?? []), { role: "user", content: text }, { role: "assistant", content: "" }],
    }));
    setIsLoading(true);

    try {
      const res = await fetch(`${PROXY_BASE}/chat/stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          message: text,
          mode,
          projectId: PROJECT_ID,
          buildId,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error((data as any).error || `Server responded with ${res.status}`);
      }

      const reader = res.body?.getReader();
      if (!reader) throw new Error("No response body");

      await processSSEStream(reader, key, buildId);
    } catch (err: any) {
      setError(err.message || "Something went wrong");
      setStageMessages(prev => {
        const msgs = [...(prev[key] ?? [])];
        const last = msgs[msgs.length - 1];
        if (last?.role === "assistant" && last.content === "") msgs.pop();
        return { ...prev, [key]: msgs };
      });
    } finally {
      setIsLoading(false);
      setToolActivity(null);
      inputRef.current?.focus();
    }
  }, [input, isLoading, activeBuild, activeStage, processSSEStream]);

  // ── Approve the current stage (after agent saved artifact) ───────────────────────
  // Auto-advances through non-interactive gate stages (brd_approved, ud_approved, etc.)
  const GATE_STAGES = new Set(["brd_approved", "ud_approved", "plan_approved", "pr_created"]);

  const handleApprove = useCallback(async () => {
    if (!pendingApproval || !activeBuild) return;
    const capturedApproval = pendingApproval;
    const capturedBuild = activeBuild;
    setPendingApproval(prev => prev ? { ...prev, approving: true } : null);

    try {
      const res = await fetch(
        `${PROXY_BASE}/builds/${encodeURIComponent(capturedBuild.id)}/approve`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ comments: `Stage '${capturedApproval.stage}' approved via chat` }),
        }
      );
      if (!res.ok) {
        const d = await res.json().catch(() => ({})) as { error?: string };
        throw new Error(d.error ?? "Approval failed");
      }
      const firstApproveData = await res.json() as {
        build: BuildDetail;
        adoAttached?: boolean;
        adoAttachError?: string | null;
        adoWorkItemId?: string | null;
      };
      let updatedBuild = firstApproveData.build;
      const adoAttached = firstApproveData.adoAttached ?? false;
      const adoWorkItemId = firstApproveData.adoWorkItemId ?? capturedBuild.adoWorkItemId;

      // Auto-advance through gate stages that need no artifact or user action
      while (GATE_STAGES.has(updatedBuild.currentStage)) {
        const gateRes = await fetch(
          `${PROXY_BASE}/builds/${encodeURIComponent(updatedBuild.id)}/approve`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ comments: `Auto-advance from gate '${updatedBuild.currentStage}'` }),
          }
        );
        if (!gateRes.ok) break;
        updatedBuild = (await gateRes.json() as { build: BuildDetail }).build;
      }

      // Update state
      setPendingApproval(null);
      setActiveBuild(updatedBuild);
      setBuilds(prev => prev.map(b => b.id === updatedBuild.id ? updatedBuild : b));

      const sKey = `${capturedBuild.id}:${capturedApproval.stage}`;

      // Build ADO attachment confirmation line
      const adoLine = adoAttached && adoWorkItemId
        ? `\n📎 Document attached to Azure Work Item **#${adoWorkItemId}**.`
        : "";

      // ── Case 1: Pipeline fully completed ──────────────────────────────────────
      if (updatedBuild.currentStage === "completed") {
        setStageMessages(prev => ({
          ...prev,
          [sKey]: [
            ...(prev[sKey] ?? []),
            {
              role: "assistant",
              content: `✅ Stage approved. ${adoLine}\n\n🎉 **Build successfully completed!** All stages are approved. Click the **Completed** tab to view the final summary.`,
            },
          ],
        }));
        return;
      }

      // ── Case 2: Advance to coding → auto-navigate + start GitHub issue ────────
      if (updatedBuild.currentStage === "coding") {
        const codingMsg = `✅ Implementation plan approved.${adoLine}\n\nNavigating to the **Coding** tab to create a GitHub Issue and trigger the Copilot Coding Agent…`;
        setStageMessages(prev => ({
          ...prev,
          [sKey]: [...(prev[sKey] ?? []), { role: "assistant", content: codingMsg }],
        }));

        // Queue coding kickoff via pendingKickoffRef so it fires after state settles
        const wiId = updatedBuild.adoWorkItemId ?? "?";
        const codingKickoff = `The implementation plan has been approved. Please review the implementation plan from the prior stage context and immediately create a GitHub Issue using the trigger_coding_agent tool. Include the full task breakdown in the issue body so the Copilot Coding Agent has everything it needs. Work Item: #${wiId}.`;
        pendingKickoffRef.current = { build: updatedBuild, stage: "coding", workItem: null, customMessage: codingKickoff };
        await activateBuildAtStage(updatedBuild, "coding");
        return;
      }

      // ── Case 3: Normal stage advance ──────────────────────────────────────────
      const nextDraftStage = getActiveDraftStage(updatedBuild.currentStage as BuildStage);
      const nextTabStage = getTabForStage(updatedBuild.currentStage as BuildStage);
      const currentTabStage = getTabForStage(capturedApproval.stage as BuildStage);
      const sameTab = nextTabStage === currentTabStage;
      const nextTabLabel = ACTIVE_STAGE_TABS.find(t => t.stage === nextTabStage)?.label ?? (STAGE_LABELS[updatedBuild.currentStage as BuildStage] ?? updatedBuild.currentStage);
      const nextHint = isActiveStage(nextDraftStage as BuildStage)
        ? sameTab
          ? ` Continue in the current **${nextTabLabel}** tab.`
          : ` Click the **${nextTabLabel}** tab to continue.`
        : "";
      setStageMessages(prev => ({
        ...prev,
        [sKey]: [
          ...(prev[sKey] ?? []),
          {
            role: "assistant",
            content: `✅ Stage approved. Pipeline is now at: **${nextTabLabel}${sameTab && nextDraftStage !== capturedApproval.stage ? ` · ${STAGE_LABELS[nextDraftStage as BuildStage] ?? nextDraftStage}` : ""}**.${adoLine}${nextHint}`,
          },
        ],
      }));
    } catch (err: any) {
      setPendingApproval(prev => prev ? { ...prev, approving: false } : null);
      setError(err.message ?? "Approval failed");
    }
  }, [pendingApproval, activeBuild, activateBuildAtStage]);

  // ── Send a kickoff message for new build sessions (agent auto-start) ─────────────
  const sendKickoffDirectly = useCallback(async (
    build: BuildDetail,
    stage: BuildStage,
    kickoffText: string
  ) => {
    const buildId = build.id;
    const sessionId = getSessionId(buildId, stage);
    const mode = STAGE_TO_MODE[stage];
    const key = `${buildId}:${stage}`;

    setStageMessages(prev => ({
      ...prev,
      [key]: [
        { role: "user", content: kickoffText },
        { role: "assistant", content: "" },
      ],
    }));
    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch(`${PROXY_BASE}/chat/stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, message: kickoffText, mode, projectId: PROJECT_ID, buildId }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error((d as any).error || `Server error ${res.status}`);
      }
      const reader = res.body?.getReader();
      if (!reader) throw new Error("No response body");
      await processSSEStream(reader, key, buildId);
    } catch (err: any) {
      setError(err.message || "Failed to start session");
      setStageMessages(prev => {
        const msgs = [...(prev[key] ?? [])];
        const last = msgs[msgs.length - 1];
        if (last?.role === "assistant" && last.content === "") msgs.pop();
        return { ...prev, [key]: msgs };
      });
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  }, [processSSEStream]);

  // ── Move pipeline from Coding to Release Documentation ────────────────────────────
  const handleMoveToRelease = useCallback(async () => {
    if (!activeBuild || movingToRelease) return;
    setMovingToRelease(true);
    try {
      let updatedBuild = activeBuild;
      // Advance through coding → pr_created → release_docs
      const codingStages = new Set(["coding", "pr_created"]);
      while (codingStages.has(updatedBuild.currentStage)) {
        const res = await fetch(
          `${PROXY_BASE}/builds/${encodeURIComponent(updatedBuild.id)}/approve`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ comments: "Coding complete, advancing to Release Documentation" }),
          }
        );
        if (!res.ok) {
          const d = await res.json().catch(() => ({})) as { error?: string };
          throw new Error(d.error ?? "Failed to advance stage");
        }
        updatedBuild = (await res.json() as { build: BuildDetail }).build;
      }
      setActiveBuild(updatedBuild);
      setBuilds(prev => prev.map(b => b.id === updatedBuild.id ? updatedBuild : b));

      // Navigate to release_docs tab and auto-kickoff the release agent
      await activateBuildAtStage(updatedBuild, "release_docs");
      const wiId = updatedBuild.adoWorkItemId ?? "?";
      setTimeout(() => {
        sendKickoffDirectly(
          updatedBuild,
          "release_docs",
          `Start preparing release notes and KB update for Work Item #${wiId}: "${updatedBuild.title}". Use the implementation plan from the prior stage context to draft the release notes — do not ask me for information already available there.`
        );
      }, 300);
    } catch (err: any) {
      setError(err.message ?? "Failed to advance to Release");
    } finally {
      setMovingToRelease(false);
    }
  }, [activeBuild, movingToRelease, activateBuildAtStage, sendKickoffDirectly]);

  // ── Auto-kickoff effect: fires after sendKickoffDirectly is wired and state settles ─
  // When a new BRD session is created, this sends the initial greeting/intake message.
  useEffect(() => {
    const pending = pendingKickoffRef.current;
    if (!pending || isLoading) return;

    const kickoffKey = `${pending.build.id}:${pending.stage}`;
    if (autoKickoffDoneRef.current.has(kickoffKey)) {
      pendingKickoffRef.current = null;
      return;
    }

    // Small delay to let React paint the empty conversation first
    const timer = setTimeout(() => {
      if (!pendingKickoffRef.current) return;
      autoKickoffDoneRef.current.add(kickoffKey);
      const { build: pendingBuild, stage: pendingStage, workItem, customMessage } = pendingKickoffRef.current;
      pendingKickoffRef.current = null;

      let kickoffMsg: string;
      if (customMessage) {
        kickoffMsg = customMessage;
      } else if (pendingStage === "ud_draft") {
        kickoffMsg = `Start drafting the Understanding Document based on the approved BRD for Work Item #${pendingBuild.adoWorkItemId ?? "?"}.`;
      } else if (pendingStage === "impl_plan") {
        kickoffMsg = `Start the implementation plan based on the approved UD for Work Item #${pendingBuild.adoWorkItemId ?? "?"}. Break down all tasks needed to implement the feature.`;
      } else {
        kickoffMsg = buildBRDKickoffMessage(workItem ?? null);
      }

      sendKickoffDirectly(pendingBuild, pendingStage, kickoffMsg);
    }, 400);

    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeBuild?.id, activeStage, isLoading, sendKickoffDirectly]);

  // â”€â”€ Copy to clipboard â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const copyMessage = useCallback(async (content: string, idx: number) => {
    try {
      await navigator.clipboard.writeText(content);
    } catch {
      const el = document.createElement("textarea");
      el.value = content;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
    }
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  }, []);

  // Submit on Enter (Shift+Enter = newline)
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (newSessionMode && !activeBuild) {
        handleNewSessionInput();
      } else {
        sendMessage();
      }
    }
  };

  // â”€â”€ Render â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

  return (
    <div className="builds-layout">
      {/* â”€â”€ Header â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */}
      <div className="builds-header">
        <span className="chat-header-icon" role="img" aria-label="copilot">🤖</span>
        <div className="chat-header-text">
          <h1 className="chat-header-title">SDLC Copilot</h1>
          <p className="chat-header-subtitle">Build Pipeline Agent</p>
        </div>
        <a href="/admin" className="chat-new-btn" title="Admin dashboard">⚙️ Admin</a>
      </div>

      {/* â”€â”€ Body: two columns â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */}
      <div className="builds-body">

        {/* â”€â”€ Session List Panel â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */}
        <aside className="session-list-panel">
          <div className="session-list-header">
            <strong>Sessions</strong>
            <button
              className="session-new-btn"
              onClick={() => {
                if (newSessionMode) {
                  setNewSessionMode(false);
                  setNewSessionMessages([]);
                } else {
                  setNewSessionMode(true);
                  setActiveBuild(null);
                  setActiveStage(null);
                  setNewSessionMessages([{
                    role: "assistant",
                    content: " To start a new SDLC session, enter your **Azure DevOps Work Item ID** below (e.g. `4521`), then press Enter.",
                  }]);
                }
              }}
            >
              {newSessionMode ? " Cancel" : "+ New"}
            </button>
          </div>

          {/* Session list */}
          {buildsLoading ? (
            <div className="session-list-loading">⚙️ Loading…</div>
          ) : builds.length === 0 ? (
            <p className="session-list-empty">No sessions yet.<br />Start with a Work Item #.</p>
          ) : (
            <ul className="session-list">
              {builds.map(b => (
                <li
                  key={b.id}
                  className={`session-card ${activeBuild?.id === b.id ? "session-card--active" : ""}`}
                  onClick={() => handleSelectBuild(b)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={e => { if (e.key === "Enter") handleSelectBuild(b); }}
                >
                  <span className="session-card-wi">#{b.adoWorkItemId ?? "—"}</span>
                  <span className="session-card-stage">{STAGE_LABELS[b.currentStage]}</span>
                </li>
              ))}
            </ul>
          )}
        </aside>

        {/* â”€â”€ Main: Stage tabs + Conversation â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */}
        <main className="builds-main">
          {!activeBuild && !newSessionMode ? (
            <div className="builds-main-empty">
              <p>Select a session or start a new one with an Azure Work Item #</p>
            </div>
          ) : !activeBuild && newSessionMode ? (
            /* ── New session chat wizard ── */
            <>
              <div className="chat-messages">
                {newSessionMessages.map((msg, i) => (
                  <div
                    key={i}
                    className={`chat-bubble-wrapper ${msg.role === "user" ? "chat-bubble-wrapper--user" : "chat-bubble-wrapper--assistant"}`}
                  >
                    <div className={`chat-bubble ${msg.role === "user" ? "chat-bubble--user" : "chat-bubble--assistant"}`}>
                      {msg.role === "assistant" ? (
                        msg.content ? (
                          <div className="markdown-content">
                            <ReactMarkdown remarkPlugins={[remarkGfm, remarkBreaks]}>{msg.content}</ReactMarkdown>
                          </div>
                        ) : (
                          <span className="chat-typing">● ● ●</span>
                        )
                      ) : (
                        <span style={{ whiteSpace: "pre-wrap" }}>{msg.content}</span>
                      )}
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
              <form className="chat-input-form" onSubmit={handleNewSessionInput}>
                <textarea
                  ref={inputRef}
                  className="chat-input"
                  placeholder="Enter Work Item ID (e.g. 4521)…"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  disabled={adoFetching || isLoading}
                  rows={2}
                />
                <button
                  type="submit"
                  className={`chat-send-btn ${adoFetching ? "chat-send-btn--loading" : ""}`}
                  disabled={adoFetching || isLoading || !input.trim()}
                >
                  {adoFetching ? "⏳" : "➤"}
                </button>
              </form>
            </>
          ) : (
            <>
              {/* Stage tab bar */}
              <nav className="stage-tabs" aria-label="Pipeline stages">
                {ACTIVE_STAGE_TABS.map(({ stage, label, endStage }) => {
                  const stageIdx = STAGE_ORDER.indexOf(stage);
                  const tabEndIdx = endStage ? STAGE_ORDER.indexOf(endStage) : stageIdx;
                  const currentIdx = STAGE_ORDER.indexOf(activeBuild!.currentStage);
                  const isCompleted = currentIdx > tabEndIdx;
                  const isCurrent = currentIdx >= stageIdx && currentIdx <= tabEndIdx;
                  const isAccessible = stageIdx <= currentIdx;
                  const clickStage = getTabClickStage(stage, endStage, activeBuild!);

                  return (
                    <button
                      key={stage}
                      className={[
                        "stage-tab",
                        isCompleted ? "stage-tab--done" : "",
                        isCurrent ? "stage-tab--active" : "",
                        !isAccessible ? "stage-tab--locked" : "",
                      ].filter(Boolean).join(" ")}
                      onClick={() => isAccessible && handleSwitchStage(clickStage)}
                      disabled={!isAccessible}
                      title={isAccessible ? label : "Complete prior stages first"}
                      aria-current={isCurrent ? "page" : undefined}
                    >
                      {isCompleted ? "✔ " : isCurrent ? "● " : "○ "}{label}
                    </button>
                  );
                })}
              </nav>

              {/* Conversation area */}
              <div className="chat-messages">
                {activeStageMessages.length === 0 && !isLoading && (
                  <div className="chat-empty">
                    <p>{getStageEmptyHint(activeStage!, activeBuild!)}</p>
                  </div>
                )}

                {activeStageMessages.map((msg, i) => (
                  <div
                    key={i}
                    className={`chat-bubble-wrapper ${
                      msg.role === "user" ? "chat-bubble-wrapper--user" : "chat-bubble-wrapper--assistant"
                    }`}
                  >
                    <div
                      className={`chat-bubble ${
                        msg.role === "user" ? "chat-bubble--user" : "chat-bubble--assistant"
                      }`}
                    >
                      {msg.role === "assistant" ? (
                        msg.content ? (
                          <div className="markdown-content">
                            <ReactMarkdown remarkPlugins={[remarkGfm, remarkBreaks]}>{msg.content}</ReactMarkdown>
                          </div>
                        ) : (
                          <span className="chat-typing">● ● ●</span>
                        )
                      ) : (
                        <span style={{ whiteSpace: "pre-wrap" }}>{msg.content}</span>
                      )}
                    </div>
                    {msg.content && (
                      <button
                        className="chat-copy-btn"
                        onClick={() => copyMessage(msg.content, i)}
                        title="Copy to clipboard"
                        aria-label="Copy message"
                      >
                        {copiedIdx === i ? "✔" : "📋"}
                      </button>
                    )}
                  </div>
                ))}

                {toolActivity && (
                  <div className="chat-tool-activity">
                    <span className="chat-tool-spinner" aria-hidden="true">⚙️</span>
                    <span>{toolActivity}</span>
                  </div>
                )}

                {/* UD download — shown until dismissed */}
                {udDownload && (
                  <div className="chat-ud-download">
                    <span>🔥</span>
                    <span>Your UD is ready:</span>
                    <a
                      href={udDownload.url}
                      download={udDownload.filename}
                      className="chat-ud-download-link"
                    >
                      {udDownload.filename}
                    </a>
                    <button
                      className="chat-dismiss-btn"
                      onClick={() => setUdDownload(null)}
                      title="Dismiss"
                      aria-label="Dismiss UD download notification"
                    >
                      ✕
                    </button>
                  </div>
                )}

                {/* Artifact download (BRD, Implementation Plan, Release Notes) — shown until dismissed */}
                {artifactDownload && (
                  <div className="chat-ud-download">
                    <span>📄</span>
                    <span>{artifactDownload.label} ready:</span>
                    <a
                      href={artifactDownload.url}
                      download={artifactDownload.filename}
                      className="chat-ud-download-link"
                    >
                      {artifactDownload.filename}
                    </a>
                    <button
                      className="chat-dismiss-btn"
                      onClick={() => setArtifactDownload(null)}
                      title="Dismiss"
                      aria-label="Dismiss artifact download notification"
                    >
                      ✕
                    </button>
                  </div>
                )}

                {error && (
                  <div className="chat-error">
                    <strong>Error:</strong> {error}
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* ── Approve bar: shown when agent saves an artifact ── */}
              {pendingApproval && pendingApproval.buildId === activeBuild!.id && (
                <div className="chat-approve-bar">
                  <div className="chat-approve-info">
                    <span className="chat-approve-icon">📄</span>
                    <div className="chat-approve-label">
                      <strong>{pendingApproval.filename}</strong> is ready for review.
                      {activeBuild!.adoWorkItemId && (
                        <span className="chat-approve-ado-hint"> Approving will attach it to Work Item <strong>#{activeBuild!.adoWorkItemId}</strong>.</span>
                      )}
                    </div>
                  </div>
                  <button
                    className="chat-approve-btn"
                    onClick={handleApprove}
                    disabled={pendingApproval.approving}
                    aria-label="Approve this stage and advance pipeline"
                  >
                    {pendingApproval.approving ? "⏳ Approving…" : "✅ Approve & Advance →"}
                  </button>
                </div>
              )}

              {/* ── Move to Release: visible when at coding stage (PR done or manual advance) ── */}
              {activeBuild &&
                activeStage === "coding" &&
                (activeBuild.currentStage === "coding" || activeBuild.currentStage === "pr_created") &&
                !pendingApproval && (
                <div className="chat-approve-bar">
                  <div className="chat-approve-info">
                    <span className="chat-approve-icon">🚀</span>
                    <span className="chat-approve-label">PR merged or coding complete?</span>
                  </div>
                  <button
                    className="chat-approve-btn"
                    onClick={handleMoveToRelease}
                    disabled={movingToRelease}
                    aria-label="Move pipeline to Release Documentation stage"
                  >
                    {movingToRelease ? "⏳ Moving…" : "Move to Release →"}
                  </button>
                </div>
              )}

              {/* Input area */}
              <form className="chat-input-form" onSubmit={sendMessage}>
                <textarea
                  ref={inputRef}
                  className="chat-input"
                  placeholder={activeStage ? getInputPlaceholder(activeStage) : "Type a message..."}
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  disabled={isLoading || !activeStage || !isActiveStage(activeBuild!.currentStage)}
                  rows={2}
                />
                <button
                  type="submit"
                  className={`chat-send-btn ${isLoading ? "chat-send-btn--loading" : ""}`}
                  disabled={isLoading || !input.trim()}
                >
                  {isLoading ? "⏳" : "➤"}
                </button>
              </form>
            </>
          )}
        </main>
      </div>
    </div>
  );
}