/**
 * Next.js App Router proxy — routes all /api/proxy/* requests to the Express
 * backend, injecting the API key server-side so it is never exposed in the
 * client bundle.
 *
 * Mapping:
 *   /api/proxy/chat/stream  → http://EXPRESS_SERVER_URL/api/chat/stream
 *   /api/proxy/...          → http://EXPRESS_SERVER_URL/api/...
 *
 * SSE streaming is preserved: the Response body is piped directly from the
 * upstream fetch, so chunks arrive in real time.
 *
 * Phase 0.0 — Security fix V2 (API key removed from client bundle)
 */

import { type NextRequest } from "next/server";

// Server-side only — NOT prefixed with NEXT_PUBLIC_
const EXPRESS_SERVER_URL =
  process.env.EXPRESS_SERVER_URL || "http://localhost:4000";
const API_KEY = process.env.API_KEY || "";

// Timeout for upstream requests (SSE streams use a longer timeout via AbortSignal)
const UPSTREAM_TIMEOUT_MS = Number(process.env.PROXY_TIMEOUT_MS) || 300_000; // 5 min

// Allowlist: each path segment must match this pattern to prevent path traversal.
// Permits alphanumeric, hyphens, underscores, dots. Blocks ".." and slash injection.
const SAFE_SEGMENT_RE = /^[a-zA-Z0-9._\-]+$/;

export const dynamic = "force-dynamic";

async function handler(
  req: NextRequest,
  context: { params: Promise<{ path: string[] }> }
): Promise<Response> {
  const { path } = await context.params;

  // Validate every segment against traversal and unexpected characters
  for (const segment of path) {
    if (!SAFE_SEGMENT_RE.test(segment)) {
      return new Response(JSON.stringify({ error: "Invalid path" }), {
        status: 400,
        headers: { "content-type": "application/json" },
      });
    }
  }

  // Preserve query string from the original request (e.g. ?sessionId=...&mode=...)
  const search = req.nextUrl.search; // includes leading "?" or is ""
  const targetUrl = `${EXPRESS_SERVER_URL}/api/${path.join("/")}${search}`;

  const forwardHeaders = new Headers();

  // Forward content-type for POST bodies
  const ct = req.headers.get("content-type");
  if (ct) forwardHeaders.set("content-type", ct);

  // Inject API key server-side (the browser never sees this)
  if (API_KEY) forwardHeaders.set("x-api-key", API_KEY);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);

  const upstreamInit: RequestInit & { duplex?: string } = {
    method: req.method,
    headers: forwardHeaders,
    cache: "no-store",
    signal: controller.signal,
  };

  // Stream request body for POST/PUT/PATCH
  if (req.method !== "GET" && req.method !== "HEAD") {
    upstreamInit.body = req.body;
    upstreamInit.duplex = "half"; // required for streaming request bodies
  }

  let upstream: globalThis.Response;
  try {
    upstream = await fetch(targetUrl, upstreamInit);
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err?.name === "AbortError") {
      return new Response(JSON.stringify({ error: "Upstream request timed out" }), {
        status: 504,
        headers: { "content-type": "application/json" },
      });
    }
    return new Response(JSON.stringify({ error: "Upstream unreachable" }), {
      status: 502,
      headers: { "content-type": "application/json" },
    });
  }
  clearTimeout(timeoutId);

  // Forward response headers — skip hop-by-hop headers that would break the client
  const responseHeaders = new Headers();
  upstream.headers.forEach((value, key) => {
    const lower = key.toLowerCase();
    if (lower !== "transfer-encoding" && lower !== "connection") {
      responseHeaders.set(key, value);
    }
  });

  // Pipe body directly — preserves SSE streaming
  return new Response(upstream.body, {
    status: upstream.status,
    headers: responseHeaders,
  });
}

export const GET = handler;
export const POST = handler;
export const PUT = handler;
export const PATCH = handler;
export const DELETE = handler;
