import type { Metadata } from "next";
import { ObservabilityPanel } from "../../components/ObservabilityPanel";

export const metadata: Metadata = {
  title: "SDLC Copilot — Observability",
  description: "Live skill health, metrics, and error diagnostics",
};

export default function ObservePage() {
  return (
    <div className="observe-page">
      <ObservabilityPanel />
    </div>
  );
}
