import type { Metadata } from "next";
import ObserverLogsPanel from "@/components/admin/ObserverLogsPanel";
export const metadata: Metadata = { title: "SDLC Copilot — Observer Logs" };
export default function ObserverLogsPage() { return <ObserverLogsPanel />; }
