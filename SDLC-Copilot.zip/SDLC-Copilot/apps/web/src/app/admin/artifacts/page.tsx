import type { Metadata } from "next";
import ArtifactsPanel from "@/components/admin/ArtifactsPanel";
export const metadata: Metadata = { title: "SDLC Copilot — Artifacts" };
export default function ArtifactsPage() { return <ArtifactsPanel />; }
