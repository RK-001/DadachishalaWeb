"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV_ITEMS = [
  { href: "/admin", label: "Dashboard", icon: "📊" },
  { href: "/admin/projects", label: "Projects", icon: "📁" },
  { href: "/admin/prompt-templates", label: "Prompt Templates", icon: "📝" },
  { href: "/admin/observer-logs", label: "Observer Logs", icon: "🔭" },
  { href: "/admin/circuit-breakers", label: "Circuit Breakers", icon: "⚡" },
  { href: "/admin/builds", label: "Builds", icon: "🏗️" },
  { href: "/admin/artifacts", label: "Artifacts", icon: "📦" },
  { href: "/observe", label: "Observability", icon: "🔬" },
];

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <aside className={`admin-sidebar ${sidebarOpen ? "admin-sidebar--open" : "admin-sidebar--collapsed"}`}>
        <div className="admin-sidebar-header">
          {sidebarOpen && (
            <span className="admin-sidebar-title">⚙️ Admin</span>
          )}
          <button
            className="admin-sidebar-toggle"
            onClick={() => setSidebarOpen((v) => !v)}
            title={sidebarOpen ? "Collapse sidebar" : "Expand sidebar"}
          >
            {sidebarOpen ? "◀" : "▶"}
          </button>
        </div>
        <nav className="admin-nav">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`admin-nav-item ${pathname === item.href ? "admin-nav-item--active" : ""}`}
              title={!sidebarOpen ? item.label : undefined}
            >
              <span className="admin-nav-icon">{item.icon}</span>
              {sidebarOpen && (
                <span className="admin-nav-label">{item.label}</span>
              )}
            </Link>
          ))}
        </nav>
        {sidebarOpen && (
          <div className="admin-sidebar-footer">
            <Link href="/" className="admin-back-link">
              ← Back to Chat
            </Link>
          </div>
        )}
      </aside>

      {/* Main content */}
      <main className="admin-main">
        {children}
      </main>
    </div>
  );
}
