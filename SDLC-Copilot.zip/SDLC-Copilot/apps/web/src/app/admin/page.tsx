import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "SDLC Copilot — Admin",
  description: "Administration and observability dashboard",
};

import AdminDashboard from "@/components/admin/AdminDashboard";

export default function AdminPage() {
  return <AdminDashboard />;
}
