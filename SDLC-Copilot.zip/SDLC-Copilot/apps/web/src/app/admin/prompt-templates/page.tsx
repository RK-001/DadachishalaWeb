import type { Metadata } from "next";
import PromptTemplatesEditor from "@/components/admin/PromptTemplatesEditor";
export const metadata: Metadata = { title: "SDLC Copilot — Prompt Templates" };
export default function PromptTemplatesPage() { return <PromptTemplatesEditor />; }
