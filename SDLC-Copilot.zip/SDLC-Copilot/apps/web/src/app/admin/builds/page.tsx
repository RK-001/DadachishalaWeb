import type { Metadata } from "next";
import BuildsManager from "@/components/admin/BuildsManager";
export const metadata: Metadata = { title: "SDLC Copilot — Builds" };
export default function BuildsPage() { return <BuildsManager />; }
