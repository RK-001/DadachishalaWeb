import type { Metadata } from "next";
import CircuitBreakerPanel from "@/components/admin/CircuitBreakerPanel";
export const metadata: Metadata = { title: "SDLC Copilot — Circuit Breakers" };
export default function CircuitBreakersPage() { return <CircuitBreakerPanel />; }
