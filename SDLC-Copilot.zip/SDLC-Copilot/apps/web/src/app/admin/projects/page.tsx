import type { Metadata } from "next";
import ProjectsManager from "@/components/admin/ProjectsManager";
export const metadata: Metadata = { title: "SDLC Copilot — Projects" };
export default function ProjectsPage() { return <ProjectsManager />; }
