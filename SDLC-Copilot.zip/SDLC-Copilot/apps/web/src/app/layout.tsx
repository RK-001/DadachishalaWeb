import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "SDLC Copilot — KB Assistant",
  description:
    "Knowledge base chat assistant powered by GitHub Copilot SDK",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <nav className="nav-bar">
          <span className="nav-bar-brand">🧠 SDLC Copilot</span>
          <Link href="/" className="nav-link">
            💬 Chat
          </Link>
          <Link href="/observe" className="nav-link">
            🔭 Observe
          </Link>
        </nav>
        {children}
      </body>
    </html>
  );
}
