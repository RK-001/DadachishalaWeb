import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ["@sdlc-copilot/shared"],
};

export default nextConfig;
