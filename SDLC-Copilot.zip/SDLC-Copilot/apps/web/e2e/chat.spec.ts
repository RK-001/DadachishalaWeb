﻿import { test, expect } from "@playwright/test";

//  Chat Interface 

test.describe("Chat Interface", () => {
  test("loads the page and shows the chat UI", async ({ page }) => {
    await page.goto("/");
    await expect(page.locator("h1, .chat-header, [data-testid='chat-header']")).toBeVisible({ timeout: 10000 });
  });

  test("chat textarea is present and focusable", async ({ page }) => {
    await page.goto("/");
    const textarea = page.locator("textarea").first();
    await expect(textarea).toBeVisible({ timeout: 10000 });
    await textarea.click();
    await expect(textarea).toBeFocused();
  });

  test("mode selector contains expected modes", async ({ page }) => {
    await page.goto("/");
    const modeSelect = page.locator("select").first();
    await expect(modeSelect).toBeVisible({ timeout: 10000 });
    const options = await modeSelect.locator("option").allTextContents();
    expect(options.length).toBeGreaterThan(0);
  });
});

//  Builds Panel 

test.describe("Builds Panel", () => {
  test("Builds toggle button is visible in header", async ({ page }) => {
    await page.goto("/");
    // Look for the builds toggle button (contains "Builds" text)
    const buildsBtn = page.locator("button", { hasText: /builds/i });
    await expect(buildsBtn).toBeVisible({ timeout: 10000 });
  });

  test("clicking Builds button opens the builds panel", async ({ page }) => {
    await page.goto("/");
    const buildsBtn = page.locator("button", { hasText: /builds/i }).first();
    await buildsBtn.click();
    // Panel should appear — look for list or new build form
    const panel = page.locator(".builds-panel, [data-testid='builds-panel']");
    await expect(panel).toBeVisible({ timeout: 5000 });
  });

  test("new build form renders title and description inputs", async ({ page }) => {
    await page.goto("/");
    const buildsBtn = page.locator("button", { hasText: /builds/i }).first();
    await buildsBtn.click();

    // Find "New Build" button inside the panel
    const newBuildBtn = page.locator("button", { hasText: /new build/i });
    if (await newBuildBtn.isVisible()) {
      await newBuildBtn.click();
    }

    // Form inputs should appear
    const titleInput = page.locator("input[placeholder*='title'], input[placeholder*='Title'], .builds-input").first();
    await expect(titleInput).toBeVisible({ timeout: 5000 });
  });

  test("closing builds panel hides it", async ({ page }) => {
    await page.goto("/");
    const buildsBtn = page.locator("button", { hasText: /builds/i }).first();
    await buildsBtn.click();

    const panel = page.locator(".builds-panel, [data-testid='builds-panel']");
    await expect(panel).toBeVisible({ timeout: 5000 });

    // Click toggle again to close
    await buildsBtn.click();
    await expect(panel).not.toBeVisible({ timeout: 5000 });
  });
});

//  Pipeline View 

test.describe("Pipeline View (via API mock)", () => {
  test("pipeline stage bar renders when build is selected", async ({ page }) => {
    // Intercept the builds API with a mock build
    await page.route("**/api/builds", async (route) => {
      if (route.request().method() === "GET") {
        await route.fulfill({
          status: 200,
          contentType: "application/json",
          body: JSON.stringify([
            {
              id: "b-test-1",
              projectId: "default",
              title: "Test Build",
              description: "A test build",
              currentStage: "brd_intake",
              status: "active",
              createdBy: "tester",
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
              artifacts: [],
              approvals: [],
            },
          ]),
        });
      } else {
        await route.continue();
      }
    });

    await page.goto("/");
    const buildsBtn = page.locator("button", { hasText: /builds/i }).first();
    await buildsBtn.click();

    // A build item should be visible
    const buildItem = page.locator("text=Test Build");
    await expect(buildItem).toBeVisible({ timeout: 8000 });

    // Click the build to select it (or it may auto-select)
    await buildItem.click();

    // Pipeline stages should appear
    const stageBar = page.locator(".pipeline-stages, .pipeline-view, [data-testid='pipeline-stages']");
    await expect(stageBar).toBeVisible({ timeout: 5000 });
  });
});
