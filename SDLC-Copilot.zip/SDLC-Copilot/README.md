# 🤖 SDLC Copilot

> An AI-powered developer assistant that summarizes GitHub files, answers project questions from a knowledge base, and guides analysts through creating Understanding Documents — built with the **GitHub Copilot SDK**, **Next.js 15**, **Express**, and **Turborepo**.

---

## Table of Contents

1. [What It Does](#what-it-does)
2. [Project Structure](#project-structure)
3. [Architecture Overview](#architecture-overview)
4. [Features](#features)
5. [Prerequisites](#prerequisites)
6. [Quick Start](#quick-start)
7. [Configuration (.env)](#configuration-env)
8. [API Reference](#api-reference)
9. [Tech Stack](#tech-stack)
10. [Security](#security)
11. [Further Reading](#further-reading)

---

## What It Does

SDLC Copilot provides three AI-powered capabilities in a single monorepo application:

| Feature | Description |
|---|---|
| **File Summarizer** | Paste a GitHub repo + file path → get a structured AI-generated summary, streamed in real time |
| **KB Chat Agent** | Ask natural-language questions about your project; the AI fetches relevant docs from a configured knowledge base repo on demand |
| **UD Creator** | Describe a requirement; the AI asks clarifying questions, drafts an Understanding Document following your template, iterates on your feedback, then delivers the approved UD as a downloadable Markdown file |

---

## Project Structure

```
sdlc-copilot/
├── apps/
│   ├── web/                    ← Next.js 15 frontend  (port 3000)
│   │   └── src/
│   │       ├── app/            ← Next.js App Router pages
│   │       └── components/
│   │           ├── ChatInterface.tsx    ← KB Chat + UD Creator UI
│   │           └── FileSummarizer.tsx   ← File Summarizer UI
│   └── server/                 ← Express API + Copilot SDK  (port 4000)
│       └── src/
│           ├── index.ts         ← Server entry point
│           ├── copilot.ts       ← Copilot SDK client singleton
│           ├── chatAgent.ts     ← Session management + tool definitions
│           ├── knowledgeBase.ts ← KB file loader with LRU cache
│           ├── github.ts        ← GitHub REST API helper
│           ├── middleware/
│           │   ├── auth.ts      ← API key / Bearer token auth
│           │   ├── rate-limit.ts
│           │   └── validate.ts  ← Input validation & sanitization
│           ├── routes/
│           │   ├── chat.ts      ← POST /api/chat/stream
│           │   └── summarize.ts ← POST /api/summarize[/stream]
│           └── prompts/
│               ├── system-prompt.md     ← KB Chat assistant persona
│               ├── ud-system-prompt.md  ← UD Analyst persona + workflow
│               └── ud-template.md       ← UD output template
├── packages/
│   └── shared/                 ← Shared TypeScript types (used by both apps)
├── turbo.json
└── package.json
```

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         Browser (Next.js)                        │
│                                                                   │
│  ┌─────────────────────┐      ┌──────────────────────────────┐  │
│  │   FileSummarizer    │      │       ChatInterface           │  │
│  │  (owner/repo/path)  │      │  mode: "chat" | "ud"         │  │
│  └────────┬────────────┘      └──────────────┬───────────────┘  │
└───────────┼──────────────────────────────────┼──────────────────┘
            │ POST /api/summarize/stream        │ POST /api/chat/stream
            │ (SSE)                             │ (SSE + sessionId)
            ▼                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Express Server (port 4000)                  │
│                                                                   │
│  Middleware: helmet · cors · auth (API key) · rate-limit         │
│                                                                   │
│  ┌────────────────────┐    ┌───────────────────────────────┐    │
│  │  summarize router  │    │        chat router            │    │
│  │  github.ts fetch   │    │  chatAgent.ts session map     │    │
│  └────────┬───────────┘    └──────────────┬────────────────┘    │
│           │                               │                       │
│           │                    ┌──────────┴──────────┐           │
│           │                    │   Copilot SDK        │           │
│           │                    │   Session (per user) │           │
│           │                    │   tools:             │           │
│           │                    │    fetch_kb_file     │           │
│           │                    │    create_ud_file    │           │
│           │                    └──────────┬──────────┘           │
└───────────┼──────────────────────────────┼──────────────────────┘
            │                              │
            ▼                              ▼
   GitHub REST API              GitHub Copilot LLM
   (file content)               (gpt-5 / claude-sonnet)
            │                              │
            └──────────── SSE ─────────────┘
                       (streamed to UI)
```

### Request Flows

**File Summarizer**
```
User enters owner/repo/file → POST /api/summarize/stream
  → github.ts fetches raw file from GitHub REST API
  → Copilot SDK session sends content to LLM
  → LLM produces structured Markdown summary
  → SSE chunks stream back to browser in real time
```

**KB Chat Agent**
```
User sends message + sessionId → POST /api/chat/stream
  → chatAgent.ts reuses or creates Copilot session (Map keyed by userId:sessionId:mode)
  → Session carries KB core files in system prompt (loaded at server startup)
  → LLM answers; calls fetch_kb_file tool for on-demand KB lookups
  → Tool handler → knowledgeBase.ts → GitHub REST API (cached)
  → Full multi-turn conversation preserved in SDK session layer
```

**UD Creator**
```
User describes requirement → POST /api/chat/stream (mode: "ud")
  → Separate sdk session with UD-analyst system prompt + UD template
  → LLM asks 3-7 targeted clarifying questions (max 3 rounds)
  → LLM drafts UD; user reviews and revises
  → On approval → LLM calls create_ud_file tool
  → ud_file_ready SSE event → frontend creates Blob download link
```

---

## Features

### Core Capabilities
- **Real-time streaming** — all AI responses stream token-by-token via Server-Sent Events (SSE)
- **Multi-turn conversation** — chat history is preserved in the SDK session layer; no re-sending history
- **On-demand KB fetching** — the LLM autonomously decides which KB files to load using the `fetch_kb_file` tool
- **UD creation workflow** — structured iterative loop: question → draft → revise → approve → download

### Reliability & Performance
- **SSE heartbeat** — keeps streaming connections alive through proxies and load balancers
- **LRU cache** — KB file fetches are cached server-side (configurable max 50 entries)
- **Retry with backoff** — GitHub API calls retry up to 2 times on transient failures
- **Client pre-warming** — Copilot SDK client connects at startup to reduce first-request latency
- **Idle session cleanup** — inactive sessions are reaped every 30 minutes to free memory
- **Graceful shutdown** — all sessions cleanly destroyed on SIGINT

### Security
- **API key authentication** — all `/api` routes require a valid `x-api-key` or `Bearer` token
- **Timing-safe comparison** — `crypto.timingSafeEqual` used for key validation
- **Rate limiting** — global (30 req/min) and per-stream (10 req/min) limits
- **Input validation** — UUID format, max message length (32 KB), allowlist for file extensions
- **Session isolation** — sessions are keyed by `userId:sessionId:mode`; users cannot access each other's sessions
- **Helmet** — sets secure HTTP headers (X-Frame-Options, CSP, etc.)
- **Body size limit** — JSON bodies capped at 100 KB

---

## Prerequisites

| Requirement | Version |
|---|---|
| Node.js | 18+ |
| npm | 10+ |
| GitHub Copilot access | Active subscription |

---

## Quick Start

```bash
# 1. Navigate to the project
cd sdlc-copilot

# 2. Install all workspace dependencies
npm install

# 3. Copy and fill in environment variables
cp .env.example .env
#  → At minimum, set GITHUB_TOKEN and COPILOT_TOKEN (see Configuration below)

# 4. Start both apps in dev mode (hot reload)
npm run dev
```

| Service | URL |
|---|---|
| Web UI | http://localhost:3000 |
| API Server | http://localhost:4000 |
| Health check | http://localhost:4000/healthz |

---

## Configuration (.env)

### Required

| Variable | Description |
|---|---|
| `GITHUB_TOKEN` | GitHub Personal Access Token — needs `repo` scope for private repos |
| `COPILOT_TOKEN` | GitHub token with Copilot API access (may be the same as `GITHUB_TOKEN`) |

### AI / Model

| Variable | Default | Description |
|---|---|---|
| `COPILOT_MODEL` | `gpt-5` | LLM model for all AI features (`gpt-5`, `claude-sonnet-4-6`, etc.) |

### Server

| Variable | Default | Description |
|---|---|---|
| `SERVER_PORT` | `4000` | Express server port |
| `WEB_ORIGIN` | `http://localhost:3000` | Allowed CORS origin |
| `API_KEYS` | *(unset = dev mode)* | Comma-separated list of valid API keys. If unset, auth is disabled |

### Knowledge Base

| Variable | Default | Description |
|---|---|---|
| `KB_REPO_OWNER` | *(required for chat)* | GitHub owner of the KB repository |
| `KB_REPO_NAME` | *(required for chat)* | GitHub repo name containing KB markdown files |
| `KB_REPO_REF` | `main` | Branch or commit ref to read KB files from |
| `KB_CORE_FILES` | `INDEX.md,README.md` | Comma-separated list of files pre-loaded into every chat session's system prompt |
| `KB_PROJECT_NAME` | `the project` | Project name injected into the assistant's persona |
| `KB_GITHUB_TOKEN` | Falls back to `GITHUB_TOKEN` | Separate token for KB repo if it differs from the summarizer repo |
| `KB_FILE_EXTENSIONS` | `.md` | Allowed file extension(s) the `fetch_kb_file` tool may retrieve |

### Frontend

| Variable | Default | Description |
|---|---|---|
| `NEXT_PUBLIC_API_URL` | `http://localhost:4000` | API base URL used by the browser |
| `NEXT_PUBLIC_API_KEY` | *(unset)* | API key sent by the browser (for dev/internal use only — do not expose in production) |

### Rate Limiting & Session Limits

| Variable | Default | Description |
|---|---|---|
| `RATE_LIMIT_WINDOW_MS` | `60000` | Rate limit window in milliseconds |
| `RATE_LIMIT_MAX` | `30` | Max general API requests per window |
| `RATE_LIMIT_STREAM_MAX` | `10` | Max streaming requests per window |
| `MAX_TOTAL_SESSIONS` | `500` | Max concurrent sessions across all users |
| `MAX_SESSIONS_PER_USER` | `10` | Max concurrent sessions per authenticated user |
| `SSE_HEARTBEAT_MS` | `20000` | SSE heartbeat interval in milliseconds |

---

## API Reference

### `POST /api/summarize`
Returns a complete summary as JSON.

**Request body:**
```json
{
  "owner": "facebook",
  "repo": "react",
  "filePath": "packages/react/README.md",
  "ref": "main"
}
```

### `POST /api/summarize/stream`
Same request body; returns an SSE stream of `{ type, data }` events (`chunk`, `metadata`, `done`, `error`).

### `POST /api/chat/stream`
Multi-turn chat with the KB assistant or UD Creator. Returns SSE stream.

**Request body:**
```json
{
  "sessionId": "550e8400-e29b-41d4-a716-446655440000",
  "message": "How does the authentication module work?",
  "mode": "chat"
}
```

`mode` is `"chat"` (KB assistant, default) or `"ud"` (UD Creator analyst).

**SSE event types:**

| Type | Payload | Description |
|---|---|---|
| `status` | string | Progress message (e.g., "Processing...") |
| `chunk` | string | Text token from the LLM |
| `tool_start` | string | Tool invocation label (e.g., "Fetching auth-module.md…") |
| `tool_complete` | string | Tool result label |
| `ud_file_ready` | `{ filename, content }` JSON | UD file ready for download (UD mode only) |
| `done` | `""` | Stream complete |
| `error` | string | Error message |

### `GET /api/chat/status`
Returns KB initialization status: `{ ready, filesLoaded, errors, cacheSize }`.

### `GET /api/health`
Authenticated health check: `{ status: "ok", timestamp }`.

### `GET /healthz`
Unauthenticated health probe (for load balancers / Kubernetes).

---

## Tech Stack

| Layer | Technology |
|---|---|
| Monorepo | Turborepo + npm workspaces |
| Frontend | Next.js 15, React 19, react-markdown |
| Backend | Express 4, TypeScript |
| AI / LLM | GitHub Copilot SDK (`@github/copilot-sdk`) |
| Auth | Custom API key middleware (`crypto.timingSafeEqual`) |
| Rate limiting | `express-rate-limit` |
| Security headers | `helmet` |

---

## Security

- Auth is **disabled in dev mode** when `API_KEYS` is not set (a warning is printed at startup). Always set `API_KEYS` in production.
- The browser-side `NEXT_PUBLIC_API_KEY` should only be used for internal/local deployments. For production, proxy API calls through your backend so the key is never exposed.
- KB file fetches are restricted to the extensions defined in `KB_FILE_EXTENSIONS` (default: `.md` only) and validated against a safe-path regex.

---

## Further Reading

| Document | Description |
|---|---|
| [TECHNICAL-GUIDE.md](TECHNICAL-GUIDE.md) | In-depth architecture, module breakdown, data flows, and extension points for developers |
| [PROJECT-OVERVIEW.md](PROJECT-OVERVIEW.md) | Non-technical plain-language guide with diagrams for stakeholders and new team members |
| [PLAN.md](PLAN.md) | Implementation plan, phase history, and design decisions |

---

## License

MIT
